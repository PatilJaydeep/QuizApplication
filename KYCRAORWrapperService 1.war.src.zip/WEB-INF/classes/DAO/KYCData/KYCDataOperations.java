/*      */ package WEB-INF.classes.DAO.KYCData;
/*      */ 
/*      */ import BO.NewFields.NewFields;
/*      */ import BO.RAOR.CustomerCountry;
/*      */ import BO.RAOR.InterestedParty;
/*      */ import BO.RAOR.Parameter;
/*      */ import BO.RAOR.RAORRequest;
/*      */ import BO.RAOR.XmlMapping;
/*      */ import Database.JNDIConnector;
/*      */ import Logging.Log4j;
/*      */ import Utilities.GetDate;
/*      */ import Utilities.LoadProperties;
/*      */ import Utilities.StringOps;
/*      */ import Utilities.XmlParser;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.naming.NamingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class KYCDataOperations
/*      */ {
/*   32 */   XmlParser p = new XmlParser();
/*   33 */   StringOps strOps = new StringOps();
/*   34 */   GetDate getDate = new GetDate();
/*   35 */   String CUST_TYPE_KEY = "";
/*   36 */   Map<String, String> CUST_TYPE_KEY_SH = new HashMap<String, String>();
/*   37 */   HashMap<String, String> custIDs = new HashMap<String, String>();
/*      */   
/*      */   public NewFields loadNewField(String xml) throws Exception {
/*   40 */     Log4j.getLog().info("This is kyc load new fields function starts");
/*   41 */     String returnedXml = null;
/*   42 */     NewFields newFields = new NewFields();
/*   43 */     HashMap<String, String> legalNames = new HashMap<String, String>();
/*      */     
/*      */     try {
/*   46 */       String nameSpaceToBeRemoved = LoadProperties.getConf().getProperty("kyc.service.namespace.request.xml");
/*   47 */       xml = this.strOps.removeNamespace(xml, nameSpaceToBeRemoved);
/*      */       
/*   49 */       RAORRequest requestRAOR = (RAORRequest)this.p.unmarshalXMl(xml, "RAORRequest");
/*      */       
/*   51 */       if (requestRAOR.getCustomer().getInterestedParties().getInterestedParty() != null && requestRAOR.getCustomer().getInterestedParties().getInterestedParty().size() > 0) {
/*   52 */         newFields.setInterestedParty(requestRAOR.getCustomer().getInterestedParties().getInterestedParty());
/*      */       }
/*   54 */       if (requestRAOR.getCustomer().getAdditionalParameters().getParameter().size() > 0) {
/*   55 */         newFields.setParamValues(requestRAOR.getCustomer().getAdditionalParameters().getParameter());
/*      */       }
/*      */       
/*   58 */       legalNames.put("0-" + requestRAOR.getCustomer().getCustmerDetails().getCustomerType(), requestRAOR.getCustomer().getCustmerDetails().getLegalName());
/*      */       
/*   60 */       returnedXml = this.p.convertoXML(requestRAOR, "RAORRequest");
/*   61 */       returnedXml = this.strOps.removeNs2(returnedXml);
/*      */       
/*   63 */       newFields.setXml(returnedXml);
/*   64 */       newFields.setLegalNames(legalNames);
/*   65 */       newFields.setRaorRequest(requestRAOR);
/*   66 */     } catch (Exception ex) {
/*      */       
/*   68 */       throw ex;
/*      */     } 
/*      */     
/*   71 */     Log4j.getLog().info("This is kyc load new fields function ends");
/*   72 */     return newFields;
/*      */   }
/*      */   
/*      */   public void INSERT_TECHX_CUSTOM(NewFields requestObj) {
/*   76 */     String caseRefNo = "CASE" + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber() + this.getDate.GetDate("yyyyMMdd");
/*   77 */     String cusId0 = requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber();
/*      */ 
/*      */     
/*   80 */     try { this.custIDs.put("caseRefNo", caseRefNo);
/*   81 */       this.custIDs.put("0-custID", cusId0);
/*   82 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/*   83 */       conn.setAutoCommit(false);
/*   84 */       String sql = "INSERT INTO FCT_TP_RAOR_TECHX_CUSTOM(n_raor_req_id,request_fic_mis_date, n_case_ref,v_ra_cust_number,JRSDCN_CD,CUST_TYPE_CD) values(SEQ_FCT_TP_RAOR_TECHX_CUSTOM.nextval,SYSDATE,?,?,'" + requestObj.getRaorRequest().getCustomer().getJurisdiction() + "','" + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerType() + "')";
/*   85 */       PreparedStatement pstmt = conn.prepareStatement(sql, new String[] { "n_raor_req_id" });
/*   86 */       pstmt.setString(1, caseRefNo);
/*   87 */       pstmt.setString(2, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/*   88 */       pstmt.executeQuery();
/*   89 */       conn.commit();
/*   90 */       ResultSet raorReqID = pstmt.getGeneratedKeys();
/*   91 */       if (raorReqID.next()) {
/*      */         
/*   93 */         Long raorRequestID = Long.valueOf(raorReqID.getLong(1));
/*   94 */         this.custIDs.put("raorRequestID", raorRequestID.toString());
/*      */       } 
/*   96 */       pstmt.close();
/*   97 */       conn.close(); }
/*      */     
/*   99 */     catch (NamingException namingException)
/*      */     {  }
/*  101 */     catch (SQLException sQLException) {  }
/*  102 */     catch (ClassNotFoundException classNotFoundException) {}
/*      */   }
/*      */ 
/*      */   
/*      */   public void INSERT_RISK_FACTOR(NewFields requestObj, String NCustTypeKey, String VSubCategory, String VCustTypeName) throws Exception {
/*  107 */     Log4j.getLog().info("This is INSERT_RISK_FACTOR function starts");
/*  108 */     ArrayList<XmlMapping> mappings = new ArrayList<XmlMapping>();
/*      */     
/*      */     try {
/*  111 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/*  112 */       conn.setAutoCommit(false);
/*  113 */       Statement s = conn.createStatement();
/*  114 */       String query = "SELECT a.n_risk_param_desc,a.n_risk_param_tag,NVL (a.n_risk_param_name, 'None') AS n_risk_param_name,NVL (c.n_risk_param_weight, 0) AS n_risk_param_weight,b.v_cust_type_code,b.n_cust_type_key FROM fct_tp_raor_params_map_thx_csm a LEFT JOIN dim_customer_type b ON a.n_focus_cust_type_key = b.n_cust_type_key INNER JOIN appln_risk_rating_params c ON a.n_risk_param_name = c.v_risk_param_code AND b.v_cust_type_code = c.v_cust_type_cd AND c.v_risk_model_code = 'CCR' AND a.N_FOCUS_CUST_TYPE_KEY = " + NCustTypeKey + " AND c.v_sub_category = '" + VSubCategory + "' ORDER BY   a.n_risk_param_tag";
/*  115 */       s.execute(query);
/*      */       
/*  117 */       ResultSet rs = s.getResultSet();
/*      */       
/*  119 */       while (rs.next()) {
/*      */         
/*  121 */         XmlMapping xmlMapping = new XmlMapping();
/*  122 */         xmlMapping.setCustomerType(rs.getString("v_cust_type_code"));
/*  123 */         xmlMapping.setRiskParamDesc(rs.getString("n_risk_param_desc"));
/*  124 */         xmlMapping.setRiskParamName(rs.getString("n_risk_param_name"));
/*  125 */         xmlMapping.setRiskParamTag(rs.getString("n_risk_param_tag"));
/*  126 */         xmlMapping.setRiskParamWeight(rs.getString("n_risk_param_weight"));
/*  127 */         xmlMapping.setCustomerTypeKey(rs.getString("n_cust_type_key"));
/*  128 */         mappings.add(xmlMapping);
/*      */       } 
/*  130 */       rs.close();
/*  131 */       s.close();
/*  132 */       String sql1 = "INSERT INTO FCT_TP_RAOR_REASONS_TECHX_CSTM(n_raor_reason_id,n_raor_case_ref,n_risk_param_name,n_risk_param_weight,n_risk_param_value,v_ra_cust_number,v_cust_type_name,n_raor_req_id) values(seq_FCT_TP_RAOR_REASONS_TECHX.nextval,?,?,?,?,?,?,?)";
/*  133 */       PreparedStatement pstmt1 = conn.prepareStatement(sql1);
/*  134 */       for (XmlMapping map : mappings) {
/*  135 */         pstmt1.setString(1, this.custIDs.get("caseRefNo"));
/*  136 */         pstmt1.setString(2, map.getRiskParamName());
/*  137 */         pstmt1.setDouble(3, Double.parseDouble(map.getRiskParamWeight()));
/*  138 */         if (map.getRiskParamTag() == null) {
/*  139 */           pstmt1.setString(4, (String)null);
/*      */         }
/*  141 */         else if (map.getRiskParamTag().equalsIgnoreCase("Value36")) {
/*  142 */           String NewExistingFlag = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(38)).getValue().get(0);
/*  143 */           Log4j.getLog().info("In Value36");
/*  144 */           if (NewExistingFlag.equalsIgnoreCase("NEW")) {
/*  145 */             ArrayList<Parameter> arr = requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter();
/*      */             
/*  147 */             pstmt1.setString(4, (String)null);
/*      */             
/*  149 */             String val = "";
/*  150 */             ArrayList<String> arrr = ((Parameter)arr.get(35)).getValue();
/*  151 */             for (String arrr1 : arrr) {
/*  152 */               if (!arrr1.isEmpty()) {
/*  153 */                 val = val + arrr1 + ",";
/*      */               }
/*      */             } 
/*      */             
/*  157 */             if (val.length() > 0 && 
/*  158 */               val.charAt(val.length() - 1) == ',') {
/*  159 */               val = val.substring(0, val.length() - 1);
/*      */             }
/*      */             
/*  162 */             pstmt1.setString(4, val);
/*      */           }
/*  164 */           else if (NewExistingFlag.equalsIgnoreCase("EXISTING")) {
/*  165 */             Log4j.getLog().info("In Value36 Existing");
/*  166 */             String existProductType = "";
/*  167 */             String strProduct = "";
/*  168 */             Connection conStatProd = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/*  169 */             conStatProd.setAutoCommit(false);
/*      */             
/*  171 */             String statVal = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(39)).getValue().get(0);
/*      */             
/*  173 */             PreparedStatement pstmtStatusProd = conStatProd.prepareStatement("SELECT PRODUCT_CD FROM CUST_PRD_SERV_CSTM WHERE CUST_INTRL_ID = ?");
/*  174 */             pstmtStatusProd.setString(1, statVal);
/*  175 */             ResultSet rstatus1 = pstmtStatusProd.executeQuery();
/*  176 */             Log4j.getLog().info("rstatus1" + rstatus1);
/*      */             
/*  178 */             while (rstatus1.next())
/*      */             {
/*  180 */               existProductType = existProductType + rstatus1.getString(1) + ",";
/*      */             }
/*      */             
/*  183 */             Log4j.getLog().info("existProductType" + existProductType);
/*      */             
/*  185 */             ArrayList<Parameter> arr = requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter();
/*      */             
/*  187 */             pstmt1.setString(4, (String)null);
/*      */             
/*  189 */             String val = "";
/*  190 */             ArrayList<String> arrr = ((Parameter)arr.get(35)).getValue();
/*  191 */             for (String arrr1 : arrr) {
/*  192 */               if (!arrr1.isEmpty()) {
/*  193 */                 val = val + arrr1 + ",";
/*      */               }
/*      */             } 
/*  196 */             if (val.length() > 0)
/*      */             {
/*  198 */               strProduct = val;
/*      */             }
/*  200 */             Log4j.getLog().info("val" + val);
/*      */             
/*  202 */             if (existProductType.length() > 0) {
/*  203 */               existProductType = existProductType.substring(0, existProductType.length() - 1);
/*  204 */               strProduct = strProduct + existProductType;
/*      */             } 
/*      */             
/*  207 */             pstmt1.setString(4, strProduct);
/*  208 */             pstmtStatusProd.close();
/*  209 */             conStatProd.close();
/*      */           } 
/*      */         } else {
/*      */           
/*  213 */           String val = "";
/*  214 */           ArrayList<String> arr = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(35)).getValue();
/*  215 */           for (int i = 0; i < arr.size(); i++) {
/*  216 */             val = val + (String)arr.get(i);
/*  217 */             if (i != arr.size() - 1) {
/*  218 */               val = val + ",";
/*      */             }
/*      */           } 
/*  221 */           pstmt1.setString(4, val);
/*      */         } 
/*      */         
/*  224 */         pstmt1.setString(5, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/*  225 */         pstmt1.setString(6, VCustTypeName);
/*  226 */         pstmt1.setLong(7, Long.parseLong(this.custIDs.get("raorRequestID")));
/*  227 */         pstmt1.addBatch();
/*      */       } 
/*  229 */       pstmt1.executeBatch();
/*  230 */       conn.commit();
/*  231 */       pstmt1.close();
/*  232 */       conn.setAutoCommit(true);
/*  233 */       conn.close();
/*  234 */     } catch (Exception ex) {
/*  235 */       throw ex;
/*      */     } 
/*      */     
/*  238 */     Log4j.getLog().info("This is INSERT_RISK_FACTOR function ends");
/*      */   }
/*      */   
/*      */   public void INSERT_GEOGRAPHY_TYPE_RISK(NewFields requestObj, String NCustTypeKey, String vStatus, String VCustTypeName) throws Exception {
/*  242 */     Log4j.getLog().info("This is INSERT_GEOGRAPHY_TYPE_RISK function starts");
/*  243 */     ArrayList<XmlMapping> mappings = new ArrayList<XmlMapping>();
/*      */     
/*      */     try {
/*  246 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/*  247 */       conn.setAutoCommit(false);
/*  248 */       Statement s = conn.createStatement();
/*  249 */       if (vStatus.equalsIgnoreCase("")) {
/*  250 */         s.execute("SELECT a.n_risk_param_desc,a.n_risk_param_tag,NVL (a.n_risk_param_name, 'None') AS n_risk_param_name,NVL (c.n_risk_param_weight, 0) AS n_risk_param_weight,b.v_cust_type_code,b.n_cust_type_key FROM fct_tp_raor_params_map_thx_csm a LEFT JOIN dim_customer_type b ON a.n_focus_cust_type_key = b.n_cust_type_key INNER JOIN appln_risk_rating_params c ON a.n_risk_param_name = c.v_risk_param_code AND b.v_cust_type_code = c.v_cust_type_cd AND c.v_risk_model_code = 'CCR' AND a.N_FOCUS_CUST_TYPE_KEY = " + NCustTypeKey + " AND c.v_sub_category = 'Geography' ORDER BY   a.n_risk_param_tag");
/*      */       } else {
/*  252 */         s.execute("SELECT a.n_risk_param_desc,a.n_risk_param_tag,NVL (a.n_risk_param_name, 'None') AS n_risk_param_name,NVL (c.n_risk_param_weight, 0) AS n_risk_param_weight,b.v_cust_type_code,b.n_cust_type_key FROM fct_tp_raor_params_map_thx_csm a LEFT JOIN dim_customer_type b ON a.n_focus_cust_type_key = b.n_cust_type_key INNER JOIN appln_risk_rating_params c ON a.n_risk_param_name = c.v_risk_param_code AND b.v_cust_type_code = c.v_cust_type_cd AND c.v_risk_model_code = 'CCR' AND a.N_FOCUS_CUST_TYPE_KEY = " + NCustTypeKey + " AND c.v_sub_category = 'Geography' AND c.V_STATUS ='" + vStatus + "' ORDER BY   a.n_risk_param_tag");
/*      */       } 
/*  254 */       ResultSet rs = s.getResultSet();
/*  255 */       while (rs.next()) {
/*  256 */         XmlMapping xmlMapping = new XmlMapping();
/*  257 */         xmlMapping.setCustomerType(rs.getString("v_cust_type_code"));
/*  258 */         xmlMapping.setRiskParamDesc(rs.getString("n_risk_param_desc"));
/*  259 */         xmlMapping.setRiskParamName(rs.getString("n_risk_param_name"));
/*  260 */         xmlMapping.setRiskParamTag(rs.getString("n_risk_param_tag"));
/*  261 */         xmlMapping.setRiskParamWeight(rs.getString("n_risk_param_weight"));
/*  262 */         xmlMapping.setCustomerTypeKey(rs.getString("n_cust_type_key"));
/*  263 */         mappings.add(xmlMapping);
/*      */       } 
/*  265 */       rs.close();
/*  266 */       s.close();
/*  267 */       String sql1 = "INSERT INTO FCT_TP_RAOR_REASONS_TECHX_CSTM(n_raor_reason_id,n_raor_case_ref,n_risk_param_name,n_risk_param_weight,n_risk_param_value,v_ra_cust_number,v_cust_type_name,n_raor_req_id) values(seq_FCT_TP_RAOR_REASONS_TECHX.nextval,?,?,?,?,?,?,?)";
/*  268 */       PreparedStatement pstmt1 = conn.prepareStatement(sql1);
/*  269 */       for (XmlMapping map : mappings) {
/*      */         
/*  271 */         pstmt1.setString(1, this.custIDs.get("caseRefNo"));
/*  272 */         pstmt1.setString(2, map.getRiskParamName());
/*  273 */         pstmt1.setDouble(3, Double.parseDouble(map.getRiskParamWeight()));
/*  274 */         if (map.getRiskParamTag().equalsIgnoreCase("PrimaryCitznCountry")) {
/*  275 */           pstmt1.setString(4, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getPrimaryCitznCountry());
/*  276 */         } else if (map.getRiskParamTag().equalsIgnoreCase("ResidenceCountry")) {
/*  277 */           pstmt1.setString(4, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getResidenceCountry());
/*  278 */         } else if (map.getRiskParamTag().equalsIgnoreCase("SecondryCitznCountry")) {
/*  279 */           pstmt1.setString(4, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getSecondryCitznCountry());
/*  280 */         } else if (map.getRiskParamTag().equalsIgnoreCase("CountryOfRelationship")) {
/*  281 */           ArrayList<CustomerCountry> countries = requestObj.getRaorRequest().getCustomer().getCustomerCountries().getCustomerCountry();
/*  282 */           if (countries != null) {
/*  283 */             String concatCountries = "";
/*  284 */             List<String> count = new ArrayList<String>();
/*  285 */             for (CustomerCountry country : countries) {
/*  286 */               count.add(country.getCountryOfRelationship());
/*      */             }
/*  288 */             concatCountries = String.join(",", (Iterable)count);
/*  289 */             pstmt1.setString(4, concatCountries);
/*      */           } else {
/*  291 */             pstmt1.setString(4, (String)null);
/*      */           } 
/*  293 */         } else if (map.getRiskParamTag().equalsIgnoreCase("InterestedParties.PrimaryCitznCountry")) {
/*  294 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/*  295 */           if (Parties != null) {
/*  296 */             String concatCountries = "";
/*  297 */             List<String> count = new ArrayList<String>();
/*  298 */             if (VCustTypeName.compareTo("Organization") == 0) {
/*  299 */               for (InterestedParty party : Parties) {
/*  300 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/*  301 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/*  302 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/*  303 */                   .equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/*  304 */                   .equalsIgnoreCase("Shareholder-Govt") && CustomerType.equalsIgnoreCase("ORG")) || RelationType
/*  305 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/*  306 */                   .equalsIgnoreCase("POA") || (RelationType
/*  307 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/*  308 */                   .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/*  309 */                   .equalsIgnoreCase("UBO-Govt") && CustomerType.equalsIgnoreCase("ORG"))) {
/*  310 */                   count.add(party.getCustomerDetails().getPrimaryCitznCountry());
/*      */                 }
/*      */               } 
/*  313 */               if (count.isEmpty()) {
/*      */                 continue;
/*      */               }
/*  316 */               concatCountries = String.join(",", (Iterable)count);
/*  317 */               pstmt1.setString(4, concatCountries);
/*  318 */             } else if (VCustTypeName.compareTo("Financial Institution") == 0) {
/*      */               
/*  320 */               for (InterestedParty party : Parties) {
/*  321 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/*  322 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/*  323 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/*  324 */                   .equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/*  325 */                   .equalsIgnoreCase("Shareholder-Govt") && CustomerType.equalsIgnoreCase("ORG")) || RelationType
/*  326 */                   .equalsIgnoreCase("KeyController") || (RelationType
/*  327 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/*  328 */                   .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/*  329 */                   .equalsIgnoreCase("UBO-Govt") && CustomerType.equalsIgnoreCase("ORG")) || RelationType
/*  330 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/*  331 */                   .equalsIgnoreCase("POA")) {
/*  332 */                   count.add(party.getCustomerDetails().getPrimaryCitznCountry());
/*      */                 }
/*      */               } 
/*      */               
/*  336 */               if (count.isEmpty()) {
/*      */                 continue;
/*      */               }
/*  339 */               concatCountries = String.join(",", (Iterable)count);
/*  340 */               pstmt1.setString(4, concatCountries);
/*      */             } else {
/*  342 */               pstmt1.setString(4, (String)null);
/*      */             } 
/*      */           } else {
/*  345 */             pstmt1.setString(4, (String)null);
/*      */           } 
/*  347 */         } else if (map.getRiskParamTag().equalsIgnoreCase("InterestedParties.ResidenceCountry")) {
/*  348 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/*  349 */           if (Parties != null) {
/*  350 */             String concatCountries = "";
/*  351 */             List<String> count = new ArrayList<String>();
/*  352 */             if (VCustTypeName.compareTo("Organization") == 0) {
/*  353 */               for (InterestedParty party : Parties) {
/*  354 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/*  355 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/*  356 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/*  357 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/*  358 */                   .equalsIgnoreCase("POA") || (RelationType
/*  359 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND"))) {
/*  360 */                   count.add(party.getCustomerDetails().getResidenceCountry());
/*      */                 }
/*      */               } 
/*  363 */               if (count.isEmpty()) {
/*      */                 continue;
/*      */               }
/*  366 */               concatCountries = String.join(",", (Iterable)count);
/*  367 */               pstmt1.setString(4, concatCountries);
/*  368 */             } else if (VCustTypeName.compareTo("Financial Institution") == 0) {
/*      */               
/*  370 */               for (InterestedParty party : Parties) {
/*  371 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/*  372 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/*  373 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/*  374 */                   .equalsIgnoreCase("KeyController") || (RelationType
/*  375 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/*  376 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/*  377 */                   .equalsIgnoreCase("POA")) {
/*  378 */                   count.add(party.getCustomerDetails().getResidenceCountry());
/*      */                 }
/*      */               } 
/*      */               
/*  382 */               if (count.isEmpty()) {
/*      */                 continue;
/*      */               }
/*  385 */               concatCountries = String.join(",", (Iterable)count);
/*  386 */               pstmt1.setString(4, concatCountries);
/*      */             } else {
/*  388 */               pstmt1.setString(4, (String)null);
/*      */             } 
/*      */           } else {
/*  391 */             pstmt1.setString(4, (String)null);
/*      */           } 
/*  393 */         } else if (map.getRiskParamTag().equalsIgnoreCase("InterestedParties.SecondryCitznCountry")) {
/*  394 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/*  395 */           if (Parties != null) {
/*  396 */             String concatCountries = "";
/*  397 */             List<String> count = new ArrayList<String>();
/*  398 */             if (VCustTypeName.compareTo("Organization") == 0) {
/*  399 */               for (InterestedParty party : Parties) {
/*  400 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/*  401 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/*  402 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/*  403 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/*  404 */                   .equalsIgnoreCase("POA") || (RelationType
/*  405 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND"))) {
/*  406 */                   count.add(party.getCustomerDetails().getSecondryCitznCountry());
/*      */                 }
/*      */               } 
/*  409 */               if (count.isEmpty()) {
/*      */                 continue;
/*      */               }
/*  412 */               concatCountries = String.join(",", (Iterable)count);
/*  413 */               pstmt1.setString(4, concatCountries);
/*  414 */             } else if (VCustTypeName.compareTo("Financial Institution") == 0) {
/*      */               
/*  416 */               for (InterestedParty party : Parties) {
/*  417 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/*  418 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/*  419 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/*  420 */                   .equalsIgnoreCase("KeyController") || (RelationType
/*  421 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/*  422 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/*  423 */                   .equalsIgnoreCase("POA")) {
/*  424 */                   count.add(party.getCustomerDetails().getSecondryCitznCountry());
/*      */                 }
/*      */               } 
/*      */               
/*  428 */               if (count.isEmpty()) {
/*      */                 continue;
/*      */               }
/*  431 */               concatCountries = String.join(",", (Iterable)count);
/*  432 */               pstmt1.setString(4, concatCountries);
/*      */             } else {
/*  434 */               pstmt1.setString(4, (String)null);
/*      */             } 
/*      */           } else {
/*  437 */             pstmt1.setString(4, (String)null);
/*      */           } 
/*  439 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Value11")) {
/*  440 */           String str = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(10)).getValue().get(0);
/*  441 */           if (str == null || str.isEmpty()) {
/*  442 */             str = null;
/*      */           }
/*  444 */           pstmt1.setString(4, str);
/*  445 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Value14")) {
/*  446 */           String str = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(13)).getValue().get(0);
/*  447 */           if (str == null || str.isEmpty()) {
/*  448 */             str = null;
/*      */           }
/*  450 */           pstmt1.setString(4, str);
/*  451 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Value55")) {
/*  452 */           String str = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(54)).getValue().get(0);
/*  453 */           if (str == null || str.isEmpty()) {
/*  454 */             str = null;
/*      */           }
/*  456 */           pstmt1.setString(4, str);
/*  457 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Value56")) {
/*  458 */           String str = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(55)).getValue().get(0);
/*  459 */           if (str == null || str.isEmpty()) {
/*  460 */             str = null;
/*      */           }
/*  462 */           pstmt1.setString(4, str);
/*      */         } 
/*  464 */         pstmt1.setString(5, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/*  465 */         pstmt1.setString(6, VCustTypeName);
/*  466 */         pstmt1.setLong(7, Long.parseLong(this.custIDs.get("raorRequestID")));
/*  467 */         pstmt1.addBatch();
/*      */       } 
/*  469 */       pstmt1.executeBatch();
/*  470 */       conn.commit();
/*  471 */       pstmt1.close();
/*  472 */       conn.setAutoCommit(true);
/*  473 */       conn.close();
/*  474 */     } catch (Exception ex) {
/*  475 */       System.out.println(ex.getMessage());
/*  476 */       throw ex;
/*      */     } 
/*      */     
/*  479 */     Log4j.getLog().info("This is INSERT_GEOGRAPHY_TYPE_RISK function ends");
/*      */   }
/*      */ 
/*      */   
/*      */   public void INSERT_CUSTOMER_TYPE_RISK(NewFields requestObj, String NCustTypeKey, String vStatus, String VCustTypeName) throws Exception {
/*  484 */     Log4j.getLog().info("This is INSERT_CUSTOMER_TYPE_RISK function starts");
/*  485 */     ArrayList<XmlMapping> mappings = new ArrayList<XmlMapping>();
/*      */     try {
/*  487 */       if (vStatus.equalsIgnoreCase("")) {
/*  488 */         Connection conStat = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/*  489 */         String status = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(32)).getValue().get(0);
/*      */ 
/*      */ 
/*      */         
/*  493 */         PreparedStatement pstmtStatus = conStat.prepareStatement("SELECT EMP_STAT_SET_NO FROM EMPLOYMENT_STATUS_IND_SET_CSTM WHERE EMPLOYMENT_STATUS= ?");
/*  494 */         pstmtStatus.setString(1, status);
/*  495 */         ResultSet rstatus = pstmtStatus.executeQuery();
/*  496 */         while (rstatus.next()) {
/*  497 */           vStatus = rstatus.getString(1);
/*      */         }
/*  499 */         if (vStatus == null || vStatus.isEmpty()) {
/*  500 */           throw new Exception("emploment status is empty or has unacceptable value");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  509 */         pstmtStatus.close();
/*  510 */         conStat.close();
/*      */       } 
/*  512 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/*  513 */       conn.setAutoCommit(false);
/*  514 */       Statement s = conn.createStatement();
/*  515 */       s.execute("SELECT a.n_risk_param_desc,a.n_risk_param_tag,NVL (a.n_risk_param_name, 'None') AS n_risk_param_name,NVL (c.n_risk_param_weight, 0) AS n_risk_param_weight,b.v_cust_type_code,b.n_cust_type_key FROM fct_tp_raor_params_map_thx_csm a LEFT JOIN dim_customer_type b ON a.n_focus_cust_type_key = b.n_cust_type_key INNER JOIN appln_risk_rating_params c ON a.n_risk_param_name = c.v_risk_param_code AND b.v_cust_type_code = c.v_cust_type_cd AND c.v_risk_model_code = 'CCR' AND a.N_FOCUS_CUST_TYPE_KEY = " + NCustTypeKey + " AND c.v_sub_category = 'CustomerType' AND c.V_STATUS ='" + vStatus + "' ORDER BY   a.n_risk_param_tag");
/*  516 */       ResultSet rs = s.getResultSet();
/*  517 */       while (rs.next()) {
/*  518 */         XmlMapping xmlMapping = new XmlMapping();
/*  519 */         xmlMapping.setCustomerType(rs.getString("v_cust_type_code"));
/*  520 */         xmlMapping.setRiskParamDesc(rs.getString("n_risk_param_desc"));
/*  521 */         xmlMapping.setRiskParamName(rs.getString("n_risk_param_name"));
/*  522 */         xmlMapping.setRiskParamTag(rs.getString("n_risk_param_tag"));
/*  523 */         xmlMapping.setRiskParamWeight(rs.getString("n_risk_param_weight"));
/*  524 */         xmlMapping.setCustomerTypeKey(rs.getString("n_cust_type_key"));
/*  525 */         mappings.add(xmlMapping);
/*      */       } 
/*  527 */       rs.close();
/*  528 */       s.close();
/*  529 */       String sql1 = "INSERT INTO FCT_TP_RAOR_REASONS_TECHX_CSTM(n_raor_reason_id,n_raor_case_ref,n_risk_param_name,n_risk_param_weight,n_risk_param_value,v_ra_cust_number,v_cust_type_name,n_raor_req_id) values(seq_FCT_TP_RAOR_REASONS_TECHX.nextval,?,?,?,?,?,?,?)";
/*  530 */       PreparedStatement pstmt1 = conn.prepareStatement(sql1);
/*  531 */       for (XmlMapping map : mappings) {
/*  532 */         pstmt1.setString(1, this.custIDs.get("caseRefNo"));
/*  533 */         pstmt1.setString(2, map.getRiskParamName());
/*  534 */         pstmt1.setDouble(3, Double.parseDouble(map.getRiskParamWeight()));
/*  535 */         if (map.getRiskParamTag().equalsIgnoreCase("Industry")) {
/*  536 */           pstmt1.setString(4, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getIndustry());
/*  537 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Occupation")) {
/*  538 */           pstmt1.setString(4, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getOccupation());
/*  539 */         } else if (map.getRiskParamTag().equalsIgnoreCase("CustomerCreationDate")) {
/*  540 */           pstmt1.setString(4, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerCreationDate());
/*  541 */         } else if (map.getRiskParamTag().equalsIgnoreCase("InstituteStartDate")) {
/*  542 */           pstmt1.setString(4, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getInstituteStartDate());
/*  543 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Value35")) {
/*  544 */           String NewExistingFlag = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(38)).getValue().get(0);
/*  545 */           if (NewExistingFlag.equalsIgnoreCase("NEW")) {
/*  546 */             String value5 = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(34)).getValue().get(0);
/*  547 */             if (value5 != null) {
/*  548 */               pstmt1.setString(4, ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(34)).getValue().get(0));
/*      */             }
/*  550 */           } else if (NewExistingFlag.equalsIgnoreCase("EXISTING")) {
/*  551 */             String RAORVal = "";
/*      */             
/*  553 */             RAORVal = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(34)).getValue().get(0);
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  558 */             String existCustAcctType = "";
/*  559 */             String existCustAcctType1 = "";
/*      */             
/*  561 */             Connection conStatAcct = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/*  562 */             conStatAcct.setAutoCommit(false);
/*  563 */             String value1 = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(39)).getValue().get(0);
/*      */             
/*  565 */             Log4j.getLog().info(value1);
/*  566 */             PreparedStatement pstmtStatusAcct = conStatAcct.prepareStatement("SELECT  CRAM_ACCOUNT_TYPE_CODE FROM CUST_ACCT_TYPE_CODE WHERE CUST_ACCT_ROLE_CD IN (SELECT CUST_ACCT_ROLE_CD FROM CUST_ACCT WHERE CUST_INTRL_ID=? AND CUST_ACCT_ROLE_CD IS NOT NULL) AND CRAM_ACCOUNT_TYPE_CODE IS NOT NULL");
/*      */             
/*  568 */             pstmtStatusAcct.setString(1, value1);
/*  569 */             ResultSet rstatus = pstmtStatusAcct.executeQuery();
/*  570 */             if (rstatus != null) {
/*  571 */               while (rstatus.next()) {
/*  572 */                 if (rstatus.getString(1) != null && !rstatus.getString(1).isEmpty()) {
/*  573 */                   existCustAcctType = existCustAcctType + rstatus.getString(1) + ",";
/*      */                 }
/*      */               } 
/*      */               
/*  577 */               Log4j.getLog().info("account type1");
/*  578 */               Log4j.getLog().info(existCustAcctType);
/*  579 */               if (existCustAcctType != null) {
/*  580 */                 Log4j.getLog().info("account type2");
/*  581 */                 if (existCustAcctType.length() > 0) {
/*  582 */                   existCustAcctType = existCustAcctType.substring(0, existCustAcctType.length() - 1);
/*  583 */                   existCustAcctType1 = existCustAcctType.substring(0, existCustAcctType.length() - 1);
/*      */                 } 
/*      */                 
/*  586 */                 if (existCustAcctType != null && !existCustAcctType.isEmpty()) {
/*  587 */                   existCustAcctType = existCustAcctType + ",";
/*      */                 }
/*  589 */                 pstmtStatusAcct.close();
/*  590 */                 conStatAcct.close();
/*      */               } 
/*      */             } 
/*  593 */             String existCustCstm = "";
/*  594 */             String existCustCstm1 = "";
/*  595 */             Connection conStatAcct1 = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/*  596 */             conStatAcct1.setAutoCommit(false);
/*  597 */             String value2 = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(39)).getValue().get(0);
/*  598 */             PreparedStatement pstmtStatusAcct1 = conStatAcct1.prepareStatement("SELECT DISTINCT ACCT_TYPE FROM CUST_CSTM WHERE CUST_INTRL_ID= ? AND ACCT_TYPE IS NOT NULL");
/*  599 */             pstmtStatusAcct1.setString(1, value2);
/*  600 */             ResultSet rstatus1 = pstmtStatusAcct1.executeQuery();
/*  601 */             if (rstatus1 != null) {
/*  602 */               while (rstatus1.next()) {
/*  603 */                 if (rstatus1.getString(1) != null && !rstatus1.getString(1).isEmpty()) {
/*  604 */                   existCustCstm = existCustCstm + rstatus1.getString(1) + ",";
/*      */                 }
/*      */               } 
/*  607 */               if (existCustCstm != null) {
/*  608 */                 Log4j.getLog().info("account type3");
/*  609 */                 Log4j.getLog().info(existCustCstm);
/*  610 */                 if (existCustCstm.length() > 0) {
/*  611 */                   existCustCstm = existCustCstm.substring(0, existCustCstm.length() - 1);
/*  612 */                   existCustCstm1 = existCustCstm.substring(0, existCustCstm.length() - 1);
/*      */                 } 
/*      */                 
/*  615 */                 if (existCustCstm != null && !existCustCstm.isEmpty())
/*      */                 {
/*  617 */                   existCustCstm = existCustCstm + ",";
/*      */                 }
/*      */               } 
/*      */             } 
/*      */ 
/*      */             
/*  623 */             String f1 = existCustAcctType + existCustCstm + RAORVal;
/*  624 */             Log4j.getLog().info("VALUE1");
/*  625 */             Log4j.getLog().info(f1);
/*  626 */             if ((existCustAcctType == null || existCustAcctType.isEmpty()) && (existCustCstm == null || existCustCstm.isEmpty()) && (RAORVal == null || RAORVal.isEmpty())) {
/*  627 */               String AuthValue = "100";
/*  628 */               pstmt1.setString(4, AuthValue);
/*  629 */               Log4j.getLog().info("VALUE2");
/*  630 */               Log4j.getLog().info(f1);
/*      */             } else {
/*      */               
/*  633 */               pstmt1.setString(4, f1);
/*  634 */               Log4j.getLog().info("VALUE3");
/*  635 */               Log4j.getLog().info(f1);
/*      */             } 
/*      */ 
/*      */             
/*  639 */             pstmtStatusAcct1.close();
/*  640 */             conStatAcct1.close();
/*      */           } 
/*  642 */         } else if (map.getRiskParamTag().equalsIgnoreCase("InterestedParties.Value5")) {
/*  643 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/*  644 */           if (Parties != null) {
/*  645 */             String concatCountries = "";
/*  646 */             List<String> count = new ArrayList<String>();
/*  647 */             if (VCustTypeName.compareTo("Organization") == 0) {
/*  648 */               for (InterestedParty party : Parties) {
/*  649 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/*  650 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/*  651 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/*  652 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/*  653 */                   .equalsIgnoreCase("POA") || (RelationType
/*  654 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND"))) {
/*  655 */                   count.add(((Parameter)party.getAdditionalParameters().getParameter().get(4)).getValue().get(0));
/*      */                 }
/*      */               } 
/*  658 */               if (count.isEmpty()) {
/*      */                 continue;
/*      */               }
/*  661 */               concatCountries = String.join(",", (Iterable)count);
/*  662 */               pstmt1.setString(4, concatCountries);
/*  663 */             } else if (VCustTypeName.compareTo("Financial Institution") == 0) {
/*  664 */               for (InterestedParty party : Parties) {
/*  665 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/*  666 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/*  667 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/*  668 */                   .equalsIgnoreCase("KeyController") || (RelationType
/*  669 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/*  670 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/*  671 */                   .equalsIgnoreCase("POA")) {
/*  672 */                   count.add(((Parameter)party.getAdditionalParameters().getParameter().get(4)).getValue().get(0));
/*      */                 }
/*      */               } 
/*  675 */               if (count.isEmpty()) {
/*      */                 continue;
/*      */               }
/*  678 */               concatCountries = String.join(",", (Iterable)count);
/*  679 */               pstmt1.setString(4, concatCountries);
/*      */             } else {
/*  681 */               pstmt1.setString(4, (String)null);
/*      */             } 
/*      */           } else {
/*  684 */             pstmt1.setString(4, (String)null);
/*      */           }
/*      */         
/*  687 */         } else if (map.getRiskParamTag().equalsIgnoreCase("InterestedParties.Value34,Value34")) {
/*  688 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/*  689 */           ArrayList<Parameter> AddParams = requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter();
/*  690 */           String concatCountries = "";
/*  691 */           List<String> count = new ArrayList<String>();
/*  692 */           if (VCustTypeName.compareTo("Organization") == 0) {
/*  693 */             if (Parties != null) {
/*  694 */               for (InterestedParty party : Parties) {
/*  695 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/*  696 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/*  697 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/*  698 */                   .equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || RelationType
/*  699 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/*  700 */                   .equalsIgnoreCase("POA") || (RelationType
/*  701 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/*  702 */                   .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG"))) {
/*  703 */                   count.add(((Parameter)party.getAdditionalParameters().getParameter().get(33)).getValue().get(0));
/*      */                 }
/*      */               } 
/*  706 */               concatCountries = String.join(",", (Iterable)count);
/*      */             } 
/*  708 */             concatCountries = concatCountries + "," + (String)((Parameter)AddParams.get(33)).getValue().get(0);
/*  709 */             pstmt1.setString(4, concatCountries);
/*  710 */           } else if (VCustTypeName.compareTo("Financial Institution") == 0) {
/*  711 */             if (Parties != null) {
/*  712 */               for (InterestedParty party : Parties) {
/*  713 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/*  714 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/*  715 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/*  716 */                   .equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || RelationType
/*  717 */                   .equalsIgnoreCase("KeyController") || (RelationType
/*  718 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/*  719 */                   .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG")) || RelationType
/*  720 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/*  721 */                   .equalsIgnoreCase("POA")) {
/*  722 */                   count.add(((Parameter)party.getAdditionalParameters().getParameter().get(33)).getValue().get(0));
/*      */                 }
/*      */               } 
/*  725 */               concatCountries = String.join(",", (Iterable)count);
/*      */             } 
/*  727 */             concatCountries = concatCountries + "," + (String)((Parameter)AddParams.get(33)).getValue().get(0);
/*  728 */             pstmt1.setString(4, concatCountries);
/*      */           } else {
/*  730 */             pstmt1.setString(4, (String)null);
/*      */           } 
/*  732 */         } else if (map.getRiskParamTag().contains("Value")) {
/*  733 */           ArrayList<Parameter> arr = requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter();
/*  734 */           for (int i = 0; i < arr.size() - 1; i++) {
/*  735 */             pstmt1.setString(4, (String)null);
/*  736 */             if (map.getRiskParamTag().equalsIgnoreCase("Value" + (i + 1))) {
/*  737 */               pstmt1.setString(4, ((Parameter)arr.get(i)).getValue().get(0)); break;
/*      */             } 
/*  739 */             if (map.getRiskParamTag().equalsIgnoreCase("Value" + (i + 1) + ",Value" + (i + 2))) {
/*  740 */               pstmt1.setString(4, (String)((Parameter)arr.get(i)).getValue().get(0) + "," + (String)((Parameter)arr.get(i + 1)).getValue().get(0));
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/*  745 */           if (map.getRiskParamTag().equalsIgnoreCase("Value" + arr.size())) {
/*  746 */             pstmt1.setString(4, ((Parameter)arr.get(arr.size() - 1)).getValue().get(0));
/*      */           }
/*      */         } 
/*      */         
/*  750 */         pstmt1.setString(5, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/*  751 */         pstmt1.setString(6, VCustTypeName);
/*  752 */         pstmt1.setLong(7, Long.parseLong(this.custIDs.get("raorRequestID")));
/*  753 */         pstmt1.addBatch();
/*      */       } 
/*  755 */       pstmt1.executeBatch();
/*  756 */       conn.commit();
/*  757 */       pstmt1.close();
/*  758 */       conn.setAutoCommit(true);
/*  759 */       conn.close();
/*  760 */     } catch (Exception ex) {
/*  761 */       throw ex;
/*      */     } 
/*      */     
/*  764 */     Log4j.getLog().info("This is INSERT_CUSTOMER_TYPE_RISK function ends");
/*      */   }
/*      */   
/*      */   public void INSERT_TRANSACTION_RISK(NewFields requestObj, String NCustTypeKey, String VCustTypeName) throws Exception {
/*  768 */     Log4j.getLog().info("This is INSERT_TRANSACTION_RISK function starts");
/*  769 */     ArrayList<XmlMapping> mappings = new ArrayList<XmlMapping>();
/*      */     
/*      */     try {
/*  772 */       Connection conStat = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/*  773 */       PreparedStatement pstmtStatus = conStat.prepareStatement("select * from cust_trans_cstm where CUST_INTRL_ID = '" + (String)((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(39)).getValue().get(0) + "'");
/*  774 */       ResultSet rstatus = pstmtStatus.executeQuery();
/*  775 */       int[] trans = new int[4];
/*  776 */       while (rstatus.next()) {
/*  777 */         trans[0] = rstatus.getInt("TRANS_TYPE_RSK");
/*  778 */         trans[1] = rstatus.getInt("TRANS_TRND_RSK");
/*  779 */         trans[2] = rstatus.getInt("SCNRO_RSK");
/*  780 */         trans[3] = rstatus.getInt("TRANS_INVS_RSK");
/*      */       } 
/*  782 */       pstmtStatus.close();
/*  783 */       conStat.close();
/*  784 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/*  785 */       conn.setAutoCommit(false);
/*  786 */       Statement s = conn.createStatement();
/*  787 */       s.execute("SELECT a.n_risk_param_desc,a.n_risk_param_tag,NVL (a.n_risk_param_name, 'None') AS n_risk_param_name,NVL (c.n_risk_param_weight, 0) AS n_risk_param_weight,b.v_cust_type_code,b.n_cust_type_key FROM fct_tp_raor_params_map_thx_csm a LEFT JOIN dim_customer_type b ON a.n_focus_cust_type_key = b.n_cust_type_key INNER JOIN appln_risk_rating_params c ON a.n_risk_param_name = c.v_risk_param_code AND b.v_cust_type_code = c.v_cust_type_cd AND c.v_risk_model_code = 'CCR' AND a.N_FOCUS_CUST_TYPE_KEY = " + NCustTypeKey + " AND c.v_sub_category = 'Transaction' ORDER BY   a.n_risk_param_tag");
/*      */       
/*  789 */       ResultSet rs = s.getResultSet();
/*      */       
/*  791 */       while (rs.next()) {
/*      */         
/*  793 */         XmlMapping xmlMapping = new XmlMapping();
/*  794 */         xmlMapping.setCustomerType(rs.getString("v_cust_type_code"));
/*  795 */         xmlMapping.setRiskParamDesc(rs.getString("n_risk_param_desc"));
/*  796 */         xmlMapping.setRiskParamName(rs.getString("n_risk_param_name"));
/*  797 */         xmlMapping.setRiskParamTag(rs.getString("n_risk_param_tag"));
/*  798 */         xmlMapping.setRiskParamWeight(rs.getString("n_risk_param_weight"));
/*  799 */         xmlMapping.setCustomerTypeKey(rs.getString("n_cust_type_key"));
/*  800 */         mappings.add(xmlMapping);
/*      */       } 
/*  802 */       rs.close();
/*  803 */       s.close();
/*  804 */       String sql1 = "INSERT INTO FCT_TP_RAOR_REASONS_TECHX_CSTM(n_raor_reason_id,n_raor_case_ref,n_risk_param_name,n_risk_param_weight,n_risk_param_value,v_ra_cust_number,v_cust_type_name,n_raor_req_id) values(seq_FCT_TP_RAOR_REASONS_TECHX.nextval,?,?,?,?,?,?,?)";
/*  805 */       PreparedStatement pstmt1 = conn.prepareStatement(sql1);
/*  806 */       for (XmlMapping map : mappings) {
/*  807 */         pstmt1.setString(1, this.custIDs.get("caseRefNo"));
/*  808 */         pstmt1.setString(2, map.getRiskParamName());
/*  809 */         pstmt1.setDouble(3, Double.parseDouble(map.getRiskParamWeight()));
/*  810 */         if (map.getRiskParamName().equalsIgnoreCase("MB_CCR_TRANS_TYP_RSK")) {
/*  811 */           pstmt1.setString(4, Integer.toString(trans[0]));
/*  812 */         } else if (map.getRiskParamName().equalsIgnoreCase("MB_CCR_TRANS_TRD_RSK")) {
/*  813 */           pstmt1.setString(4, Integer.toString(trans[1]));
/*  814 */         } else if (map.getRiskParamName().equalsIgnoreCase("MB_CCR_SCRNO_RSK")) {
/*  815 */           pstmt1.setString(4, Integer.toString(trans[2]));
/*  816 */         } else if (map.getRiskParamName().equalsIgnoreCase("MB_CCR_TRANS_INVS_RSK")) {
/*  817 */           pstmt1.setString(4, Integer.toString(trans[3]));
/*      */         } 
/*  819 */         pstmt1.setString(5, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/*  820 */         pstmt1.setString(6, VCustTypeName);
/*  821 */         pstmt1.setLong(7, Long.parseLong(this.custIDs.get("raorRequestID")));
/*  822 */         pstmt1.addBatch();
/*      */       } 
/*  824 */       pstmt1.executeBatch();
/*  825 */       conn.commit();
/*  826 */       pstmt1.close();
/*  827 */       conn.setAutoCommit(true);
/*  828 */       conn.close();
/*  829 */     } catch (Exception ex) {
/*  830 */       throw ex;
/*      */     } 
/*      */     
/*  833 */     Log4j.getLog().info("This is INSERT_TRANSACTION_RISK function ends");
/*      */   }
/*      */   
/*      */   public void INSERT_CHANNEL_RISK(NewFields requestObj, String NCustTypeKey, String vStatus, String VCustTypeName) throws Exception {
/*  837 */     Log4j.getLog().info("This is INSERT_CHANNEL_RISK function starts");
/*  838 */     ArrayList<XmlMapping> mappings = new ArrayList<XmlMapping>();
/*      */     
/*      */     try {
/*  841 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/*  842 */       conn.setAutoCommit(false);
/*  843 */       Statement s = conn.createStatement();
/*  844 */       if (vStatus.equalsIgnoreCase("")) {
/*  845 */         s.execute("SELECT   a.n_risk_param_desc,a.n_risk_param_tag,NVL (a.n_risk_param_name, 'None') AS n_risk_param_name,NVL (c.n_risk_param_weight, 0) AS n_risk_param_weight,b.v_cust_type_code,b.n_cust_type_key FROM fct_tp_raor_params_map_thx_csm a LEFT JOIN dim_customer_type b ON a.n_focus_cust_type_key = b.n_cust_type_key INNER JOIN appln_risk_rating_params c ON a.n_risk_param_name = c.v_risk_param_code AND b.v_cust_type_code = c.v_cust_type_cd AND c.v_risk_model_code = 'CCR' AND a.N_FOCUS_CUST_TYPE_KEY = " + NCustTypeKey + " AND c.v_sub_category = 'Channel' ORDER BY   a.n_risk_param_tag");
/*      */       } else {
/*  847 */         s.execute("SELECT   a.n_risk_param_desc,a.n_risk_param_tag,NVL (a.n_risk_param_name, 'None') AS n_risk_param_name,NVL (c.n_risk_param_weight, 0) AS n_risk_param_weight,b.v_cust_type_code,b.n_cust_type_key FROM fct_tp_raor_params_map_thx_csm a LEFT JOIN dim_customer_type b ON a.n_focus_cust_type_key = b.n_cust_type_key INNER JOIN appln_risk_rating_params c ON a.n_risk_param_name = c.v_risk_param_code AND b.v_cust_type_code = c.v_cust_type_cd AND c.v_risk_model_code = 'CCR' AND a.N_FOCUS_CUST_TYPE_KEY = " + NCustTypeKey + " AND c.v_sub_category = 'Channel' AND c.V_STATUS ='" + vStatus + "'  ORDER BY   a.n_risk_param_tag");
/*      */       } 
/*  849 */       ResultSet rs = s.getResultSet();
/*  850 */       while (rs.next()) {
/*  851 */         XmlMapping xmlMapping = new XmlMapping();
/*  852 */         xmlMapping.setCustomerType(rs.getString("v_cust_type_code"));
/*  853 */         xmlMapping.setRiskParamDesc(rs.getString("n_risk_param_desc"));
/*  854 */         xmlMapping.setRiskParamName(rs.getString("n_risk_param_name"));
/*  855 */         xmlMapping.setRiskParamTag(rs.getString("n_risk_param_tag"));
/*  856 */         xmlMapping.setRiskParamWeight(rs.getString("n_risk_param_weight"));
/*  857 */         xmlMapping.setCustomerTypeKey(rs.getString("n_cust_type_key"));
/*  858 */         mappings.add(xmlMapping);
/*      */       } 
/*  860 */       rs.close();
/*  861 */       s.close();
/*  862 */       String sql1 = "INSERT INTO FCT_TP_RAOR_REASONS_TECHX_CSTM(n_raor_reason_id,n_raor_case_ref,n_risk_param_name,n_risk_param_weight,n_risk_param_value,v_ra_cust_number,v_cust_type_name,n_raor_req_id) values(seq_FCT_TP_RAOR_REASONS_TECHX.nextval,?,?,?,?,?,?,?)";
/*  863 */       PreparedStatement pstmt1 = conn.prepareStatement(sql1);
/*  864 */       for (XmlMapping map : mappings) {
/*  865 */         pstmt1.setString(1, this.custIDs.get("caseRefNo"));
/*  866 */         pstmt1.setString(2, map.getRiskParamName());
/*  867 */         pstmt1.setDouble(3, Double.parseDouble(map.getRiskParamWeight()));
/*  868 */         if (map.getRiskParamTag().contains("Value")) {
/*  869 */           ArrayList<Parameter> arr = requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter();
/*      */           
/*  871 */           for (int i = 0; i < arr.size(); i++) {
/*  872 */             pstmt1.setString(4, (String)null);
/*  873 */             if (map.getRiskParamTag().equalsIgnoreCase("Value" + (i + 1))) {
/*      */               
/*  875 */               String val = "";
/*  876 */               ArrayList<String> arrr = ((Parameter)arr.get(i)).getValue();
/*  877 */               for (String arrr1 : arrr) {
/*  878 */                 if (!arrr1.isEmpty()) {
/*  879 */                   val = val + arrr1 + ",";
/*      */                 }
/*      */               } 
/*  882 */               if (val.length() > 0 && 
/*  883 */                 val.charAt(val.length() - 1) == ',') {
/*  884 */                 val = val.substring(0, val.length() - 1);
/*      */               }
/*      */               
/*  887 */               pstmt1.setString(4, val);
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/*  894 */         pstmt1.setString(5, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/*  895 */         pstmt1.setString(6, VCustTypeName);
/*  896 */         pstmt1.setLong(7, Long.parseLong(this.custIDs.get("raorRequestID")));
/*  897 */         pstmt1.addBatch();
/*      */       } 
/*  899 */       pstmt1.executeBatch();
/*  900 */       conn.commit();
/*  901 */       pstmt1.close();
/*  902 */       conn.setAutoCommit(true);
/*  903 */       conn.close();
/*  904 */     } catch (Exception ex) {
/*  905 */       throw ex;
/*      */     } 
/*      */ 
/*      */     
/*  909 */     Log4j.getLog().info("This is INSERT_CHANNEL_RISK function ends");
/*      */   }
/*      */   
/*      */   public void INSERT_PRODUCT_RISK(NewFields requestObj, String NCustTypeKey, String vStatus, String VCustTypeName) throws Exception {
/*  913 */     Log4j.getLog().info("This is INSERT_PRODUCT_RISK function starts");
/*  914 */     ArrayList<XmlMapping> mappings = new ArrayList<XmlMapping>();
/*      */     
/*      */     try {
/*  917 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/*  918 */       conn.setAutoCommit(false);
/*  919 */       Statement s = conn.createStatement();
/*  920 */       s.execute("SELECT   a.n_risk_param_desc,a.n_risk_param_tag,NVL (a.n_risk_param_name, 'None') AS n_risk_param_name,NVL (c.n_risk_param_weight, 0) AS n_risk_param_weight,b.v_cust_type_code,b.n_cust_type_key FROM fct_tp_raor_params_map_thx_csm a LEFT JOIN dim_customer_type b ON a.n_focus_cust_type_key = b.n_cust_type_key INNER JOIN appln_risk_rating_params c ON a.n_risk_param_name = c.v_risk_param_code AND b.v_cust_type_code = c.v_cust_type_cd AND c.v_risk_model_code = 'CCR' AND a.N_FOCUS_CUST_TYPE_KEY = " + NCustTypeKey + " AND c.v_sub_category = 'ProductService' AND c.V_STATUS ='" + vStatus + "' ORDER BY   a.n_risk_param_tag");
/*  921 */       Log4j.getLog().info("This is INSERT_PRODUCT_RISK function 1");
/*  922 */       ResultSet rs = s.getResultSet();
/*  923 */       while (rs.next()) {
/*  924 */         XmlMapping xmlMapping = new XmlMapping();
/*  925 */         xmlMapping.setCustomerType(rs.getString("v_cust_type_code"));
/*  926 */         xmlMapping.setRiskParamDesc(rs.getString("n_risk_param_desc"));
/*  927 */         xmlMapping.setRiskParamName(rs.getString("n_risk_param_name"));
/*  928 */         xmlMapping.setRiskParamTag(rs.getString("n_risk_param_tag"));
/*  929 */         xmlMapping.setRiskParamWeight(rs.getString("n_risk_param_weight"));
/*  930 */         xmlMapping.setCustomerTypeKey(rs.getString("n_cust_type_key"));
/*  931 */         mappings.add(xmlMapping);
/*  932 */         Log4j.getLog().info("This is INSERT_PRODUCT_RISK function 2");
/*      */       } 
/*  934 */       rs.close();
/*  935 */       s.close();
/*  936 */       String sql1 = "INSERT INTO FCT_TP_RAOR_REASONS_TECHX_CSTM(n_raor_reason_id,n_raor_case_ref,n_risk_param_name,n_risk_param_weight,n_risk_param_value,v_ra_cust_number,v_cust_type_name,n_raor_req_id) values(seq_FCT_TP_RAOR_REASONS_TECHX.nextval,?,?,?,?,?,?,?)";
/*  937 */       PreparedStatement pstmt1 = conn.prepareStatement(sql1);
/*  938 */       Log4j.getLog().info("This is INSERT_PRODUCT_RISK function 3");
/*  939 */       for (XmlMapping map : mappings) {
/*  940 */         pstmt1.setString(1, this.custIDs.get("caseRefNo"));
/*  941 */         pstmt1.setString(2, map.getRiskParamName());
/*  942 */         pstmt1.setDouble(3, Double.parseDouble(map.getRiskParamWeight()));
/*  943 */         if (map.getRiskParamTag().contains("Value")) {
/*  944 */           Log4j.getLog().info("This is INSERT_PRODUCT_RISK Value part");
/*  945 */           ArrayList<Parameter> arr = requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter();
/*      */           
/*  947 */           for (int i = 0; i < arr.size(); i++) {
/*  948 */             pstmt1.setString(4, (String)null);
/*  949 */             if (map.getRiskParamTag().equalsIgnoreCase("Value" + (i + 1))) {
/*      */               
/*  951 */               String val = "";
/*  952 */               ArrayList<String> arrr = ((Parameter)arr.get(i)).getValue();
/*  953 */               for (String arrr1 : arrr) {
/*  954 */                 if (!arrr1.isEmpty()) {
/*  955 */                   val = val + arrr1 + ",";
/*      */                 }
/*      */               } 
/*  958 */               if (val.length() > 0 && 
/*  959 */                 val.charAt(val.length() - 1) == ',') {
/*  960 */                 val = val.substring(0, val.length() - 1);
/*      */               }
/*      */               
/*  963 */               pstmt1.setString(4, val);
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/*  970 */         Log4j.getLog().info("This is INSERT_PRODUCT_RISK function 4");
/*  971 */         pstmt1.setString(5, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/*  972 */         pstmt1.setString(6, VCustTypeName);
/*  973 */         pstmt1.setLong(7, Long.parseLong(this.custIDs.get("raorRequestID")));
/*  974 */         pstmt1.addBatch();
/*      */       } 
/*  976 */       pstmt1.executeBatch();
/*  977 */       conn.commit();
/*  978 */       pstmt1.close();
/*  979 */       conn.setAutoCommit(true);
/*  980 */       conn.close();
/*  981 */     } catch (Exception ex) {
/*  982 */       throw ex;
/*      */     } 
/*      */ 
/*      */     
/*  986 */     Log4j.getLog().info("This is INSERT_PRODUCT_RISK function ends");
/*      */   }
/*      */   
/*      */   public void INSERT_SYSTEM_CONTOL_RISK(NewFields requestObj, String NCustTypeKey, String vStatus, String VCustTypeName) throws Exception {
/*  990 */     Log4j.getLog().info("This is INSERT_SYSTEM_CONTOL_RISK function starts");
/*  991 */     ArrayList<XmlMapping> mappings = new ArrayList<XmlMapping>();
/*      */     
/*      */     try {
/*  994 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/*  995 */       conn.setAutoCommit(false);
/*  996 */       Statement s = conn.createStatement();
/*  997 */       s.execute("SELECT   a.n_risk_param_desc,a.n_risk_param_tag,NVL (a.n_risk_param_name, 'None') AS n_risk_param_name,NVL (c.n_risk_param_weight, 0) AS n_risk_param_weight,b.v_cust_type_code,b.n_cust_type_key FROM fct_tp_raor_params_map_thx_csm a LEFT JOIN dim_customer_type b ON a.n_focus_cust_type_key = b.n_cust_type_key INNER JOIN appln_risk_rating_params c ON a.n_risk_param_name = c.v_risk_param_code AND b.v_cust_type_code = c.v_cust_type_cd AND c.v_risk_model_code = 'CCR' AND a.N_FOCUS_CUST_TYPE_KEY = " + NCustTypeKey + " AND c.v_sub_category = 'SystemAndControl' AND c.V_STATUS ='" + vStatus + "' ORDER BY   a.n_risk_param_tag");
/*  998 */       ResultSet rs = s.getResultSet();
/*  999 */       while (rs.next()) {
/* 1000 */         XmlMapping xmlMapping = new XmlMapping();
/* 1001 */         xmlMapping.setCustomerType(rs.getString("v_cust_type_code"));
/* 1002 */         xmlMapping.setRiskParamDesc(rs.getString("n_risk_param_desc"));
/* 1003 */         xmlMapping.setRiskParamName(rs.getString("n_risk_param_name"));
/* 1004 */         xmlMapping.setRiskParamTag(rs.getString("n_risk_param_tag"));
/* 1005 */         xmlMapping.setRiskParamWeight(rs.getString("n_risk_param_weight"));
/* 1006 */         xmlMapping.setCustomerTypeKey(rs.getString("n_cust_type_key"));
/* 1007 */         mappings.add(xmlMapping);
/*      */       } 
/* 1009 */       rs.close();
/* 1010 */       s.close();
/* 1011 */       String sql1 = "INSERT INTO FCT_TP_RAOR_REASONS_TECHX_CSTM(n_raor_reason_id,n_raor_case_ref,n_risk_param_name,n_risk_param_weight,n_risk_param_value,v_ra_cust_number,v_cust_type_name,n_raor_req_id) values(seq_FCT_TP_RAOR_REASONS_TECHX.nextval,?,?,?,?,?,?,?)";
/* 1012 */       PreparedStatement pstmt1 = conn.prepareStatement(sql1);
/* 1013 */       for (XmlMapping map : mappings) {
/* 1014 */         pstmt1.setString(1, this.custIDs.get("caseRefNo"));
/* 1015 */         pstmt1.setString(2, map.getRiskParamName());
/* 1016 */         pstmt1.setDouble(3, Double.parseDouble(map.getRiskParamWeight()));
/* 1017 */         if (map.getRiskParamTag().contains("Value")) {
/* 1018 */           ArrayList<Parameter> arr = requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter();
/*      */           
/* 1020 */           for (int i = 0; i < arr.size(); i++) {
/* 1021 */             pstmt1.setString(4, (String)null);
/* 1022 */             if (map.getRiskParamTag().equalsIgnoreCase("Value" + (i + 1))) {
/*      */               
/* 1024 */               String val = "";
/* 1025 */               ArrayList<String> arrr = ((Parameter)arr.get(i)).getValue();
/* 1026 */               for (String arrr1 : arrr) {
/* 1027 */                 if (!arrr1.isEmpty()) {
/* 1028 */                   val = val + arrr1 + ",";
/*      */                 }
/*      */               } 
/* 1031 */               if (val.length() > 0 && 
/* 1032 */                 val.charAt(val.length() - 1) == ',') {
/* 1033 */                 val = val.substring(0, val.length() - 1);
/*      */               }
/*      */               
/* 1036 */               pstmt1.setString(4, val);
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/* 1043 */         pstmt1.setString(5, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/* 1044 */         pstmt1.setString(6, VCustTypeName);
/* 1045 */         pstmt1.setLong(7, Long.parseLong(this.custIDs.get("raorRequestID")));
/* 1046 */         pstmt1.addBatch();
/*      */       } 
/* 1048 */       pstmt1.executeBatch();
/* 1049 */       conn.commit();
/* 1050 */       pstmt1.close();
/* 1051 */       conn.setAutoCommit(true);
/* 1052 */       conn.close();
/* 1053 */     } catch (Exception ex) {
/* 1054 */       throw ex;
/*      */     } 
/*      */     
/* 1057 */     Log4j.getLog().info("This is INSERT_SYSTEM_CONTOL_RISK function ends");
/*      */   }
/*      */   
/*      */   public void INSERT_OVERRIDE_PROHIBITS(NewFields requestObj, String NCustTypeKey, String value, String VCustTypeName) throws Exception {
/* 1061 */     Log4j.getLog().info("This is INSERT_OVERRIDE_PROHIBITS function starts");
/* 1062 */     ArrayList<XmlMapping> mappings = new ArrayList<XmlMapping>();
/*      */     
/*      */     try {
/* 1065 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/* 1066 */       conn.setAutoCommit(false);
/* 1067 */       Statement s = conn.createStatement();
/* 1068 */       s.execute("SELECT DISTINCT a.n_risk_param_desc, NVL (a.n_risk_param_tag, 'None') AS n_risk_param_tag , NVL (a.n_risk_param_name, 'None') AS n_risk_param_name, b.v_cust_type_code, b.n_cust_type_key FROM fct_tp_raor_params_map_thx_csm a LEFT JOIN dim_customer_type b ON a.n_focus_cust_type_key = b.n_cust_type_key INNER JOIN appln_rb_processing c ON     a.n_risk_param_name = c.v_rb_rule_code AND b.v_cust_type_code = c.v_cust_type_cd AND  a.N_FOCUS_CUST_TYPE_KEY = " + NCustTypeKey + " AND c.V_RISK_ASSMNT_MODEL = 'RB' and C.V_RB_RULE_COMMENTS ='" + value + "'");
/* 1069 */       ResultSet rs = s.getResultSet();
/* 1070 */       while (rs.next()) {
/* 1071 */         XmlMapping xmlMapping = new XmlMapping();
/* 1072 */         xmlMapping.setCustomerType(rs.getString("v_cust_type_code"));
/* 1073 */         xmlMapping.setRiskParamDesc(rs.getString("n_risk_param_desc"));
/* 1074 */         xmlMapping.setRiskParamName(rs.getString("n_risk_param_name"));
/* 1075 */         xmlMapping.setRiskParamTag(rs.getString("n_risk_param_tag"));
/* 1076 */         xmlMapping.setCustomerTypeKey(rs.getString("n_cust_type_key"));
/* 1077 */         mappings.add(xmlMapping);
/*      */       } 
/* 1079 */       rs.close();
/* 1080 */       s.close();
/*      */       
/* 1082 */       Connection conStat = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/* 1083 */       String statVal = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(39)).getValue().get(0);
/* 1084 */       PreparedStatement pstmtStatus = conStat.prepareStatement("select * from cust_trans_cstm where CUST_INTRL_ID = '" + statVal + "'");
/* 1085 */       ResultSet rstatus = pstmtStatus.executeQuery();
/*      */       
/* 1087 */       int[] trans = new int[4];
/* 1088 */       while (rstatus.next()) {
/* 1089 */         trans[0] = rstatus.getInt("TRANS_TYPE_RSK");
/* 1090 */         trans[1] = rstatus.getInt("TRANS_TRND_RSK");
/* 1091 */         trans[2] = rstatus.getInt("SCNRO_RSK");
/* 1092 */         trans[3] = rstatus.getInt("TRANS_INVS_RSK");
/*      */       } 
/* 1094 */       pstmtStatus.close();
/* 1095 */       conStat.close();
/*      */       
/* 1097 */       String sql1 = "INSERT INTO FCT_TP_RAOR_REASONS_TECHX_CSTM(n_raor_reason_id,n_raor_case_ref,n_risk_param_name,n_risk_param_value,v_ra_cust_number,v_cust_type_name,n_raor_req_id) values(seq_FCT_TP_RAOR_REASONS_TECHX.nextval,?,?,?,?,?,?)";
/* 1098 */       PreparedStatement pstmt1 = conn.prepareStatement(sql1);
/* 1099 */       ArrayList<Parameter> AddParams = requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter();
/* 1100 */       for (XmlMapping map : mappings) {
/* 1101 */         pstmt1.setString(1, this.custIDs.get("caseRefNo"));
/* 1102 */         pstmt1.setString(2, map.getRiskParamName());
/* 1103 */         if (map.getRiskParamName() != null && map.getRiskParamName().equalsIgnoreCase("RB_CCR_TRANS_INVS_RSK")) {
/* 1104 */           pstmt1.setString(3, Integer.toString(trans[3]));
/* 1105 */         } else if (map.getRiskParamTag().equalsIgnoreCase("None")) {
/* 1106 */           pstmt1.setString(3, (String)null);
/* 1107 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Value32,Value33,PrimaryCitznCountry,SecondryCitznCountry")) {
/* 1108 */           pstmt1.setString(3, (String)((Parameter)AddParams.get(31)).getValue().get(0) + "," + (String)((Parameter)AddParams.get(32)).getValue().get(0) + "," + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getPrimaryCitznCountry() + "," + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getSecondryCitznCountry());
/* 1109 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Value32")) {
/* 1110 */           pstmt1.setString(3, ((Parameter)AddParams.get(31)).getValue().get(0));
/* 1111 */         } else if (map.getRiskParamTag().equalsIgnoreCase("ResidenceCountry")) {
/* 1112 */           pstmt1.setString(3, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getResidenceCountry());
/* 1113 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Value33,Industry")) {
/* 1114 */           pstmt1.setString(3, (String)((Parameter)AddParams.get(32)).getValue().get(0) + "," + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getIndustry());
/* 1115 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Value33,Occupation")) {
/* 1116 */           pstmt1.setString(3, (String)((Parameter)AddParams.get(32)).getValue().get(0) + "," + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getOccupation());
/* 1117 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Value6,PrimaryCitznCountry")) {
/*      */ 
/*      */ 
/*      */           
/* 1121 */           pstmt1.setString(3, (String)((Parameter)AddParams.get(5)).getValue().get(0) + "," + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getPrimaryCitznCountry());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1130 */         else if (map.getRiskParamTag().equalsIgnoreCase("Value32,PrimaryCitznCountry,SecondryCitznCountry")) {
/* 1131 */           pstmt1.setString(3, (String)((Parameter)AddParams.get(31)).getValue().get(0) + "," + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getPrimaryCitznCountry() + "," + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getSecondryCitznCountry());
/*      */         
/*      */         }
/* 1134 */         else if (map.getRiskParamTag().equalsIgnoreCase("Value5")) {
/*      */ 
/*      */           
/* 1137 */           pstmt1.setString(3, ((Parameter)AddParams.get(4)).getValue().get(0));
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1142 */         else if (map.getRiskParamTag().equalsIgnoreCase("Value34")) {
/* 1143 */           pstmt1.setString(3, ((Parameter)AddParams.get(33)).getValue().get(0));
/* 1144 */         } else if (map.getRiskParamTag().equalsIgnoreCase("PrimaryCitznCountry,SecondryCitznCountry,Value11,ResidenceCountry")) {
/* 1145 */           pstmt1.setString(3, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getPrimaryCitznCountry() + "," + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getSecondryCitznCountry() + "," + (String)((Parameter)AddParams.get(10)).getValue().get(0) + "," + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getResidenceCountry());
/* 1146 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Industry")) {
/* 1147 */           pstmt1.setString(3, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getIndustry());
/* 1148 */         } else if (map.getRiskParamTag().equalsIgnoreCase("InterestedParties.Value5")) {
/* 1149 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/* 1150 */           if (Parties != null) {
/* 1151 */             String concatCountries = "";
/* 1152 */             List<String> count = new ArrayList<String>();
/* 1153 */             if (VCustTypeName.compareTo("Organization") == 0) {
/* 1154 */               for (InterestedParty party : Parties) {
/* 1155 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1156 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1157 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/* 1158 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/* 1159 */                   .equalsIgnoreCase("POA") || (RelationType
/* 1160 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND"))) {
/* 1161 */                   count.add(((Parameter)party.getAdditionalParameters().getParameter().get(4)).getValue().get(0));
/*      */                 }
/*      */               } 
/* 1164 */               concatCountries = String.join(",", (Iterable)count);
/* 1165 */               pstmt1.setString(3, concatCountries);
/* 1166 */             } else if (VCustTypeName.compareTo("Financial Institution") == 0) {
/* 1167 */               for (InterestedParty party : Parties) {
/* 1168 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1169 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1170 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/* 1171 */                   .equalsIgnoreCase("KeyController") || (RelationType
/* 1172 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/* 1173 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/* 1174 */                   .equalsIgnoreCase("POA")) {
/* 1175 */                   count.add(((Parameter)party.getAdditionalParameters().getParameter().get(4)).getValue().get(0));
/*      */                 }
/*      */               } 
/* 1178 */               concatCountries = String.join(",", (Iterable)count);
/* 1179 */               pstmt1.setString(3, concatCountries);
/*      */             } else {
/* 1181 */               pstmt1.setString(3, (String)null);
/*      */             } 
/*      */           } else {
/* 1184 */             pstmt1.setString(3, (String)null);
/*      */           } 
/* 1186 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Value2,ResidenceCountry")) {
/* 1187 */           pstmt1.setString(3, (String)((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(1)).getValue().get(0) + "," + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getResidenceCountry());
/* 1188 */         } else if (map.getRiskParamTag().equalsIgnoreCase("InterestedParties.ResidenceCountry")) {
/* 1189 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/* 1190 */           if (Parties != null) {
/* 1191 */             String concatCountries = "";
/* 1192 */             List<String> count = new ArrayList<String>();
/* 1193 */             if (VCustTypeName.compareTo("Organization") == 0) {
/* 1194 */               for (InterestedParty party : Parties) {
/* 1195 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1196 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1197 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/* 1198 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/* 1199 */                   .equalsIgnoreCase("POA") || (RelationType
/* 1200 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND"))) {
/* 1201 */                   count.add(party.getCustomerDetails().getResidenceCountry());
/*      */                 }
/*      */               } 
/* 1204 */               concatCountries = String.join(",", (Iterable)count);
/* 1205 */               pstmt1.setString(3, concatCountries);
/* 1206 */             } else if (VCustTypeName.compareTo("Financial Institution") == 0) {
/*      */               
/* 1208 */               for (InterestedParty party : Parties) {
/* 1209 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1210 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1211 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/* 1212 */                   .equalsIgnoreCase("KeyController") || (RelationType
/* 1213 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/* 1214 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/* 1215 */                   .equalsIgnoreCase("POA")) {
/* 1216 */                   count.add(party.getCustomerDetails().getResidenceCountry());
/*      */                 }
/*      */               } 
/*      */               
/* 1220 */               if (count.isEmpty()) {
/*      */                 continue;
/*      */               }
/* 1223 */               concatCountries = String.join(",", (Iterable)count);
/* 1224 */               pstmt1.setString(3, concatCountries);
/*      */             } else {
/* 1226 */               pstmt1.setString(3, (String)null);
/*      */             } 
/*      */           } else {
/* 1229 */             pstmt1.setString(3, (String)null);
/*      */           } 
/* 1231 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Value2,CountryOfRelationship")) {
/* 1232 */           ArrayList<CustomerCountry> countries = requestObj.getRaorRequest().getCustomer().getCustomerCountries().getCustomerCountry();
/*      */           
/* 1234 */           List<String> count = new ArrayList<String>();
/* 1235 */           if (countries != null) {
/* 1236 */             for (CustomerCountry country : countries) {
/* 1237 */               count.add(country.getCountryOfRelationship());
/*      */             }
/*      */           }
/* 1240 */           String concatCountries = String.join(",", (Iterable)count);
/* 1241 */           concatCountries = (String)((Parameter)AddParams.get(1)).getValue().get(0) + "," + concatCountries;
/* 1242 */           pstmt1.setString(3, concatCountries);
/* 1243 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Industry,Value2")) {
/* 1244 */           pstmt1.setString(3, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getIndustry() + "," + (String)((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(1)).getValue().get(0));
/* 1245 */         } else if (map.getRiskParamTag().equalsIgnoreCase("InterestedParties.Value34")) {
/* 1246 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/* 1247 */           if (Parties != null) {
/* 1248 */             String concatCountries = "";
/* 1249 */             List<String> count = new ArrayList<String>();
/* 1250 */             if (VCustTypeName.compareTo("Organization") == 0) {
/* 1251 */               for (InterestedParty party : Parties) {
/* 1252 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1253 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1254 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1255 */                   .equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || RelationType
/* 1256 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/* 1257 */                   .equalsIgnoreCase("POA") || (RelationType
/* 1258 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1259 */                   .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG"))) {
/* 1260 */                   count.add(((Parameter)party.getAdditionalParameters().getParameter().get(33)).getValue().get(0));
/*      */                 }
/*      */               } 
/* 1263 */               concatCountries = String.join(",", (Iterable)count);
/* 1264 */               pstmt1.setString(3, concatCountries);
/* 1265 */             } else if (VCustTypeName.compareTo("Financial Institution") == 0) {
/* 1266 */               for (InterestedParty party : Parties) {
/* 1267 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1268 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1269 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1270 */                   .equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || RelationType
/* 1271 */                   .equalsIgnoreCase("KeyController") || (RelationType
/* 1272 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1273 */                   .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG"))) {
/* 1274 */                   count.add(((Parameter)party.getAdditionalParameters().getParameter().get(33)).getValue().get(0));
/*      */                 }
/*      */               } 
/* 1277 */               concatCountries = String.join(",", (Iterable)count);
/* 1278 */               pstmt1.setString(3, concatCountries);
/*      */             } else {
/* 1280 */               pstmt1.setString(3, (String)null);
/*      */             } 
/*      */           } else {
/* 1283 */             pstmt1.setString(3, (String)null);
/*      */           } 
/* 1285 */         } else if (map.getRiskParamTag().equalsIgnoreCase("InterestedParties.Value34,Value34")) {
/* 1286 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/* 1287 */           String concatCountries = "";
/* 1288 */           List<String> count = new ArrayList<String>();
/* 1289 */           if (VCustTypeName.compareTo("Organization") == 0) {
/* 1290 */             if (Parties != null) {
/* 1291 */               for (InterestedParty party : Parties) {
/* 1292 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1293 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1294 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1295 */                   .equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || RelationType
/* 1296 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/* 1297 */                   .equalsIgnoreCase("POA") || (RelationType
/* 1298 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1299 */                   .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG"))) {
/* 1300 */                   count.add(((Parameter)party.getAdditionalParameters().getParameter().get(33)).getValue().get(0));
/*      */                 }
/*      */               } 
/* 1303 */               concatCountries = String.join(",", (Iterable)count);
/*      */             } 
/* 1305 */             concatCountries = concatCountries + "," + (String)((Parameter)AddParams.get(33)).getValue().get(0);
/* 1306 */             pstmt1.setString(3, concatCountries);
/* 1307 */           } else if (VCustTypeName.compareTo("Financial Institution") == 0) {
/* 1308 */             if (Parties != null) {
/* 1309 */               for (InterestedParty party : Parties) {
/* 1310 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1311 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1312 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1313 */                   .equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || RelationType
/* 1314 */                   .equalsIgnoreCase("KeyController") || (RelationType
/* 1315 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1316 */                   .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG")) || RelationType
/* 1317 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/* 1318 */                   .equalsIgnoreCase("POA")) {
/* 1319 */                   count.add(((Parameter)party.getAdditionalParameters().getParameter().get(33)).getValue().get(0));
/*      */                 }
/*      */               } 
/* 1322 */               concatCountries = String.join(",", (Iterable)count);
/*      */             } 
/* 1324 */             concatCountries = concatCountries + "," + (String)((Parameter)AddParams.get(33)).getValue().get(0);
/* 1325 */             pstmt1.setString(3, concatCountries);
/*      */           } else {
/* 1327 */             pstmt1.setString(3, (String)null);
/*      */           } 
/* 1329 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Industry,InterestedParties.PrimaryCitznCountry")) {
/* 1330 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/* 1331 */           String concatCountries = "";
/* 1332 */           List<String> count = new ArrayList<String>();
/* 1333 */           if (VCustTypeName.compareTo("Organization") == 0) {
/* 1334 */             if (Parties != null) {
/* 1335 */               for (InterestedParty party : Parties) {
/* 1336 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1337 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1338 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1339 */                   .equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1340 */                   .equalsIgnoreCase("Shareholder-Govt") && CustomerType.equalsIgnoreCase("ORG")) || RelationType
/* 1341 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/* 1342 */                   .equalsIgnoreCase("POA") || (RelationType
/* 1343 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1344 */                   .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1345 */                   .equalsIgnoreCase("UBO-Govt") && CustomerType.equalsIgnoreCase("ORG"))) {
/* 1346 */                   count.add(party.getCustomerDetails().getPrimaryCitznCountry());
/*      */                 }
/*      */               } 
/* 1349 */               concatCountries = String.join(",", (Iterable)count);
/*      */             } 
/* 1351 */             concatCountries = requestObj.getRaorRequest().getCustomer().getCustmerDetails().getIndustry() + "," + concatCountries;
/* 1352 */             pstmt1.setString(3, concatCountries);
/* 1353 */           } else if (VCustTypeName.compareTo("Financial Institution") == 0) {
/* 1354 */             if (Parties != null) {
/* 1355 */               for (InterestedParty party : Parties) {
/* 1356 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1357 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1358 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1359 */                   .equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1360 */                   .equalsIgnoreCase("Shareholder-Govt") && CustomerType.equalsIgnoreCase("ORG")) || RelationType
/* 1361 */                   .equalsIgnoreCase("KeyController") || (RelationType
/* 1362 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1363 */                   .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1364 */                   .equalsIgnoreCase("UBO-Govt") && CustomerType.equalsIgnoreCase("ORG"))) {
/* 1365 */                   count.add(party.getCustomerDetails().getPrimaryCitznCountry());
/*      */                 }
/*      */               } 
/* 1368 */               concatCountries = String.join(",", (Iterable)count);
/*      */             } 
/* 1370 */             concatCountries = requestObj.getRaorRequest().getCustomer().getCustmerDetails().getIndustry() + "," + concatCountries;
/* 1371 */             pstmt1.setString(3, concatCountries);
/*      */           } else {
/* 1373 */             pstmt1.setString(3, (String)null);
/*      */           } 
/* 1375 */         } else if (map.getRiskParamTag().equalsIgnoreCase("InterestedParties.ResidenceCountry,InterestedParties.PrimaryCitznCountry,InterestedParties.SecondryCitznCountry")) {
/* 1376 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/* 1377 */           if (Parties != null) {
/* 1378 */             String concatCountries = "";
/* 1379 */             List<String> count = new ArrayList<String>();
/* 1380 */             if (VCustTypeName.compareTo("Organization") == 0) {
/* 1381 */               for (InterestedParty party : Parties) {
/* 1382 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1383 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1384 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/* 1385 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/* 1386 */                   .equalsIgnoreCase("POA") || (RelationType
/* 1387 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND"))) {
/* 1388 */                   count.add(party.getCustomerDetails().getResidenceCountry() + "," + party.getCustomerDetails().getPrimaryCitznCountry() + "," + party.getCustomerDetails().getSecondryCitznCountry());
/*      */                 }
/*      */               } 
/* 1391 */               concatCountries = String.join(".", (Iterable)count);
/* 1392 */               pstmt1.setString(3, concatCountries);
/* 1393 */             } else if (VCustTypeName.compareTo("Financial Institution") == 0) {
/*      */               
/* 1395 */               for (InterestedParty party : Parties) {
/* 1396 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1397 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1398 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/* 1399 */                   .equalsIgnoreCase("KeyController") || (RelationType
/* 1400 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/* 1401 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/* 1402 */                   .equalsIgnoreCase("POA")) {
/* 1403 */                   count.add(party.getCustomerDetails().getResidenceCountry() + "," + party.getCustomerDetails().getPrimaryCitznCountry() + "," + party.getCustomerDetails().getSecondryCitznCountry());
/*      */                 }
/*      */               } 
/*      */               
/* 1407 */               concatCountries = String.join(".", (Iterable)count);
/* 1408 */               pstmt1.setString(3, concatCountries);
/*      */             } else {
/* 1410 */               pstmt1.setString(3, (String)null);
/*      */             } 
/*      */           } else {
/* 1413 */             pstmt1.setString(3, (String)null);
/*      */           } 
/* 1415 */         } else if (map.getRiskParamTag().equalsIgnoreCase("InterestedParties.PrimaryCitznCountry") && (map.getRiskParamName().equalsIgnoreCase("RB_CCR_IP_PRM_NATONLY_RSK") || map.getRiskParamName().equalsIgnoreCase("RB_CCR_PRHB_IP_PRM_NATONLY_RSK"))) {
/* 1416 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/* 1417 */           if (Parties != null) {
/* 1418 */             String concatCountries = "";
/* 1419 */             List<String> count = new ArrayList<String>();
/* 1420 */             if (VCustTypeName.compareTo("Organization") == 0 || VCustTypeName.compareTo("Financial Institution") == 0) {
/* 1421 */               for (InterestedParty party : Parties) {
/* 1422 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1423 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1424 */                 if ((RelationType.equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1425 */                   .equalsIgnoreCase("Shareholder-Govt") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1426 */                   .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1427 */                   .equalsIgnoreCase("UBO-Govt") && CustomerType.equalsIgnoreCase("ORG")))
/*      */                 {
/*      */                   
/* 1430 */                   count.add(party.getCustomerDetails().getPrimaryCitznCountry());
/*      */                 }
/*      */               } 
/*      */               
/* 1434 */               concatCountries = String.join(",", (Iterable)count);
/* 1435 */               pstmt1.setString(3, concatCountries);
/*      */             } else {
/* 1437 */               pstmt1.setString(3, (String)null);
/*      */             } 
/*      */           } else {
/* 1440 */             pstmt1.setString(3, (String)null);
/*      */           } 
/* 1442 */         } else if (map.getRiskParamTag().equalsIgnoreCase("InterestedParties.PrimaryCitznCountry")) {
/*      */           
/* 1444 */           int i = 0;
/* 1445 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/* 1446 */           if (Parties != null) {
/* 1447 */             String concatCountries = "";
/* 1448 */             List<String> count = new ArrayList<String>();
/* 1449 */             if (VCustTypeName.compareTo("Organization") == 0) {
/* 1450 */               for (InterestedParty party : Parties) {
/* 1451 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1452 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1453 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1454 */                   .equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1455 */                   .equalsIgnoreCase("Shareholder-Govt") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1456 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1457 */                   .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1458 */                   .equalsIgnoreCase("UBO-Govt") && CustomerType.equalsIgnoreCase("ORG"))) {
/* 1459 */                   count.add(party.getCustomerDetails().getPrimaryCitznCountry());
/*      */                 }
/*      */               } 
/* 1462 */               concatCountries = String.join(",", (Iterable)count);
/* 1463 */               pstmt1.setString(3, concatCountries);
/* 1464 */             } else if (VCustTypeName.compareTo("Financial Institution") == 0) {
/* 1465 */               if (map.getRiskParamName().equalsIgnoreCase("RB_CCR_ENT_INCORP_CNTRY") || map
/* 1466 */                 .getRiskParamName().equalsIgnoreCase("RB_CCR_PRHB_ENT_INCORP_CNTRY")) {
/* 1467 */                 String concat = "";
/* 1468 */                 for (InterestedParty party : Parties) {
/* 1469 */                   String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1470 */                   String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1471 */                   if ((RelationType.equalsIgnoreCase("Shareholder-Govt") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1472 */                     .equalsIgnoreCase("UBO-Govt") && CustomerType.equalsIgnoreCase("ORG")))
/*      */                   {
/* 1474 */                     count.add(party.getCustomerDetails().getPrimaryCitznCountry());
/*      */                   }
/*      */                 } 
/*      */                 
/* 1478 */                 concat = String.join(",", (Iterable)count);
/*      */                 
/* 1480 */                 pstmt1.setString(3, concat);
/*      */               } else {
/*      */                 
/* 1483 */                 for (InterestedParty party : Parties) {
/* 1484 */                   String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1485 */                   String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1486 */                   if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1487 */                     .equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1488 */                     .equalsIgnoreCase("Shareholder-Govt") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1489 */                     .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1490 */                     .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1491 */                     .equalsIgnoreCase("UBO-Govt") && CustomerType.equalsIgnoreCase("ORG"))) {
/* 1492 */                     count.add(party.getCustomerDetails().getPrimaryCitznCountry());
/*      */                   }
/*      */                 } 
/* 1495 */                 concatCountries = String.join(",", (Iterable)count);
/* 1496 */                 pstmt1.setString(3, concatCountries);
/*      */               } 
/*      */             } else {
/* 1499 */               pstmt1.setString(3, (String)null);
/*      */             } 
/*      */           } else {
/* 1502 */             pstmt1.setString(3, (String)null);
/*      */           } 
/* 1504 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Value2,Industry,InterestedParties.PrimaryCitznCountry,InterestedParties.SecondryCitznCountry")) {
/* 1505 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/* 1506 */           String concatCountries = "";
/* 1507 */           List<String> count = new ArrayList<String>();
/* 1508 */           List<String> SCount = new ArrayList<String>();
/* 1509 */           if (VCustTypeName.compareTo("Organization") == 0) {
/* 1510 */             if (Parties != null) {
/* 1511 */               String str = (String)((Parameter)AddParams.get(1)).getValue().get(0) + "," + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getIndustry() + ".";
/* 1512 */               for (InterestedParty party : Parties) {
/* 1513 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1514 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1515 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || RelationType
/* 1516 */                   .equalsIgnoreCase("AuthorizedSignatory") || RelationType
/* 1517 */                   .equalsIgnoreCase("POA") || (RelationType
/* 1518 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND"))) {
/* 1519 */                   count.add(party.getCustomerDetails().getPrimaryCitznCountry());
/* 1520 */                   str = str + party.getCustomerDetails().getPrimaryCitznCountry() + "," + party.getCustomerDetails().getSecondryCitznCountry() + ".";
/*      */                 } 
/*      */               } 
/* 1523 */               if (str.charAt(str.length() - 1) == '.') {
/* 1524 */                 str = str.substring(0, str.length() - 1);
/*      */               }
/* 1526 */               pstmt1.setString(3, str);
/*      */             } else {
/* 1528 */               String str = (String)((Parameter)AddParams.get(1)).getValue().get(0) + "," + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getIndustry() + ".,.,";
/* 1529 */               pstmt1.setString(3, str);
/*      */             }
/*      */           
/* 1532 */           } else if (VCustTypeName.compareTo("Financial Institution") == 0) {
/* 1533 */             if (Parties != null) {
/* 1534 */               String str = (String)((Parameter)AddParams.get(1)).getValue().get(0) + "," + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getIndustry() + ".";
/* 1535 */               for (InterestedParty party : Parties) {
/* 1536 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1537 */                 if (RelationType.equalsIgnoreCase("Shareholder") || RelationType.equalsIgnoreCase("UBO")) {
/* 1538 */                   str = str + party.getCustomerDetails().getPrimaryCitznCountry() + "," + party.getCustomerDetails().getSecondryCitznCountry() + ".";
/*      */                 }
/*      */               } 
/* 1541 */               if (str.charAt(str.length() - 1) == '.') {
/* 1542 */                 str = str.substring(0, str.length() - 1);
/*      */               }
/* 1544 */               pstmt1.setString(3, str);
/*      */             } else {
/* 1546 */               String str = (String)((Parameter)AddParams.get(1)).getValue().get(0) + "," + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getIndustry() + "..";
/* 1547 */               pstmt1.setString(3, str);
/*      */             } 
/*      */           } else {
/* 1550 */             pstmt1.setString(3, (String)null);
/*      */           } 
/* 1552 */         } else if (map.getRiskParamTag().equalsIgnoreCase("Value2,InterestedParties.PrimaryCitznCountry")) {
/* 1553 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/* 1554 */           if (VCustTypeName.compareTo("Organization") == 0) {
/* 1555 */             if (Parties != null) {
/* 1556 */               String str = (String)((Parameter)AddParams.get(1)).getValue().get(0) + ",";
/* 1557 */               for (InterestedParty party : Parties) {
/* 1558 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1559 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1560 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1561 */                   .equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1562 */                   .equalsIgnoreCase("Shareholder-Govt") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1563 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1564 */                   .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1565 */                   .equalsIgnoreCase("UBO-Govt") && CustomerType.equalsIgnoreCase("ORG"))) {
/* 1566 */                   str = str + party.getCustomerDetails().getPrimaryCitznCountry() + ",";
/*      */                 }
/*      */               } 
/* 1569 */               if (str.charAt(str.length() - 1) == ',') {
/* 1570 */                 str = str.substring(0, str.length() - 1);
/*      */               }
/* 1572 */               pstmt1.setString(3, str);
/*      */             } 
/* 1574 */           } else if (VCustTypeName.compareTo("Financial Institution") == 0) {
/* 1575 */             if (Parties != null) {
/* 1576 */               String str = (String)((Parameter)AddParams.get(1)).getValue().get(0) + ",";
/* 1577 */               for (InterestedParty party : Parties) {
/* 1578 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1579 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1580 */                 if ((RelationType.equalsIgnoreCase("Shareholder") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1581 */                   .equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1582 */                   .equalsIgnoreCase("Shareholder-Govt") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1583 */                   .equalsIgnoreCase("UBO") && CustomerType.equalsIgnoreCase("IND")) || (RelationType
/* 1584 */                   .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1585 */                   .equalsIgnoreCase("UBO-Govt") && CustomerType.equalsIgnoreCase("ORG"))) {
/* 1586 */                   str = str + party.getCustomerDetails().getPrimaryCitznCountry() + ",";
/*      */                 }
/*      */               } 
/* 1589 */               if (str.charAt(str.length() - 1) == ',') {
/* 1590 */                 str = str.substring(0, str.length() - 1);
/*      */               }
/* 1592 */               pstmt1.setString(3, str);
/*      */             } 
/*      */           } else {
/* 1595 */             pstmt1.setString(3, (String)null);
/*      */           } 
/* 1597 */         } else if (map.getRiskParamTag().equalsIgnoreCase("InterestedParties.Value43,InterestedParties.PrimaryCitznCountry")) {
/* 1598 */           ArrayList<InterestedParty> Parties = requestObj.getRaorRequest().getCustomer().getInterestedParties().getInterestedParty();
/* 1599 */           String concat = "";
/* 1600 */           List<String> count = new ArrayList<String>();
/* 1601 */           if (VCustTypeName.compareTo("Organization") == 0 || VCustTypeName.compareTo("Financial Institution") == 0)
/*      */           {
/* 1603 */             if (Parties != null) {
/* 1604 */               for (InterestedParty party : Parties) {
/* 1605 */                 String RelationType = ((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0);
/* 1606 */                 String CustomerType = party.getCustomerDetails().getCustomerType();
/* 1607 */                 if ((RelationType.equalsIgnoreCase("Shareholder-Govt") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1608 */                   .equalsIgnoreCase("UBO-Govt") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1609 */                   .equalsIgnoreCase("Shareholder-Owning") && CustomerType.equalsIgnoreCase("ORG")) || (RelationType
/* 1610 */                   .equalsIgnoreCase("UBO-Entity") && CustomerType.equalsIgnoreCase("ORG"))) {
/* 1611 */                   count.add(((Parameter)party.getAdditionalParameters().getParameter().get(42)).getValue().get(0));
/* 1612 */                   count.add(party.getCustomerDetails().getPrimaryCitznCountry());
/*      */                 } 
/*      */               } 
/* 1615 */               concat = String.join(",", (Iterable)count);
/*      */             } 
/* 1617 */             pstmt1.setString(3, concat);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1640 */         else if (map.getRiskParamTag().contains("Value")) {
/* 1641 */           for (int i = 0; i < requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().size(); i++) {
/* 1642 */             pstmt1.setString(3, (String)null);
/* 1643 */             if (map.getRiskParamTag().equalsIgnoreCase("Value" + (i + 1))) {
/* 1644 */               pstmt1.setString(3, ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(i)).getValue().get(0));
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } 
/* 1649 */         pstmt1.setString(4, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/* 1650 */         pstmt1.setString(5, VCustTypeName);
/* 1651 */         pstmt1.setLong(6, Long.parseLong(this.custIDs.get("raorRequestID")));
/* 1652 */         pstmt1.addBatch();
/*      */       } 
/* 1654 */       pstmt1.executeBatch();
/* 1655 */       conn.commit();
/* 1656 */       pstmt1.close();
/* 1657 */       conn.setAutoCommit(true);
/* 1658 */       conn.close();
/* 1659 */     } catch (Exception ex) {
/* 1660 */       Log4j.getLog().info(ex.toString());
/* 1661 */       throw ex;
/*      */     } 
/* 1663 */     Log4j.getLog().info("This is INSERT_OVERRIDE_PROHIBITS function ends");
/*      */   }
/*      */   
/*      */   public HashMap<String, String> insertRAORInfoToDB(NewFields requestObj) throws Exception {
/* 1667 */     Log4j.getLog().info("This is insertRAORInfoToDB function starts");
/*      */     try {
/* 1669 */       String CustType = requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerType();
/* 1670 */       String CustStatus = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(38)).getValue().get(0);
/* 1671 */       INSERT_TECHX_CUSTOM(requestObj);
/*      */       
/* 1673 */       if (CustType.compareTo("ORG") == 0) {
/* 1674 */         Log4j.getLog().info("This is Organization Cutomer");
/* 1675 */         String VCustTypeName = "Organization";
/* 1676 */         if (CustStatus.compareTo("EXISTING") == 0) {
/* 1677 */           INSERT_RISK_FACTOR(requestObj, "2", CustStatus, VCustTypeName);
/* 1678 */           INSERT_CUSTOMER_TYPE_RISK(requestObj, "2", CustStatus, VCustTypeName);
/* 1679 */           INSERT_TRANSACTION_RISK(requestObj, "2", VCustTypeName);
/*      */         } else {
/* 1681 */           INSERT_RISK_FACTOR(requestObj, "2", CustStatus + "," + (String)((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(40)).getValue().get(0), VCustTypeName);
/* 1682 */           INSERT_CUSTOMER_TYPE_RISK(requestObj, "2", CustStatus + "," + (String)((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(40)).getValue().get(0), VCustTypeName);
/*      */         } 
/* 1684 */         INSERT_GEOGRAPHY_TYPE_RISK(requestObj, "2", ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(40)).getValue().get(0), VCustTypeName);
/* 1685 */         INSERT_CHANNEL_RISK(requestObj, "2", ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(40)).getValue().get(0), VCustTypeName);
/* 1686 */         INSERT_OVERRIDE_PROHIBITS(requestObj, "2", "OVERRIDE", VCustTypeName);
/* 1687 */         INSERT_OVERRIDE_PROHIBITS(requestObj, "2", "PROHIBIT", VCustTypeName);
/*      */       }
/* 1689 */       else if (CustType.compareTo("IND") == 0) {
/*      */         
/* 1691 */         Log4j.getLog().info("This is Individual Cutomer");
/* 1692 */         String VCustTypeName = "Individual";
/* 1693 */         INSERT_RISK_FACTOR(requestObj, "1", CustStatus, VCustTypeName);
/* 1694 */         INSERT_CUSTOMER_TYPE_RISK(requestObj, "1", "", VCustTypeName);
/* 1695 */         INSERT_GEOGRAPHY_TYPE_RISK(requestObj, "1", "", VCustTypeName);
/* 1696 */         if (CustStatus.equalsIgnoreCase("EXISTING")) {
/* 1697 */           INSERT_TRANSACTION_RISK(requestObj, "1", VCustTypeName);
/*      */         }
/* 1699 */         INSERT_CHANNEL_RISK(requestObj, "1", "", VCustTypeName);
/* 1700 */         INSERT_OVERRIDE_PROHIBITS(requestObj, "1", "OVERRIDE", VCustTypeName);
/* 1701 */         INSERT_OVERRIDE_PROHIBITS(requestObj, "1", "PROHIBIT", VCustTypeName);
/*      */       }
/* 1703 */       else if (CustType.compareTo("FIN") == 0) {
/*      */         
/* 1705 */         Log4j.getLog().info("This is Financial Institution Cutomer");
/* 1706 */         String VCustTypeName = "Financial Institution";
/* 1707 */         String vStatus = null;
/* 1708 */         Connection conStat = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/* 1709 */         String status = ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(43)).getValue().get(0);
/* 1710 */         PreparedStatement pstmtStatus = conStat.prepareStatement("SELECT FI_STAT_SET_NO FROM FINANCIAL_INSTITUTION_RISK_PARAM_SET WHERE RISK_FACTOR= ?");
/* 1711 */         pstmtStatus.setString(1, status);
/* 1712 */         ResultSet rstatus = pstmtStatus.executeQuery();
/* 1713 */         while (rstatus.next()) {
/* 1714 */           vStatus = rstatus.getString(1);
/*      */         }
/* 1716 */         pstmtStatus.close();
/* 1717 */         conStat.close();
/*      */         
/* 1719 */         INSERT_RISK_FACTOR(requestObj, "3", vStatus, VCustTypeName);
/* 1720 */         INSERT_CUSTOMER_TYPE_RISK(requestObj, "3", ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(43)).getValue().get(0), VCustTypeName);
/* 1721 */         INSERT_GEOGRAPHY_TYPE_RISK(requestObj, "3", ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(43)).getValue().get(0), VCustTypeName);
/* 1722 */         INSERT_PRODUCT_RISK(requestObj, "3", ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(43)).getValue().get(0), VCustTypeName);
/* 1723 */         INSERT_SYSTEM_CONTOL_RISK(requestObj, "3", ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(43)).getValue().get(0), VCustTypeName);
/* 1724 */         INSERT_OVERRIDE_PROHIBITS(requestObj, "3", "OVERRIDE", VCustTypeName);
/* 1725 */         INSERT_OVERRIDE_PROHIBITS(requestObj, "3", "PROHIBIT", VCustTypeName);
/*      */       }
/*      */     
/* 1728 */     } catch (Exception e) {
/* 1729 */       throw e;
/*      */     } 
/* 1731 */     Log4j.getLog().info("This is insertRAORInfoToDB function ends");
/* 1732 */     return this.custIDs;
/*      */   }
/*      */   
/*      */   public String[] getRiskScore(HashMap<String, String> custIDs, String requestRAORID) throws Exception {
/* 1736 */     Log4j.getLog().info("This is getRiskScore function starts");
/* 1737 */     CallableStatement stmt = null;
/* 1738 */     String[] riskScoreAndCategory = new String[2];
/* 1739 */     String[] maxRiskScore = new String[4];
/* 1740 */     float riskscore = 0.0F;
/* 1741 */     String caseRefNo = custIDs.get("caseRefNo");
/* 1742 */     custIDs.remove("caseRefNo");
/*      */     
/*      */     try {
/* 1745 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/* 1746 */       for (Map.Entry<String, String> m : custIDs.entrySet()) {
/*      */         
/* 1748 */         stmt = conn.prepareCall("{? = call FN_RAOR_PROCESS_TECHLX_CUSTOM(?,?,?)}");
/* 1749 */         stmt.setString(2, m.getValue());
/* 1750 */         stmt.setString(3, caseRefNo);
/* 1751 */         stmt.setInt(4, Integer.parseInt(requestRAORID));
/* 1752 */         stmt.registerOutParameter(1, 12);
/* 1753 */         stmt.execute();
/*      */         
/* 1755 */         riskScoreAndCategory = stmt.getString(1).split(",");
/* 1756 */         Log4j.getLog().info("CustomerID: " + ((String)m.getValue()).toString() + ",RiskScore: " + Float.parseFloat(riskScoreAndCategory[0]) + ",Category: " + riskScoreAndCategory[1]);
/* 1757 */         if (riskscore <= Float.parseFloat(riskScoreAndCategory[0])) {
/*      */           
/* 1759 */           riskscore = Float.parseFloat(riskScoreAndCategory[0]);
/* 1760 */           maxRiskScore[0] = String.valueOf(riskscore);
/* 1761 */           maxRiskScore[1] = riskScoreAndCategory[1];
/* 1762 */           maxRiskScore[2] = ((String)m.getValue()).toString();
/* 1763 */           maxRiskScore[3] = caseRefNo;
/*      */         } 
/*      */       } 
/* 1766 */       Log4j.getLog().info("MaxScore:" + maxRiskScore[0]);
/* 1767 */       Log4j.getLog().info("MaxScore Category:" + maxRiskScore[1]);
/*      */       
/* 1769 */       stmt.close();
/* 1770 */       conn.close();
/* 1771 */     } catch (Exception ex) {
/* 1772 */       throw ex;
/*      */     } 
/*      */     
/* 1775 */     Log4j.getLog().info("This is getRiskScore function ends");
/* 1776 */     return maxRiskScore;
/*      */   }
/*      */   
/*      */   public void updateRAORResponseToDB(String[] response, String requestRAORID) throws Exception {
/* 1780 */     Log4j.getLog().info("This is updateRAORResponseToDB function starts");
/* 1781 */     PreparedStatement pstmt = null;
/* 1782 */     String sql = "";
/*      */     
/*      */     try {
/* 1785 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/*      */       
/* 1787 */       sql = "UPDATE FCT_TP_RAOR_TECHX_CUSTOM set response_fic_mis_date = SYSDATE, n_risk_score = ?, v_risk_category = ?  WHERE n_raor_req_id = ?";
/*      */       
/* 1789 */       pstmt = conn.prepareStatement(sql);
/* 1790 */       pstmt.setString(1, response[0]);
/* 1791 */       pstmt.setString(2, response[1]);
/* 1792 */       pstmt.setInt(3, Integer.parseInt(requestRAORID));
/*      */       
/* 1794 */       pstmt.executeQuery();
/* 1795 */       pstmt.close();
/* 1796 */       conn.close();
/* 1797 */     } catch (Exception ex) {
/* 1798 */       throw ex;
/*      */     } 
/*      */     
/* 1801 */     Log4j.getLog().info("This is updateRAORResponseToDB function ends");
/*      */   }
/*      */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\DAO\KYCData\KYCDataOperations.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */