/*     */ package WEB-INF.classes.DAO.FATCAData;
/*     */ 
/*     */ import BO.NewFields.NewFields;
/*     */ import BO.RAOR.Address;
/*     */ import BO.RAOR.InterestedParty;
/*     */ import BO.RAOR.Parameter;
/*     */ import BO.RAOR.Phone;
/*     */ import BO.RAOR.RAORRequest;
/*     */ import BO.RAOR.XmlMapping_FT;
/*     */ import Database.JNDIConnector;
/*     */ import Logging.Log4j;
/*     */ import Utilities.GetDate;
/*     */ import Utilities.LoadProperties;
/*     */ import Utilities.StringOps;
/*     */ import Utilities.XmlParser;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class FATCADataOperations
/*     */ {
/*  27 */   XmlParser p = new XmlParser();
/*  28 */   StringOps strOps = new StringOps();
/*  29 */   GetDate getDate = new GetDate();
/*  30 */   int OwnershipPerc = 0;
/*  31 */   String CUST_TYPE_KEY = "";
/*  32 */   Map<String, String> CUST_TYPE_KEY_SH = new HashMap<String, String>();
/*     */   
/*     */   public NewFields loadNewField(String xml) throws Exception {
/*  35 */     Log4j.getLog().info("This is fatca load new fields function starts");
/*  36 */     String returnedXml = null;
/*  37 */     NewFields newFields_FT = new NewFields();
/*     */     
/*     */     try {
/*  40 */       String nameSpaceToBeRemoved = LoadProperties.getConf().getProperty("kyc.service.namespace.request.xml");
/*  41 */       xml = this.strOps.removeNamespace(xml, nameSpaceToBeRemoved);
/*     */       
/*  43 */       RAORRequest requestRAOR = (RAORRequest)this.p.unmarshalXMl(xml, "RAORRequest");
/*     */       
/*  45 */       if (requestRAOR.getCustomer().getInterestedParties().getInterestedParty() != null && requestRAOR.getCustomer().getInterestedParties().getInterestedParty().size() > 0) {
/*  46 */         newFields_FT.setInterestedParty(requestRAOR.getCustomer().getInterestedParties().getInterestedParty());
/*     */       }
/*  48 */       if (requestRAOR.getCustomer().getAdditionalParameters().getParameter().size() > 0) {
/*  49 */         newFields_FT.setParamValues(requestRAOR.getCustomer().getAdditionalParameters().getParameter());
/*     */       }
/*     */       
/*  52 */       returnedXml = this.p.convertoXML(requestRAOR, "RAORRequest");
/*  53 */       returnedXml = this.strOps.removeNs2(returnedXml);
/*     */       
/*  55 */       newFields_FT.setXml(returnedXml);
/*     */       
/*  57 */       newFields_FT.setRaorRequest(requestRAOR);
/*  58 */     } catch (Exception ex) {
/*     */       
/*  60 */       throw ex;
/*     */     } 
/*     */     
/*  63 */     Log4j.getLog().info("This is fatca load new fields function ends");
/*  64 */     return newFields_FT;
/*     */   }
/*     */   
/*     */   public ArrayList<XmlMapping_FT> loadXMLTagMapping() throws Exception {
/*  68 */     Log4j.getLog().info("This is loadXMLTagMapping function starts");
/*  69 */     ArrayList<XmlMapping_FT> mappings_FT = new ArrayList<XmlMapping_FT>();
/*     */     
/*     */     try {
/*  72 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi2.name"));
/*  73 */       Statement s = null;
/*  74 */       s = conn.createStatement();
/*  75 */       s.execute("SELECT   a.V_RULE_GRP_NM, a.N_RISK_PARAM_CODE, a.n_risk_param_desc, a.n_risk_param_tag,         b.v_cust_type_code, b.n_cust_type_key,         c.V_RULE_OPT, c.V_RULE_TX_VAL, c.F_RULE_ENBL_FL    FROM FCT_TP_RAOR_PARAMS_MAP_FT_THX_CSM a LEFT JOIN dim_customer_type b         ON a.N_FOCUS_CUST_TYPE_KEY = b.n_cust_type_key         LEFT JOIN FATCA_ASSESSMENT_RULES c         ON a.N_RISK_PARAM_DESC = c.V_RULE_DESC         AND a.V_RULE_GRP_NM = c.V_RULE_GRP_NM         AND c.V_JRSDCN_CD = 'D'         AND c.V_BUS_DMN = 'D'         AND c.V_GEO_JRSDCN_CD ='D'ORDER BY a.n_risk_param_tag");
/*     */       
/*  77 */       ResultSet rs = s.getResultSet();
/*     */       
/*  79 */       while (rs.next()) {
/*     */         
/*  81 */         XmlMapping_FT xmlMapping_FT = new XmlMapping_FT();
/*  82 */         xmlMapping_FT.setRuleGrpNm(rs.getString("V_RULE_GRP_NM"));
/*  83 */         xmlMapping_FT.setRiskParamDesc(rs.getString("n_risk_param_desc"));
/*  84 */         xmlMapping_FT.setRiskParamCode(rs.getString("N_RISK_PARAM_CODE"));
/*  85 */         xmlMapping_FT.setRiskParamTag(rs.getString("n_risk_param_tag"));
/*  86 */         xmlMapping_FT.setRuleOpt(rs.getString("V_RULE_OPT"));
/*  87 */         xmlMapping_FT.setRuleTxVal(rs.getString("V_RULE_TX_VAL"));
/*  88 */         xmlMapping_FT.setCustomerTypeKey(rs.getString("n_cust_type_key"));
/*  89 */         xmlMapping_FT.setRuleEnblFl(rs.getString("F_RULE_ENBL_FL"));
/*  90 */         xmlMapping_FT.setCustomerType(rs.getString("v_cust_type_code"));
/*  91 */         mappings_FT.add(xmlMapping_FT);
/*     */       } 
/*     */       
/*  94 */       rs.close();
/*  95 */       s.close();
/*  96 */       conn.close();
/*  97 */     } catch (Exception ex) {
/*  98 */       throw ex;
/*     */     } 
/*     */     
/* 101 */     Log4j.getLog().info("This is loadXMLTagMapping function ends");
/* 102 */     return mappings_FT;
/*     */   }
/*     */   
/*     */   public HashMap<String, String> insertRAORInfoToDB(ArrayList<XmlMapping_FT> mappings_FT, NewFields requestObj) throws Exception {
/* 106 */     Log4j.getLog().info("This is insertRAORInfoToDB function starts");
/*     */     
/* 108 */     String customerType = "";
/* 109 */     String sql = "";
/* 110 */     int j = 0;
/* 111 */     String caseRefNo = "CASE" + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber() + this.getDate.GetDate("yyyyMMdd");
/* 112 */     PreparedStatement pstmt1 = null;
/* 113 */     String values = "";
/* 114 */     HashMap<String, String> custIDs_FT = new HashMap<String, String>();
/* 115 */     Long raorRequestID = null;
/*     */     
/*     */     try {
/* 118 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi2.name"));
/* 119 */       conn.setAutoCommit(false);
/*     */       
/* 121 */       String sql1 = "INSERT INTO FCT_TP_RAOR_REASONS_FT_TECHX_CSTM(n_raor_reason_id,n_raor_case_ref,V_RULE_GRP_NM,N_RISK_PARAM_NAME,V_RULE_OPT,V_RULE_TX_VAL,F_RULE_ENBL_FL,N_RISK_PARAM_VALUE,v_ra_cust_number,v_cust_type_name,n_raor_req_id) values(seq_FCT_TP_RAOR_REASONS_FT_TECHX.nextval,?,?,?,?,?,?,?,?,?,?)";
/*     */       
/* 123 */       pstmt1 = conn.prepareStatement(sql1);
/*     */       
/* 125 */       customerType = requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerType();
/*     */       
/* 127 */       Log4j.getLog().info("starting getting fatca key for main customer");
/* 128 */       Log4j.getLog().info("Customer type for main customer is: " + customerType);
/* 129 */       Connection keyconn1 = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/* 130 */       keyconn1.setAutoCommit(false);
/* 131 */       this.CUST_TYPE_KEY = "";
/* 132 */       Log4j.getLog().info("fatca before getting from db key for main customer is: " + this.CUST_TYPE_KEY);
/* 133 */       String sql2 = "SELECT N_CUST_TYPE_KEY FROM DIM_CUSTOMER_TYPE WHERE V_CUST_TYPE_CODE= ?";
/* 134 */       PreparedStatement keypstmt4 = null;
/* 135 */       keypstmt4 = keyconn1.prepareStatement(sql2);
/* 136 */       keypstmt4.setString(1, customerType);
/* 137 */       keypstmt4.executeQuery();
/* 138 */       ResultSet keyrs = keypstmt4.getResultSet();
/* 139 */       while (keyrs.next()) {
/* 140 */         this.CUST_TYPE_KEY = keyrs.getString(1);
/*     */       }
/* 142 */       Log4j.getLog().info("fatca key for main customer is: " + this.CUST_TYPE_KEY);
/* 143 */       keyrs.close();
/* 144 */       keypstmt4.close();
/* 145 */       keyconn1.close();
/*     */       
/* 147 */       custIDs_FT.put("caseRefNo", caseRefNo);
/* 148 */       custIDs_FT.put("0-custID", requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/*     */       
/* 150 */       for (XmlMapping_FT map : mappings_FT) {
/*     */         
/* 152 */         Log4j.getLog().info("map. customer type key is: " + map.getCustomerTypeKey());
/* 153 */         if (map.getCustomerTypeKey().equalsIgnoreCase(this.CUST_TYPE_KEY)) {
/*     */           
/* 155 */           if (j == 0) {
/*     */             
/* 157 */             sql = "INSERT INTO FCT_TP_CUST_RAOR_THX_CUSTOM(n_raor_req_id,request_fic_mis_date, n_case_ref,v_ra_cust_number,V_RG_CUST_TYPE_CD) values(SEQ_FCT_TP_CUST_RAOR_THX_CSM.nextval,SYSDATE,?,?,?)";
/*     */             
/* 159 */             PreparedStatement pstmt2 = conn.prepareStatement(sql, new String[] { "n_raor_req_id" });
/*     */             
/* 161 */             pstmt2.setString(1, caseRefNo);
/* 162 */             pstmt2.setString(2, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/* 163 */             pstmt2.setString(3, map.getCustomerType());
/*     */             
/* 165 */             pstmt2.executeQuery();
/* 166 */             conn.commit();
/*     */             
/* 168 */             ResultSet raorReqID = pstmt2.getGeneratedKeys();
/* 169 */             if (raorReqID.next()) {
/*     */               
/* 171 */               raorRequestID = Long.valueOf(raorReqID.getLong(1));
/* 172 */               custIDs_FT.put("raorRequestID", raorRequestID.toString());
/*     */             } 
/* 174 */             pstmt2.close();
/* 175 */             j = 1;
/*     */           } 
/*     */           
/* 178 */           if (this.CUST_TYPE_KEY.equalsIgnoreCase("1")) {
/*     */             
/* 180 */             pstmt1.setString(1, caseRefNo);
/* 181 */             pstmt1.setString(2, map.getRuleGrpNm());
/* 182 */             pstmt1.setString(3, map.getRiskParamDesc());
/* 183 */             pstmt1.setString(4, map.getRuleOpt());
/* 184 */             pstmt1.setString(5, map.getRuleTxVal());
/* 185 */             pstmt1.setString(6, map.getRuleEnblFl());
/* 186 */             if (map.getRiskParamTag().equalsIgnoreCase("PrimaryCitznCountry")) {
/*     */               
/* 188 */               pstmt1.setString(7, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getPrimaryCitznCountry());
/* 189 */             } else if (map.getRiskParamTag().equalsIgnoreCase("SecondryCitznCountry")) {
/*     */               
/* 191 */               pstmt1.setString(7, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getSecondryCitznCountry());
/* 192 */             } else if (map.getRiskParamTag().equalsIgnoreCase("ResidenceCountry")) {
/*     */               
/* 194 */               pstmt1.setString(7, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getResidenceCountry());
/* 195 */             } else if (map.getRiskParamTag().equalsIgnoreCase("PhoneCountry")) {
/*     */               
/* 197 */               values = "";
/* 198 */               for (int i = 0; i < requestObj.getRaorRequest().getCustomer().getPhones().getPhone().size(); i++) {
/* 199 */                 values = values + ((Phone)requestObj.getRaorRequest().getCustomer().getPhones().getPhone().get(i)).getPhoneCountry() + ",";
/*     */               }
/* 201 */               values = values.substring(0, values.length() - 1);
/* 202 */               pstmt1.setString(7, values);
/* 203 */             } else if (map.getRiskParamTag().equalsIgnoreCase("AddressCountry")) {
/*     */               
/* 205 */               values = "";
/* 206 */               for (int i = 0; i < requestObj.getRaorRequest().getCustomer().getAddresses().getAddress().size(); i++) {
/* 207 */                 values = values + ((Address)requestObj.getRaorRequest().getCustomer().getAddresses().getAddress().get(i)).getAddressCountry() + ",";
/*     */               }
/* 209 */               values = values.substring(0, values.length() - 1);
/* 210 */               pstmt1.setString(7, values);
/* 211 */             } else if (map.getRiskParamTag().equalsIgnoreCase("MailHandingInstruction")) {
/*     */               
/* 213 */               values = "";
/* 214 */               for (int i = 0; i < requestObj.getRaorRequest().getCustomer().getAddresses().getAddress().size(); i++) {
/* 215 */                 values = values + ((Address)requestObj.getRaorRequest().getCustomer().getAddresses().getAddress().get(i)).getMailHandingInstruction() + ",";
/*     */               }
/* 217 */               values = values.substring(0, values.length() - 1);
/* 218 */               pstmt1.setString(7, values);
/* 219 */             } else if (map.getRiskParamTag().contains("Value")) {
/*     */               
/* 221 */               for (int i = 9; i < requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().size(); i++) {
/*     */                 
/* 223 */                 pstmt1.setString(7, "None");
/* 224 */                 if (map.getRiskParamTag().equalsIgnoreCase("Value" + (i + 1))) {
/*     */                   
/* 226 */                   pstmt1.setString(7, ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(i)).getValue().get(0));
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             } 
/* 231 */             pstmt1.setString(8, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/* 232 */             pstmt1.setString(9, "Individual");
/* 233 */             pstmt1.setLong(10, raorRequestID.longValue());
/* 234 */             pstmt1.addBatch();
/*     */             
/*     */             continue;
/*     */           } 
/* 238 */           pstmt1.setString(1, caseRefNo);
/* 239 */           pstmt1.setString(2, map.getRuleGrpNm());
/* 240 */           pstmt1.setString(3, map.getRiskParamDesc());
/* 241 */           pstmt1.setString(4, map.getRuleOpt());
/* 242 */           pstmt1.setString(5, map.getRuleTxVal());
/* 243 */           pstmt1.setString(6, map.getRuleEnblFl());
/* 244 */           if (map.getRiskParamTag().equalsIgnoreCase("AddressCountry")) {
/*     */             
/* 246 */             values = "";
/* 247 */             for (int i = 0; i < requestObj.getRaorRequest().getCustomer().getAddresses().getAddress().size(); i++) {
/*     */               
/* 249 */               if (((Address)requestObj.getRaorRequest().getCustomer().getAddresses().getAddress().get(i)).getAddressType().equalsIgnoreCase("B") || ((Address)requestObj
/* 250 */                 .getRaorRequest().getCustomer().getAddresses().getAddress().get(i)).getAddressType().equalsIgnoreCase("P")) {
/* 251 */                 values = values + ((Address)requestObj.getRaorRequest().getCustomer().getAddresses().getAddress().get(i)).getAddressCountry() + ",";
/*     */               }
/*     */             } 
/*     */             
/* 255 */             if (values == "") {
/* 256 */               values = "None,";
/*     */             }
/* 258 */             values = values.substring(0, values.length() - 1);
/* 259 */             pstmt1.setString(7, values);
/* 260 */           } else if (map.getRiskParamTag().equalsIgnoreCase("PhoneCountry")) {
/*     */             
/* 262 */             values = "";
/* 263 */             for (int i = 0; i < requestObj.getRaorRequest().getCustomer().getPhones().getPhone().size(); i++) {
/* 264 */               values = values + ((Phone)requestObj.getRaorRequest().getCustomer().getPhones().getPhone().get(i)).getPhoneCountry() + ",";
/*     */             }
/* 266 */             values = values.substring(0, values.length() - 1);
/* 267 */             pstmt1.setString(7, values);
/* 268 */           } else if (map.getRiskParamTag().equalsIgnoreCase("PhoneCountry-F")) {
/*     */             
/* 270 */             values = "";
/* 271 */             for (int i = 0; i < requestObj.getRaorRequest().getCustomer().getPhones().getPhone().size(); i++) {
/*     */               
/* 273 */               if (((Phone)requestObj.getRaorRequest().getCustomer().getPhones().getPhone().get(i)).getPhoneType().equalsIgnoreCase("F")) {
/* 274 */                 values = values + ((Phone)requestObj.getRaorRequest().getCustomer().getPhones().getPhone().get(i)).getPhoneCountry() + ",";
/*     */               }
/*     */             } 
/*     */             
/* 278 */             if (values == "") {
/* 279 */               values = "None,";
/*     */             }
/* 281 */             values = values.substring(0, values.length() - 1);
/* 282 */             pstmt1.setString(7, values);
/* 283 */           } else if (map.getRiskParamTag().equalsIgnoreCase("MailHandingInstruction")) {
/*     */             
/* 285 */             values = "";
/* 286 */             for (int i = 0; i < requestObj.getRaorRequest().getCustomer().getAddresses().getAddress().size(); i++) {
/* 287 */               values = values + ((Address)requestObj.getRaorRequest().getCustomer().getAddresses().getAddress().get(i)).getMailHandingInstruction() + ",";
/*     */             }
/* 289 */             values = values.substring(0, values.length() - 1);
/* 290 */             pstmt1.setString(7, values);
/* 291 */           } else if (map.getRiskParamTag().contains("Value")) {
/*     */             
/* 293 */             for (int i = 13; i < requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().size(); i++) {
/*     */               
/* 295 */               pstmt1.setString(7, "None");
/* 296 */               if (map.getRiskParamTag().equalsIgnoreCase("Value" + (i + 1))) {
/*     */                 
/* 298 */                 pstmt1.setString(7, ((Parameter)requestObj.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(i)).getValue().get(0));
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */           } 
/* 303 */           pstmt1.setString(8, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/* 304 */           pstmt1.setString(9, "Legal Entity");
/* 305 */           pstmt1.setLong(10, raorRequestID.longValue());
/* 306 */           pstmt1.addBatch();
/*     */         } 
/*     */       } 
/*     */       
/* 310 */       pstmt1.executeBatch();
/* 311 */       conn.commit();
/* 312 */       pstmt1.close();
/*     */       
/* 314 */       if (requestObj.getInterestedParty() != null && requestObj.getInterestedParty().size() > 0) {
/*     */         
/* 316 */         PreparedStatement pstmt3 = conn.prepareStatement("SELECT N_SUB_PARAM_NB_1_VAL FROM FATCA_SETUP_PARAMS WHERE V_PARAM_CD = 'Ownership_Params'");
/* 317 */         ResultSet rs = pstmt3.executeQuery();
/* 318 */         while (rs.next()) {
/* 319 */           this.OwnershipPerc = Integer.parseInt(rs.getString(1));
/*     */         }
/* 321 */         rs.close();
/* 322 */         Log4j.getLog().info("Ownership perc 11" + this.OwnershipPerc);
/*     */         
/* 324 */         for (int i = 0; i < requestObj.getInterestedParty().size(); i++) {
/*     */           
/* 326 */           custIDs_FT.put((i + 1) + "-SH", ((InterestedParty)requestObj.getInterestedParty().get(i)).getCustomerDetails().getCustomerIdNumber());
/* 327 */           if (Double.parseDouble(((InterestedParty)requestObj.getInterestedParty().get(i)).getCustomerRelationships().getCustomerRelation().getOwnershipPercentage()) > this.OwnershipPerc) {
/* 328 */             insertShareholdersInfoToDB(requestObj.getInterestedParty().get(i), caseRefNo, conn, mappings_FT, raorRequestID, i + 1, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 333 */       conn.setAutoCommit(true);
/* 334 */       conn.close();
/* 335 */     } catch (Exception ex) {
/*     */       
/* 337 */       throw ex;
/*     */     } 
/* 339 */     Log4j.getLog().info("This is insertRAORInfoToDB function ends");
/* 340 */     return custIDs_FT;
/*     */   }
/*     */   
/*     */   public void insertShareholdersInfoToDB(InterestedParty interestedParty, String caseRefNo, Connection conn, ArrayList<XmlMapping_FT> mappings_FT, Long raorRequestID, int shNum, String customerId) throws Exception {
/* 344 */     Log4j.getLog().info("This is insertShareholdersInfoToDB function starts");
/* 345 */     String customerType = "";
/* 346 */     PreparedStatement pstmt1 = null;
/* 347 */     String values = "";
/*     */     
/* 349 */     int j = 0;
/*     */     
/*     */     try {
/* 352 */       String sql1 = "INSERT INTO FCT_TP_RAOR_REASONS_FT_TECHX_CSTM(n_raor_reason_id,n_raor_case_ref,V_RULE_GRP_NM,N_RISK_PARAM_NAME,V_RULE_OPT,V_RULE_TX_VAL,F_RULE_ENBL_FL,N_RISK_PARAM_VALUE,v_ra_cust_number,v_cust_type_name,n_raor_req_id,is_shareholder) values(seq_FCT_TP_RAOR_REASONS_FT_TECHX.nextval,?,?,?,?,?,?,?,?,?,?,?)";
/*     */       
/* 354 */       pstmt1 = conn.prepareStatement(sql1);
/*     */       
/* 356 */       customerType = interestedParty.getCustomerDetails().getCustomerType();
/* 357 */       Log4j.getLog().info("customer type of sharholde: " + customerType);
/*     */       
/* 359 */       Log4j.getLog().info("starting get shareholder fatca keyy");
/* 360 */       Connection keyconn2 = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/* 361 */       keyconn2.setAutoCommit(false);
/* 362 */       this.CUST_TYPE_KEY_SH.put(interestedParty.getCustomerDetails().getCustomerIdNumber(), "");
/* 363 */       Log4j.getLog().info(" befire getting key fatca shareholder key: " + (String)this.CUST_TYPE_KEY_SH.get(interestedParty.getCustomerDetails().getCustomerIdNumber()));
/* 364 */       String sql3 = "SELECT N_CUST_TYPE_KEY FROM DIM_CUSTOMER_TYPE WHERE V_CUST_TYPE_CODE= ?";
/* 365 */       PreparedStatement keypstmt5 = null;
/* 366 */       keypstmt5 = keyconn2.prepareStatement(sql3);
/* 367 */       keypstmt5.setString(1, customerType);
/* 368 */       keypstmt5.executeQuery();
/* 369 */       ResultSet keyrs1 = keypstmt5.getResultSet();
/* 370 */       Log4j.getLog().info("inerested part sh customeridnumber: " + interestedParty.getCustomerDetails().getCustomerIdNumber());
/* 371 */       while (keyrs1.next())
/*     */       {
/* 373 */         this.CUST_TYPE_KEY_SH.put(interestedParty.getCustomerDetails().getCustomerIdNumber(), keyrs1.getString(1));
/*     */       }
/*     */       
/* 376 */       Log4j.getLog().info("shareholder key: " + (String)this.CUST_TYPE_KEY_SH.get(interestedParty.getCustomerDetails().getCustomerIdNumber()));
/* 377 */       keyrs1.close();
/* 378 */       keypstmt5.close();
/* 379 */       keyconn2.close();
/*     */       
/* 381 */       for (XmlMapping_FT map : mappings_FT) {
/*     */         
/* 383 */         if (map.getCustomerTypeKey().equalsIgnoreCase(this.CUST_TYPE_KEY_SH.get(interestedParty.getCustomerDetails().getCustomerIdNumber()))) {
/*     */           
/* 385 */           if (j == 0) {
/*     */             
/* 387 */             String sql = "INSERT INTO FCT_TP_SH_RAOR_THX_CUSTOM(n_raor_req_id, FIC_MIS_DATE, n_case_ref,V_RA_SH_NUMBER, N_RAOR_REQ_ID_CUST,V_RA_CUST_NUMBER,V_RG_CUST_TYPE_CD) values(SEQ_FCT_TP_SH_RAOR_THX_CUSTOM.nextval,SYSDATE,?,?,?,?,?)";
/*     */             
/* 389 */             PreparedStatement pstmt = conn.prepareStatement(sql);
/* 390 */             pstmt.setString(1, caseRefNo);
/* 391 */             pstmt.setString(2, interestedParty.getCustomerDetails().getCustomerIdNumber());
/* 392 */             pstmt.setLong(3, raorRequestID.longValue());
/* 393 */             pstmt.setString(4, customerId);
/* 394 */             pstmt.setString(5, customerType);
/* 395 */             pstmt.executeQuery();
/* 396 */             conn.commit();
/*     */             
/* 398 */             pstmt.close();
/* 399 */             j = 1;
/*     */           } 
/* 401 */           if (((String)this.CUST_TYPE_KEY_SH.get(interestedParty.getCustomerDetails().getCustomerIdNumber())).equalsIgnoreCase("1")) {
/*     */             
/* 403 */             pstmt1.setString(1, caseRefNo);
/* 404 */             pstmt1.setString(2, map.getRuleGrpNm());
/* 405 */             pstmt1.setString(3, map.getRiskParamDesc());
/* 406 */             pstmt1.setString(4, map.getRuleOpt());
/* 407 */             pstmt1.setString(5, map.getRuleTxVal());
/* 408 */             pstmt1.setString(6, map.getRuleEnblFl());
/* 409 */             if (map.getRiskParamTag().equalsIgnoreCase("PrimaryCitznCountry")) {
/*     */               
/* 411 */               pstmt1.setString(7, interestedParty.getCustomerDetails().getPrimaryCitznCountry());
/* 412 */             } else if (map.getRiskParamTag().equalsIgnoreCase("SecondryCitznCountry")) {
/*     */               
/* 414 */               pstmt1.setString(7, interestedParty.getCustomerDetails().getSecondryCitznCountry());
/* 415 */             } else if (map.getRiskParamTag().equalsIgnoreCase("ResidenceCountry")) {
/*     */               
/* 417 */               pstmt1.setString(7, interestedParty.getCustomerDetails().getResidenceCountry());
/* 418 */             } else if (map.getRiskParamTag().equalsIgnoreCase("PhoneCountry")) {
/*     */               
/* 420 */               values = "";
/* 421 */               for (int i = 0; i < interestedParty.getPhones().getPhone().size(); i++) {
/* 422 */                 values = values + ((Phone)interestedParty.getPhones().getPhone().get(i)).getPhoneCountry() + ",";
/*     */               }
/* 424 */               values = values.substring(0, values.length() - 1);
/* 425 */               pstmt1.setString(7, values);
/* 426 */             } else if (map.getRiskParamTag().equalsIgnoreCase("AddressCountry")) {
/*     */               
/* 428 */               values = "";
/* 429 */               for (int i = 0; i < interestedParty.getAddresses().getAddress().size(); i++) {
/* 430 */                 values = values + ((Address)interestedParty.getAddresses().getAddress().get(i)).getAddressCountry() + ",";
/*     */               }
/* 432 */               values = values.substring(0, values.length() - 1);
/* 433 */               pstmt1.setString(7, values);
/* 434 */             } else if (map.getRiskParamTag().equalsIgnoreCase("MailHandingInstruction")) {
/*     */               
/* 436 */               values = "";
/* 437 */               for (int i = 0; i < interestedParty.getAddresses().getAddress().size(); i++) {
/* 438 */                 values = values + ((Address)interestedParty.getAddresses().getAddress().get(i)).getMailHandingInstruction() + ",";
/*     */               }
/* 440 */               values = values.substring(0, values.length() - 1);
/* 441 */               pstmt1.setString(7, values);
/* 442 */             } else if (map.getRiskParamTag().contains("Value")) {
/*     */               
/* 444 */               for (int i = 9; i < interestedParty.getAdditionalParameters().getParameter().size(); i++) {
/*     */                 
/* 446 */                 pstmt1.setString(7, "None");
/* 447 */                 if (map.getRiskParamTag().equalsIgnoreCase("Value" + (i + 1))) {
/*     */                   
/* 449 */                   pstmt1.setString(7, ((Parameter)interestedParty.getAdditionalParameters().getParameter().get(i)).getValue().get(0));
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             } 
/* 454 */             pstmt1.setString(8, interestedParty.getCustomerDetails().getCustomerIdNumber());
/* 455 */             pstmt1.setString(9, "Individual");
/* 456 */             pstmt1.setLong(10, raorRequestID.longValue());
/* 457 */             pstmt1.setInt(11, shNum);
/* 458 */             pstmt1.addBatch();
/*     */             
/*     */             continue;
/*     */           } 
/* 462 */           pstmt1.setString(1, caseRefNo);
/* 463 */           pstmt1.setString(2, map.getRuleGrpNm());
/* 464 */           pstmt1.setString(3, map.getRiskParamDesc());
/* 465 */           pstmt1.setString(4, map.getRuleOpt());
/* 466 */           pstmt1.setString(5, map.getRuleTxVal());
/* 467 */           pstmt1.setString(6, map.getRuleEnblFl());
/* 468 */           if (map.getRiskParamTag().equalsIgnoreCase("AddressCountry")) {
/*     */             
/* 470 */             values = "";
/* 471 */             for (int i = 0; i < interestedParty.getAddresses().getAddress().size(); i++) {
/*     */               
/* 473 */               if (((Address)interestedParty.getAddresses().getAddress().get(i)).getAddressType().equalsIgnoreCase("B") || ((Address)interestedParty
/* 474 */                 .getAddresses().getAddress().get(i)).getAddressType().equalsIgnoreCase("P")) {
/* 475 */                 values = values + ((Address)interestedParty.getAddresses().getAddress().get(i)).getAddressCountry() + ",";
/*     */               }
/*     */             } 
/*     */             
/* 479 */             if (values == "") {
/* 480 */               values = "None,";
/*     */             }
/* 482 */             values = values.substring(0, values.length() - 1);
/* 483 */             pstmt1.setString(7, values);
/* 484 */           } else if (map.getRiskParamTag().equalsIgnoreCase("PhoneCountry")) {
/*     */             
/* 486 */             values = "";
/* 487 */             for (int i = 0; i < interestedParty.getPhones().getPhone().size(); i++) {
/* 488 */               values = values + ((Phone)interestedParty.getPhones().getPhone().get(i)).getPhoneCountry() + ",";
/*     */             }
/* 490 */             values = values.substring(0, values.length() - 1);
/* 491 */             pstmt1.setString(7, values);
/* 492 */           } else if (map.getRiskParamTag().equalsIgnoreCase("PhoneCountry-F")) {
/*     */             
/* 494 */             values = "";
/* 495 */             for (int i = 0; i < interestedParty.getPhones().getPhone().size(); i++) {
/*     */               
/* 497 */               if (((Phone)interestedParty.getPhones().getPhone().get(i)).getPhoneType().equalsIgnoreCase("F")) {
/* 498 */                 values = values + ((Phone)interestedParty.getPhones().getPhone().get(i)).getPhoneCountry() + ",";
/*     */               }
/*     */             } 
/*     */             
/* 502 */             if (values == "") {
/* 503 */               values = "None,";
/*     */             }
/* 505 */             values = values.substring(0, values.length() - 1);
/* 506 */             pstmt1.setString(7, values);
/* 507 */           } else if (map.getRiskParamTag().equalsIgnoreCase("MailHandingInstruction")) {
/*     */             
/* 509 */             values = "";
/* 510 */             for (int i = 0; i < interestedParty.getAddresses().getAddress().size(); i++) {
/* 511 */               values = values + ((Address)interestedParty.getAddresses().getAddress().get(i)).getMailHandingInstruction() + ",";
/*     */             }
/* 513 */             values = values.substring(0, values.length() - 1);
/* 514 */             pstmt1.setString(7, values);
/* 515 */           } else if (map.getRiskParamTag().contains("Value")) {
/*     */             
/* 517 */             for (int i = 13; i < interestedParty.getAdditionalParameters().getParameter().size(); i++) {
/*     */               
/* 519 */               pstmt1.setString(7, "None");
/* 520 */               if (map.getRiskParamTag().equalsIgnoreCase("Value" + (i + 1))) {
/*     */                 
/* 522 */                 pstmt1.setString(7, ((Parameter)interestedParty.getAdditionalParameters().getParameter().get(i)).getValue().get(0));
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */           } 
/* 527 */           pstmt1.setString(8, interestedParty.getCustomerDetails().getCustomerIdNumber());
/* 528 */           pstmt1.setString(9, "Legal Entity");
/* 529 */           pstmt1.setLong(10, raorRequestID.longValue());
/* 530 */           pstmt1.setInt(11, shNum);
/* 531 */           pstmt1.addBatch();
/*     */         } 
/*     */       } 
/*     */       
/* 535 */       pstmt1.executeBatch();
/* 536 */       conn.commit();
/* 537 */       pstmt1.close();
/* 538 */     } catch (Exception ex) {
/*     */       
/* 540 */       throw ex;
/*     */     } 
/*     */     
/* 543 */     Log4j.getLog().info("This is insertShareholdersInfoToDB function ends");
/*     */   }
/*     */   
/*     */   public void calculateIndicia(HashMap<String, String> custIDs_FT, String requestRAORID) throws Exception {
/* 547 */     Log4j.getLog().info("This is calculateIndicia function starts111");
/* 548 */     CallableStatement stmt = null;
/*     */     
/* 550 */     String caseRefNo = custIDs_FT.get("caseRefNo");
/* 551 */     custIDs_FT.remove("caseRefNo");
/*     */     
/* 553 */     String custId = custIDs_FT.get("0-custID");
/*     */     
/*     */     try {
/* 556 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi2.name"));
/*     */       
/* 558 */       stmt = conn.prepareCall("{? = call FN_FT_RAOR_PROCESS_THX_CSM(?,?,?)}");
/* 559 */       stmt.setString(2, custId);
/* 560 */       stmt.setString(3, caseRefNo);
/* 561 */       stmt.setInt(4, Integer.parseInt(requestRAORID));
/* 562 */       stmt.registerOutParameter(1, 12);
/* 563 */       stmt.execute();
/*     */       
/* 565 */       String returnVal = stmt.getString(1);
/* 566 */       Log4j.getLog().info("Return Value: " + returnVal + "......");
/*     */       
/* 568 */       stmt.close();
/* 569 */       conn.close();
/* 570 */     } catch (Exception ex) {
/* 571 */       throw ex;
/*     */     } 
/*     */     
/* 574 */     Log4j.getLog().info("This is calculateIndicia function ends");
/*     */   }
/*     */   
/*     */   public String[] getfatcaResponseParams(String requestRAORID, NewFields newFields_FT, HashMap<String, String> custIDs_FT) throws Exception {
/* 578 */     Log4j.getLog().info("This is getfatcaResponseParams function starts");
/*     */     
/* 580 */     String[] fatcaResponseParams = new String[500];
/*     */     
/* 582 */     String values = "";
/* 583 */     int highPriorityKey = 16;
/* 584 */     String highPriorityCd = "NULL";
/* 585 */     String[] fatcaOrgType = new String[2];
/*     */     
/*     */     try {
/* 588 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi2.name"));
/* 589 */       conn.setAutoCommit(false);
/* 590 */       fatcaResponseParams[0] = newFields_FT.getRaorRequest().getCustomer().getCustmerDetails().getCustomerType();
/*     */       
/* 592 */       PreparedStatement ps = conn.prepareStatement("SELECT F_INDICIA_P1_FL, NVL(F_INDICIA_P2_FL,'NULL'), F_RG_OVERALL_INDICIA_FL,FATCA_STATUS_KEY FROM FCT_TP_CUST_RAOR_THX_CUSTOM WHERE N_RAOR_REQ_ID = " + requestRAORID);
/* 593 */       ResultSet rs = ps.executeQuery();
/* 594 */       while (rs.next()) {
/*     */         
/* 596 */         fatcaResponseParams[1] = rs.getString(1);
/* 597 */         fatcaResponseParams[12] = rs.getString(2);
/* 598 */         fatcaResponseParams[13] = rs.getString(3);
/* 599 */         fatcaResponseParams[18] = rs.getString(4);
/*     */       } 
/*     */       
/* 602 */       rs.close();
/*     */       
/* 604 */       Log4j.getLog().info("fatca status key  is: " + fatcaResponseParams[18]);
/* 605 */       PreparedStatement f_ps = conn.prepareStatement("SELECT FATCA_DESC FROM DIM_FATCA_STATUS_THX_CSTM WHERE FATCA_CUST_TYPE= ? AND FATCA_KEY = " + fatcaResponseParams[18]);
/* 606 */       if (this.CUST_TYPE_KEY.equalsIgnoreCase("1")) {
/*     */         
/* 608 */         Log4j.getLog().info("fatca status for individual: ");
/* 609 */         f_ps.setString(1, "IND");
/*     */       } else {
/*     */         
/* 612 */         Log4j.getLog().info("fatca status for entity: ");
/* 613 */         f_ps.setString(1, "ENT");
/*     */       } 
/* 615 */       ResultSet f_rs = f_ps.executeQuery();
/* 616 */       while (f_rs.next()) {
/* 617 */         fatcaResponseParams[18] = f_rs.getString(1);
/*     */       }
/* 619 */       f_rs.close();
/* 620 */       f_ps.close();
/* 621 */       Log4j.getLog().info("fatca status is: " + fatcaResponseParams[18]);
/*     */       
/* 623 */       if (this.CUST_TYPE_KEY.equalsIgnoreCase("1")) {
/*     */         
/* 625 */         fatcaResponseParams[2] = newFields_FT.getRaorRequest().getCustomer().getCustmerDetails().getPrimaryCitznCountry() + "," + newFields_FT.getRaorRequest().getCustomer().getCustmerDetails().getSecondryCitznCountry();
/*     */         
/* 627 */         fatcaResponseParams[3] = ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(9)).getValue().get(0);
/*     */         
/* 629 */         fatcaResponseParams[4] = newFields_FT.getRaorRequest().getCustomer().getCustmerDetails().getResidenceCountry();
/*     */         
/* 631 */         fatcaResponseParams[5] = ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(10)).getValue().get(0);
/*     */         
/* 633 */         values = "";
/*     */         int i;
/* 635 */         for (i = 0; i < newFields_FT.getRaorRequest().getCustomer().getAddresses().getAddress().size(); i++) {
/* 636 */           values = values + ((Address)newFields_FT.getRaorRequest().getCustomer().getAddresses().getAddress().get(i)).getAddressCountry() + ",";
/*     */         }
/* 638 */         values = values.substring(0, values.length() - 1);
/* 639 */         fatcaResponseParams[6] = values;
/*     */         
/* 641 */         fatcaResponseParams[7] = ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(11)).getValue().get(0);
/*     */         
/* 643 */         fatcaResponseParams[8] = ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(12)).getValue().get(0);
/*     */         
/* 645 */         values = "";
/* 646 */         for (i = 0; i < newFields_FT.getRaorRequest().getCustomer().getAddresses().getAddress().size(); i++) {
/* 647 */           values = values + ((Address)newFields_FT.getRaorRequest().getCustomer().getAddresses().getAddress().get(i)).getMailHandingInstruction() + ",";
/*     */         }
/* 649 */         values = values.substring(0, values.length() - 1);
/* 650 */         fatcaResponseParams[9] = values;
/*     */         
/* 652 */         values = "";
/* 653 */         for (i = 0; i < newFields_FT.getRaorRequest().getCustomer().getPhones().getPhone().size(); i++) {
/* 654 */           values = values + ((Phone)newFields_FT.getRaorRequest().getCustomer().getPhones().getPhone().get(i)).getPhoneCountry() + ",";
/*     */         }
/* 656 */         values = values.substring(0, values.length() - 1);
/* 657 */         fatcaResponseParams[10] = values;
/*     */       }
/*     */       else {
/*     */         
/* 661 */         fatcaResponseParams[2] = ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(13)).getValue().get(0);
/*     */         
/* 663 */         values = "";
/*     */         int i;
/* 665 */         for (i = 0; i < newFields_FT.getRaorRequest().getCustomer().getAddresses().getAddress().size(); i++) {
/*     */           
/* 667 */           if (((Address)newFields_FT.getRaorRequest().getCustomer().getAddresses().getAddress().get(i)).getAddressType().equalsIgnoreCase("B") || ((Address)newFields_FT
/* 668 */             .getRaorRequest().getCustomer().getAddresses().getAddress().get(i)).getAddressType().equalsIgnoreCase("P")) {
/* 669 */             values = values + ((Address)newFields_FT.getRaorRequest().getCustomer().getAddresses().getAddress().get(i)).getAddressCountry() + ",";
/*     */           }
/*     */         } 
/*     */         
/* 673 */         if (values == "") {
/* 674 */           values = "None,";
/*     */         }
/* 676 */         values = values.substring(0, values.length() - 1);
/* 677 */         fatcaResponseParams[3] = values;
/*     */         
/* 679 */         values = "";
/* 680 */         for (i = 0; i < newFields_FT.getRaorRequest().getCustomer().getPhones().getPhone().size(); i++) {
/*     */           
/* 682 */           if (((Phone)newFields_FT.getRaorRequest().getCustomer().getPhones().getPhone().get(i)).getPhoneType().equalsIgnoreCase("F")) {
/* 683 */             values = values + ((Phone)newFields_FT.getRaorRequest().getCustomer().getPhones().getPhone().get(i)).getPhoneCountry() + ",";
/*     */           }
/*     */         } 
/*     */         
/* 687 */         if (values == "") {
/* 688 */           values = "None,";
/*     */         }
/* 690 */         values = values.substring(0, values.length() - 1);
/* 691 */         fatcaResponseParams[4] = values;
/*     */         
/* 693 */         values = "";
/* 694 */         for (i = 0; i < newFields_FT.getRaorRequest().getCustomer().getPhones().getPhone().size(); i++) {
/* 695 */           values = values + ((Phone)newFields_FT.getRaorRequest().getCustomer().getPhones().getPhone().get(i)).getPhoneCountry() + ",";
/*     */         }
/* 697 */         values = values.substring(0, values.length() - 1);
/* 698 */         fatcaResponseParams[5] = values;
/*     */         
/* 700 */         fatcaResponseParams[6] = ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(28)).getValue().get(0);
/*     */         
/* 702 */         values = "";
/* 703 */         for (i = 0; i < newFields_FT.getRaorRequest().getCustomer().getAddresses().getAddress().size(); i++) {
/* 704 */           values = values + ((Address)newFields_FT.getRaorRequest().getCustomer().getAddresses().getAddress().get(i)).getMailHandingInstruction() + ",";
/*     */         }
/* 706 */         values = values.substring(0, values.length() - 1);
/* 707 */         fatcaResponseParams[7] = values;
/*     */       } 
/*     */       
/* 710 */       if (this.CUST_TYPE_KEY.equalsIgnoreCase("2") || this.CUST_TYPE_KEY.equalsIgnoreCase("3")) {
/*     */         
/* 712 */         String sql = "INSERT INTO FCT_FATCA_ORG_TYPE_THX_CSM(ID,N_RAOR_REQ_ID,V_RA_CUST_NUMBER,FI_FL,TAX_REGISTER_FL,GIIN_NUMBER,DEEMED_COMPLIANT_FL,PARTICIPATING_ENTITY_FL,FINANCIAL_ACC_NPFI_FL,OWNER_COMPANY_FL,SHAREHOLDER_OWNED_COMPANY,PASSIVE_INCOME_PERC,ACTIVE_INCOME_PERC,STOCK_SECURITY_TRAD,COUNTRY_OF_INCOPERATION,WITHOLD_FOREIGN_PARTNERSHIP,WITHOLD_FOREIGN_TRUST,ENTITY_CATEGORY,SH_FL,RAOR_EOD_FL,DATA_DUMP_DATE,FATCA_ORG_TYPE) values(SEQ_FCT_FATCA_ORG_TYPE_THX_CSM.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,'RAOR', TO_DATE(TO_CHAR(sysdate, 'MM/DD/YYYY'), 'MM/DD/YYYY'),'EBO' )";
/*     */         
/* 714 */         PreparedStatement pstmt = conn.prepareStatement(sql);
/* 715 */         pstmt.setInt(1, Integer.parseInt(requestRAORID));
/* 716 */         pstmt.setString(2, newFields_FT.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/* 717 */         pstmt.setString(3, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(14)).getValue().get(0));
/* 718 */         pstmt.setString(4, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(15)).getValue().get(0));
/* 719 */         pstmt.setString(5, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(16)).getValue().get(0));
/* 720 */         pstmt.setString(6, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(17)).getValue().get(0));
/* 721 */         pstmt.setString(7, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(18)).getValue().get(0));
/* 722 */         pstmt.setString(8, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(19)).getValue().get(0));
/* 723 */         pstmt.setString(9, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(20)).getValue().get(0));
/* 724 */         pstmt.setString(10, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(21)).getValue().get(0));
/* 725 */         pstmt.setString(11, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(22)).getValue().get(0));
/* 726 */         pstmt.setString(12, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(23)).getValue().get(0));
/* 727 */         pstmt.setString(13, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(24)).getValue().get(0));
/* 728 */         pstmt.setString(14, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(13)).getValue().get(0));
/* 729 */         pstmt.setString(15, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(25)).getValue().get(0));
/* 730 */         pstmt.setString(16, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(26)).getValue().get(0));
/* 731 */         pstmt.setString(17, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(27)).getValue().get(0));
/* 732 */         pstmt.executeQuery();
/* 733 */         conn.commit();
/* 734 */         pstmt.close();
/* 735 */         CallableStatement stmt = conn.prepareCall("{? = call FN_FT_ORG_TYPE_CALC_THX_CSM(?,?,?)}");
/* 736 */         stmt.setString(2, newFields_FT.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/* 737 */         stmt.setInt(3, Integer.parseInt(requestRAORID));
/* 738 */         stmt.setString(4, newFields_FT.getRaorRequest().getCustomer().getCustmerDetails().getLegalName());
/* 739 */         stmt.registerOutParameter(1, 12);
/* 740 */         stmt.execute();
/*     */         
/* 742 */         fatcaOrgType = stmt.getString(1).split(",");
/* 743 */         Log4j.getLog().info("FATCA ORG TYPE KEY: " + Integer.parseInt(fatcaOrgType[0]) + ", ORG TYPE CD: " + fatcaOrgType[1]);
/* 744 */         highPriorityKey = Integer.parseInt(fatcaOrgType[0]);
/* 745 */         highPriorityCd = fatcaOrgType[1];
/* 746 */         stmt.close();
/*     */         
/* 748 */         fatcaResponseParams[11] = fatcaOrgType[1];
/*     */       }
/*     */       else {
/*     */         
/* 752 */         fatcaResponseParams[11] = "NULL";
/*     */       } 
/*     */       
/* 755 */       Log4j.getLog().info("This is calculate form type function starrtsss");
/* 756 */       CallableStatement frm_stmt = null;
/* 757 */       String caseRefNo = custIDs_FT.get("caseRefNo");
/* 758 */       custIDs_FT.remove("caseRefNo");
/* 759 */       String custId = custIDs_FT.get("0-custID");
/*     */       
/*     */       try {
/* 762 */         Connection frm_conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi2.name"));
/* 763 */         frm_stmt = conn.prepareCall("{? = call FN_FRMTYP_RAOR_PROCESS_THX_CSM(?,?,?)}");
/* 764 */         frm_stmt.setString(2, custId);
/* 765 */         frm_stmt.setString(3, caseRefNo);
/* 766 */         frm_stmt.setInt(4, Integer.parseInt(requestRAORID));
/* 767 */         frm_stmt.registerOutParameter(1, 12);
/* 768 */         frm_stmt.execute();
/* 769 */         String returnVal = frm_stmt.getString(1);
/* 770 */         Log4j.getLog().info("Return Value form type: " + returnVal + "......");
/* 771 */         frm_stmt.close();
/* 772 */         frm_conn.close();
/* 773 */         fatcaResponseParams[19] = returnVal;
/* 774 */       } catch (Exception ex) {
/* 775 */         throw ex;
/*     */       } 
/*     */       
/* 778 */       Log4j.getLog().info("This is calculate form type function ends");
/*     */       
/* 780 */       if (this.CUST_TYPE_KEY.equalsIgnoreCase("2") || this.CUST_TYPE_KEY.equalsIgnoreCase("3")) {
/*     */         
/* 782 */         CallableStatement stmt3 = conn.prepareCall("{? = call FN_FT_IRS_SCAN_THX_CSM(?, ?)}");
/* 783 */         stmt3.setString(2, ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(16)).getValue().get(0));
/* 784 */         stmt3.setString(3, newFields_FT.getRaorRequest().getCustomer().getCustmerDetails().getLegalName());
/* 785 */         stmt3.registerOutParameter(1, 12);
/* 786 */         stmt3.execute();
/* 787 */         fatcaResponseParams[14] = stmt3.getString(1);
/* 788 */         stmt3.close();
/*     */       } else {
/*     */         
/* 791 */         fatcaResponseParams[14] = "F";
/*     */       } 
/*     */       
/* 794 */       fatcaResponseParams[15] = newFields_FT.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber();
/*     */       
/* 796 */       int no = 0;
/* 797 */       if (newFields_FT.getInterestedParty() != null && newFields_FT.getInterestedParty().size() > 0) {
/* 798 */         for (int i = 0; i < newFields_FT.getInterestedParty().size(); i++) {
/*     */           
/* 800 */           if (Double.parseDouble(((InterestedParty)newFields_FT.getInterestedParty().get(i)).getCustomerRelationships().getCustomerRelation().getOwnershipPercentage()) > this.OwnershipPerc) {
/* 801 */             no++;
/*     */           }
/*     */         } 
/*     */       }
/* 805 */       fatcaResponseParams[16] = String.valueOf(no);
/*     */       
/* 807 */       fatcaResponseParams[17] = newFields_FT.getRaorRequest().getCustomer().getJurisdiction();
/*     */       
/* 809 */       int j = 20;
/* 810 */       if (newFields_FT.getInterestedParty() != null && newFields_FT.getInterestedParty().size() > 0) {
/* 811 */         for (int i = 0; i < newFields_FT.getInterestedParty().size(); i++) {
/*     */           
/* 813 */           if (Double.parseDouble(((InterestedParty)newFields_FT.getInterestedParty().get(i)).getCustomerRelationships().getCustomerRelation().getOwnershipPercentage()) > this.OwnershipPerc) {
/*     */             
/* 815 */             fatcaResponseParams[j] = ((InterestedParty)newFields_FT.getInterestedParty().get(i)).getCustomerDetails().getCustomerIdNumber();
/* 816 */             j++;
/* 817 */             fatcaResponseParams[j] = ((InterestedParty)newFields_FT.getInterestedParty().get(i)).getCustomerDetails().getCustomerType();
/* 818 */             j++;
/*     */             
/* 820 */             PreparedStatement ps2 = conn.prepareStatement("SELECT F_INDICIA_P1_FL FROM FCT_TP_SH_RAOR_THX_CUSTOM WHERE N_RAOR_REQ_ID_CUST = " + requestRAORID + " AND V_RA_SH_NUMBER = '" + ((InterestedParty)newFields_FT.getInterestedParty().get(i)).getCustomerDetails().getCustomerIdNumber() + "'");
/* 821 */             ResultSet rs2 = ps2.executeQuery();
/* 822 */             while (rs2.next()) {
/* 823 */               fatcaResponseParams[j] = rs2.getString(1);
/*     */             }
/* 825 */             j++;
/* 826 */             rs2.close();
/*     */             
/* 828 */             if (((String)this.CUST_TYPE_KEY_SH.get(((InterestedParty)newFields_FT.getInterestedParty().get(i)).getCustomerDetails().getCustomerIdNumber())).equalsIgnoreCase("1")) {
/*     */               
/* 830 */               fatcaResponseParams[j] = ((InterestedParty)newFields_FT.getInterestedParty().get(i)).getCustomerDetails().getPrimaryCitznCountry() + "," + newFields_FT.getRaorRequest().getCustomer().getCustmerDetails().getSecondryCitznCountry();
/* 831 */               j++;
/*     */               
/* 833 */               fatcaResponseParams[j] = ((Parameter)((InterestedParty)newFields_FT.getInterestedParty().get(i)).getAdditionalParameters().getParameter().get(9)).getValue().get(0);
/* 834 */               j++;
/*     */               
/* 836 */               fatcaResponseParams[j] = ((InterestedParty)newFields_FT.getInterestedParty().get(i)).getCustomerDetails().getResidenceCountry();
/* 837 */               j++;
/*     */               
/* 839 */               fatcaResponseParams[j] = ((Parameter)((InterestedParty)newFields_FT.getInterestedParty().get(i)).getAdditionalParameters().getParameter().get(10)).getValue().get(0);
/* 840 */               j++;
/*     */               
/* 842 */               values = "";
/*     */               int k;
/* 844 */               for (k = 0; k < ((InterestedParty)newFields_FT.getInterestedParty().get(i)).getAddresses().getAddress().size(); k++) {
/* 845 */                 values = values + ((Address)((InterestedParty)newFields_FT.getInterestedParty().get(i)).getAddresses().getAddress().get(k)).getAddressCountry() + ",";
/*     */               }
/* 847 */               values = values.substring(0, values.length() - 1);
/* 848 */               fatcaResponseParams[j] = values;
/* 849 */               j++;
/*     */               
/* 851 */               fatcaResponseParams[j] = ((Parameter)((InterestedParty)newFields_FT.getInterestedParty().get(i)).getAdditionalParameters().getParameter().get(11)).getValue().get(0);
/* 852 */               j++;
/*     */               
/* 854 */               fatcaResponseParams[j] = ((Parameter)((InterestedParty)newFields_FT.getInterestedParty().get(i)).getAdditionalParameters().getParameter().get(12)).getValue().get(0);
/* 855 */               j++;
/*     */               
/* 857 */               values = "";
/* 858 */               for (k = 0; k < ((InterestedParty)newFields_FT.getInterestedParty().get(i)).getAddresses().getAddress().size(); k++) {
/* 859 */                 values = values + ((Address)((InterestedParty)newFields_FT.getInterestedParty().get(i)).getAddresses().getAddress().get(k)).getMailHandingInstruction() + ",";
/*     */               }
/* 861 */               values = values.substring(0, values.length() - 1);
/* 862 */               fatcaResponseParams[j] = values;
/* 863 */               j++;
/*     */               
/* 865 */               values = "";
/* 866 */               for (k = 0; k < ((InterestedParty)newFields_FT.getInterestedParty().get(i)).getPhones().getPhone().size(); k++) {
/* 867 */                 values = values + ((Phone)((InterestedParty)newFields_FT.getInterestedParty().get(i)).getPhones().getPhone().get(k)).getPhoneCountry() + ",";
/*     */               }
/* 869 */               values = values.substring(0, values.length() - 1);
/* 870 */               fatcaResponseParams[j] = values;
/* 871 */               j++;
/*     */             }
/*     */             else {
/*     */               
/* 875 */               fatcaResponseParams[j] = ((Parameter)newFields_FT.getRaorRequest().getCustomer().getAdditionalParameters().getParameter().get(13)).getValue().get(0);
/* 876 */               j++;
/*     */               
/* 878 */               values = "";
/*     */               int k;
/* 880 */               for (k = 0; k < ((InterestedParty)newFields_FT.getInterestedParty().get(i)).getAddresses().getAddress().size(); k++) {
/*     */                 
/* 882 */                 if (((Address)((InterestedParty)newFields_FT.getInterestedParty().get(i)).getAddresses().getAddress().get(k)).getAddressType().equalsIgnoreCase("B") || ((Address)((InterestedParty)newFields_FT
/* 883 */                   .getInterestedParty().get(i)).getAddresses().getAddress().get(k)).getAddressType().equalsIgnoreCase("P")) {
/* 884 */                   values = values + ((Address)((InterestedParty)newFields_FT.getInterestedParty().get(i)).getAddresses().getAddress().get(k)).getAddressCountry() + ",";
/*     */                 }
/*     */               } 
/*     */               
/* 888 */               if (values == "") {
/* 889 */                 values = "None,";
/*     */               }
/* 891 */               values = values.substring(0, values.length() - 1);
/* 892 */               fatcaResponseParams[j] = values;
/* 893 */               j++;
/*     */               
/* 895 */               values = "";
/* 896 */               for (k = 0; k < ((InterestedParty)newFields_FT.getInterestedParty().get(i)).getPhones().getPhone().size(); k++) {
/*     */                 
/* 898 */                 if (((Phone)((InterestedParty)newFields_FT.getInterestedParty().get(i)).getPhones().getPhone().get(k)).getPhoneType().equalsIgnoreCase("F")) {
/* 899 */                   values = values + ((Phone)((InterestedParty)newFields_FT.getInterestedParty().get(i)).getPhones().getPhone().get(k)).getPhoneCountry() + ",";
/*     */                 }
/*     */               } 
/*     */               
/* 903 */               if (values == "") {
/* 904 */                 values = "None,";
/*     */               }
/* 906 */               values = values.substring(0, values.length() - 1);
/* 907 */               fatcaResponseParams[j] = values;
/* 908 */               j++;
/*     */               
/* 910 */               values = "";
/* 911 */               for (k = 0; k < ((InterestedParty)newFields_FT.getInterestedParty().get(i)).getPhones().getPhone().size(); k++) {
/* 912 */                 values = values + ((Phone)((InterestedParty)newFields_FT.getInterestedParty().get(i)).getPhones().getPhone().get(k)).getPhoneCountry() + ",";
/*     */               }
/* 914 */               values = values.substring(0, values.length() - 1);
/* 915 */               fatcaResponseParams[j] = values;
/* 916 */               j++;
/*     */               
/* 918 */               values = "";
/* 919 */               for (k = 0; k < ((InterestedParty)newFields_FT.getInterestedParty().get(i)).getAddresses().getAddress().size(); k++) {
/* 920 */                 values = values + ((Address)((InterestedParty)newFields_FT.getInterestedParty().get(i)).getAddresses().getAddress().get(k)).getMailHandingInstruction() + ",";
/*     */               }
/* 922 */               values = values.substring(0, values.length() - 1);
/* 923 */               fatcaResponseParams[j] = values;
/* 924 */               j++;
/*     */             } 
/*     */             
/* 927 */             if (((String)this.CUST_TYPE_KEY_SH.get(((InterestedParty)newFields_FT.getInterestedParty().get(i)).getCustomerDetails().getCustomerIdNumber())).equalsIgnoreCase("2") || ((String)this.CUST_TYPE_KEY_SH
/* 928 */               .get(((InterestedParty)newFields_FT.getInterestedParty().get(i)).getCustomerDetails().getCustomerIdNumber())).equalsIgnoreCase("3")) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 971 */               j++;
/*     */             } else {
/*     */               
/* 974 */               fatcaResponseParams[j] = "NULL";
/* 975 */               j++;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/* 980 */       conn.setAutoCommit(true);
/* 981 */       conn.close();
/* 982 */       for (int l = 0; l < j; l++) {
/* 983 */         Log4j.getLog().info("getfatcaResponseParams[" + l + "] = " + fatcaResponseParams[l]);
/*     */       }
/* 985 */       Log4j.getLog().info("FATCA:: ORG TYPE KEY: " + highPriorityKey + ", ORG TYPE CD: " + highPriorityCd);
/* 986 */     } catch (Exception ex) {
/* 987 */       throw ex;
/*     */     } 
/*     */     
/* 990 */     Log4j.getLog().info("This is getfatcaResponseParams function ends");
/* 991 */     return fatcaResponseParams;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\DAO\FATCAData\FATCADataOperations.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */