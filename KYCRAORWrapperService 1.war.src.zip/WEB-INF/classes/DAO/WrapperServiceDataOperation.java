/*     */ package WEB-INF.classes.DAO;
/*     */ 
/*     */ import BO.WrapperService.IndiciaAttributes;
/*     */ import BO.WrapperService.KYCRAORServiceResponse;
/*     */ import BO.WrapperService.Shareholder;
/*     */ import BO.WrapperService.Shareholders;
/*     */ import BO.WrapperService.WatchList;
/*     */ import DAO.WatchListData.WatchListDataOperation;
/*     */ import Logging.Log4j;
/*     */ import Utilities.StringOps;
/*     */ import Utilities.XmlParser;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ public class WrapperServiceDataOperation
/*     */ {
/*  17 */   XmlParser p = new XmlParser();
/*  18 */   StringOps strOps = new StringOps();
/*  19 */   WatchListDataOperation wlDataOps = new WatchListDataOperation();
/*     */   
/*     */   public String createWrapperServiceResponse(String[] respRAORBO, WatchList respWLBO, String[] respFATCABO) throws Exception {
/*  22 */     Log4j.getLog().info("createWrapperServiceResponse Function srtarts");
/*  23 */     String wrapperServiceResponse = "";
/*     */     
/*  25 */     IndiciaAttributes indiciaAttributes = new IndiciaAttributes();
/*  26 */     Shareholders shareholders = new Shareholders();
/*  27 */     int noOfShareholder = 0;
/*  28 */     ArrayList<Shareholder> shareholderList = new ArrayList<Shareholder>();
/*     */     
/*     */     try {
/*  31 */       KYCRAORServiceResponse response = new KYCRAORServiceResponse();
/*     */       
/*  33 */       if (respFATCABO.length > 0 || respRAORBO.length > 0 || (respWLBO != null && respWLBO.getMatch().size() > 0)) {
/*     */         
/*  35 */         response.setCustomerId(respRAORBO[2]);
/*  36 */         response.setRAORiskScore(respRAORBO[0]);
/*  37 */         response.setRAORiskCategory(respRAORBO[1]);
/*     */         
/*  39 */         response.setWatchlist(respWLBO);
/*     */         
/*  41 */         response.setCustomerId(respFATCABO[15]);
/*     */         
/*  43 */         response.setTerritoryRegion(respFATCABO[17]);
/*     */         
/*  45 */         response.setCustomerType(respFATCABO[0]);
/*     */         
/*  47 */         indiciaAttributes.setIndicia(respFATCABO[1]);
/*  48 */         if (response.getCustomerType().equalsIgnoreCase("IND")) {
/*     */           
/*  50 */           indiciaAttributes.setCountryOfNationality(respFATCABO[2]);
/*  51 */           indiciaAttributes.setGreenCard(respFATCABO[3]);
/*  52 */           indiciaAttributes.setCountryOfResidence(respFATCABO[4]);
/*  53 */           indiciaAttributes.setCountryOfBirth(respFATCABO[5]);
/*  54 */           indiciaAttributes.setCountryOfAddress(respFATCABO[6]);
/*  55 */           indiciaAttributes.setPowerOfAttorney(respFATCABO[7]);
/*  56 */           indiciaAttributes.setStandingInstructions(respFATCABO[8]);
/*  57 */           indiciaAttributes.setMailHandlingInstructions(respFATCABO[9]);
/*  58 */           indiciaAttributes.setCountryOfPhoneNumber(respFATCABO[10]);
/*     */         } else {
/*     */           
/*  61 */           indiciaAttributes.setCountryOfIncorporation(respFATCABO[2]);
/*  62 */           indiciaAttributes.setCountryOfBusinessAddress(respFATCABO[3]);
/*  63 */           indiciaAttributes.setCountryOfFax(respFATCABO[4]);
/*  64 */           indiciaAttributes.setCountryOfPhoneNumber(respFATCABO[5]);
/*  65 */           indiciaAttributes.setEntityControlledByUsIndicia(respFATCABO[6]);
/*  66 */           indiciaAttributes.setMailHandlingInstructions(respFATCABO[7]);
/*     */         } 
/*  68 */         response.setIndiciaAttributes(indiciaAttributes);
/*     */         
/*  70 */         response.setFatcaOrgType(respFATCABO[11]);
/*     */         
/*  72 */         noOfShareholder = Integer.parseInt(respFATCABO[16]);
/*  73 */         if (noOfShareholder > 0) {
/*  74 */           shareholders.setShareholderIndicia(respFATCABO[12]);
/*     */         }
/*     */         
/*  77 */         int j = 20;
/*  78 */         for (int i = 0; i < noOfShareholder; i++) {
/*  79 */           Shareholder shareholder = new Shareholder();
/*  80 */           IndiciaAttributes indiciaAttributesShareholder = new IndiciaAttributes();
/*  81 */           shareholder.setShareholderId(respFATCABO[j]);
/*  82 */           j++;
/*  83 */           shareholder.setShareholderType(respFATCABO[j]);
/*  84 */           j++;
/*  85 */           indiciaAttributesShareholder.setIndicia(respFATCABO[j]);
/*  86 */           j++;
/*  87 */           if (shareholder.getShareholderType().equalsIgnoreCase("IND")) {
/*     */             
/*  89 */             indiciaAttributesShareholder.setCountryOfNationality(respFATCABO[j]);
/*  90 */             j++;
/*  91 */             indiciaAttributesShareholder.setGreenCard(respFATCABO[j]);
/*  92 */             j++;
/*  93 */             indiciaAttributesShareholder.setCountryOfResidence(respFATCABO[j]);
/*  94 */             j++;
/*  95 */             indiciaAttributesShareholder.setCountryOfBirth(respFATCABO[j]);
/*  96 */             j++;
/*  97 */             indiciaAttributesShareholder.setCountryOfAddress(respFATCABO[j]);
/*  98 */             j++;
/*  99 */             indiciaAttributesShareholder.setPowerOfAttorney(respFATCABO[j]);
/* 100 */             j++;
/* 101 */             indiciaAttributesShareholder.setStandingInstructions(respFATCABO[j]);
/* 102 */             j++;
/* 103 */             indiciaAttributesShareholder.setMailHandlingInstructions(respFATCABO[j]);
/* 104 */             j++;
/* 105 */             indiciaAttributesShareholder.setCountryOfPhoneNumber(respFATCABO[j]);
/* 106 */             j++;
/*     */           } else {
/*     */             
/* 109 */             indiciaAttributesShareholder.setCountryOfIncorporation(respFATCABO[j]);
/* 110 */             j++;
/* 111 */             indiciaAttributesShareholder.setCountryOfBusinessAddress(respFATCABO[j]);
/* 112 */             j++;
/* 113 */             indiciaAttributesShareholder.setCountryOfFax(respFATCABO[j]);
/* 114 */             j++;
/* 115 */             indiciaAttributesShareholder.setCountryOfPhoneNumber(respFATCABO[j]);
/* 116 */             j++;
/* 117 */             indiciaAttributes.setMailHandlingInstructions(respFATCABO[j]);
/* 118 */             j++;
/*     */           } 
/*     */           
/* 121 */           shareholder.setIndiciaAttributes(indiciaAttributesShareholder);
/* 122 */           shareholder.setFatcaOrgType(respFATCABO[j]);
/* 123 */           j++;
/* 124 */           shareholderList.add(shareholder);
/*     */         } 
/* 126 */         shareholders.setShareholder(shareholderList);
/* 127 */         response.setShareholders(shareholders);
/*     */         
/* 129 */         response.setOverallIndicia(respFATCABO[13]);
/*     */         
/* 131 */         response.setGIINAvailable(respFATCABO[14]);
/*     */         
/* 133 */         if (response.getOverallIndicia().equalsIgnoreCase("Y")) {
/* 134 */           response.setMessage("Please collect FATCA form");
/*     */         }
/*     */         
/* 137 */         response.setFatcaStatus(respFATCABO[18]);
/* 138 */         response.setFatcaFormType(respFATCABO[19]);
/*     */         
/* 140 */         wrapperServiceResponse = this.p.convertoXML(response, "KYCRAORServiceResponse");
/* 141 */         wrapperServiceResponse = this.strOps.removeNs2(wrapperServiceResponse);
/* 142 */         Log4j.getLog().info(wrapperServiceResponse);
/*     */       } else {
/* 144 */         response.setError("Service execution failed! Check log file for details");
/*     */       }
/*     */     
/* 147 */     } catch (Exception ex) {
/*     */       
/* 149 */       throw ex;
/*     */     } 
/*     */     
/* 152 */     return wrapperServiceResponse;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\DAO\WrapperServiceDataOperation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */