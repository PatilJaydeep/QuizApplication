/*     */ package WEB-INF.classes.DAO.WatchListData;
/*     */ 
/*     */ import BO.NewFields.NewFields;
/*     */ import BO.RAOR.InterestedParty;
/*     */ import BO.WatchList.Candidate_name_type;
/*     */ import BO.WatchList.Candidate_type;
/*     */ import BO.WatchList.MWSS.Password_type;
/*     */ import BO.WatchList.MWSS.Password_type_attr;
/*     */ import BO.WatchList.MWSS.Security_type;
/*     */ import BO.WatchList.MWSS.Username_token_type;
/*     */ import BO.WatchList.ScanWatchListRequest;
/*     */ import BO.WatchList.ScanWatchListResponse;
/*     */ import BO.WrapperService.Match;
/*     */ import Database.JNDIConnector;
/*     */ import Logging.Log4j;
/*     */ import Utilities.LoadProperties;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ 
/*     */ public class WatchListDataOperation
/*     */ {
/*     */   public ScanWatchListRequest setWatchListBO(String customerType, String customerName) throws Exception {
/*  27 */     Log4j.getLog().info("This is getWatchListResponse function starts");
/*     */     
/*  29 */     ScanWatchListRequest scanRequest = new ScanWatchListRequest();
/*     */     
/*     */     try {
/*  32 */       Username_token_type username_token_type = new Username_token_type();
/*  33 */       Password_type password_type = new Password_type();
/*  34 */       Security_type security_type = new Security_type();
/*     */       
/*  36 */       password_type.setType(Password_type_attr.PasswordText);
/*  37 */       password_type.set_value("mantas");
/*     */       
/*  39 */       username_token_type.setUsername("mantas");
/*  40 */       username_token_type.setPassword(password_type);
/*     */       
/*  42 */       security_type.setUsernameToken(username_token_type);
/*  43 */       scanRequest.setSecurity(security_type);
/*     */       
/*  45 */       Log4j.getLog().info("customer name: " + customerName);
/*     */       
/*  47 */       Candidate_type candidate = new Candidate_type();
/*     */       
/*  49 */       candidate.setName(customerName);
/*  50 */       if (customerType.contains("IND")) {
/*     */         
/*  52 */         Log4j.getLog().info("in personal");
/*  53 */         candidate.setType(Candidate_name_type.Personal);
/*     */       } else {
/*     */         
/*  56 */         Log4j.getLog().info("in business");
/*  57 */         candidate.setType(Candidate_name_type.Business);
/*     */       } 
/*     */       
/*  60 */       scanRequest.setCandidate(new Candidate_type[1]);
/*  61 */       scanRequest.setCandidate(0, candidate);
/*     */     }
/*  63 */     catch (Exception ex) {
/*     */       
/*  65 */       throw ex;
/*     */     } 
/*     */     
/*  68 */     Log4j.getLog().info("This is getWatchListResponse function edns");
/*  69 */     return scanRequest;
/*     */   }
/*     */   
/*     */   public ArrayList<Match> mapWLResponseToObj(ScanWatchListResponse scanWatchListResponse, String customerType) throws Exception {
/*  73 */     Log4j.getLog().info("This is mapWLResponseToObj function starts");
/*  74 */     ArrayList<Match> matchList = new ArrayList<Match>();
/*     */     
/*     */     try {
/*  77 */       if (scanWatchListResponse.getCandidateMatch(0).getMatch() != null) {
/*  78 */         for (int i = 0; i < (scanWatchListResponse.getCandidateMatch(0).getMatch()).length; i++) {
/*     */           
/*  80 */           Match match = new Match();
/*  81 */           match.setWatchListLegalName(scanWatchListResponse.getCandidateMatch(0).getMatch(i).getName());
/*  82 */           match.setWatchListScore(Integer.parseInt(scanWatchListResponse.getCandidateMatch(0).getMatch(i).getScore().toString()));
/*  83 */           match.setWatchListName(scanWatchListResponse.getCandidateMatch(0).getMatch(i).getWatchListName());
/*     */           
/*  85 */           if (customerType.contains("SH")) {
/*     */             
/*  87 */             match.setWatchListCustomerType("Shareholder");
/*  88 */           } else if (customerType.contains("IND")) {
/*     */             
/*  90 */             match.setWatchListCustomerType("Individual");
/*  91 */           } else if (customerType.contains("ORG") || customerType.contains("FIN")) {
/*     */             
/*  93 */             match.setWatchListCustomerType("Entity");
/*     */           } 
/*  95 */           matchList.add(match);
/*     */         } 
/*     */       }
/*  98 */     } catch (Exception ex) {
/*     */       
/* 100 */       throw ex;
/*     */     } 
/*     */     
/* 103 */     Log4j.getLog().info("This is mapWLResponseToObj function ends");
/* 104 */     return matchList;
/*     */   }
/*     */   
/*     */   public ArrayList<Match> getTopRecords(ArrayList<Match> matchedResult) throws Exception {
/* 108 */     Log4j.getLog().info("This is getTopRecords function starts");
/* 109 */     int wlRecordLimit = Integer.parseInt(LoadProperties.getConf().getProperty("watchlist.record.limit"));
/*     */     
/*     */     try {
/* 112 */       Collections.sort(matchedResult, (Comparator<? super Match>)new Match());
/*     */       
/* 114 */       Log4j.getLog().info("matchList size:" + matchedResult.size());
/* 115 */       Log4j.getLog().info("wlRecordLimit:" + wlRecordLimit);
/*     */       
/* 117 */       if (matchedResult.size() > wlRecordLimit) {
/* 118 */         for (int i = matchedResult.size() - 1; i >= wlRecordLimit; i--) {
/* 119 */           matchedResult.remove(i);
/*     */         }
/*     */       }
/* 122 */       Log4j.getLog().info("after remove size:" + matchedResult.size());
/* 123 */     } catch (Exception ex) {
/*     */       
/* 125 */       throw ex;
/*     */     } 
/*     */     
/* 128 */     Log4j.getLog().info("This is getTopRecords function ends");
/* 129 */     return matchedResult;
/*     */   }
/*     */   
/*     */   public String[] insertWLSRequestToDB(NewFields requestObj, String requestRAORID, String custType, String legalName, int shIndex) throws Exception {
/* 133 */     Log4j.getLog().info("This is insertWLSRequestToDB function starts");
/* 134 */     PreparedStatement pstmt = null;
/* 135 */     String sql = "";
/* 136 */     String caseRefNo = "CASE" + requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber();
/* 137 */     String[] caseRefAndWlsKey = new String[2];
/* 138 */     caseRefAndWlsKey[0] = caseRefNo;
/*     */     
/*     */     try {
/* 141 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/*     */       
/* 143 */       sql = "INSERT INTO FCT_WLS_REQUESTS_TECHX_CUSTOM(v_wls_ref,fic_mis_date,n_raor_req_id,v_ra_cust_number,v_focus_cust_name,v_request_status,n_focus_cust_type,n_wls_key,n_src_cntry_key) values(?,SYSDATE,?,?,?,'I',?,SEQ_FCT_WLS_REQ_THX_CSM.nextval,(Select N_JURISDICTION_KEY from DIM_JURISDICTION where V_JURISDICTION_NAME = ? ))";
/*     */       
/* 145 */       pstmt = conn.prepareStatement(sql, new String[] { "n_wls_key" });
/* 146 */       pstmt.setString(1, caseRefNo);
/* 147 */       pstmt.setInt(2, Integer.parseInt(requestRAORID));
/* 148 */       if (!custType.contains("SH")) {
/*     */         
/* 150 */         pstmt.setString(3, requestObj.getRaorRequest().getCustomer().getCustmerDetails().getCustomerIdNumber());
/*     */       } else {
/*     */         
/* 153 */         pstmt.setString(3, ((InterestedParty)requestObj.getInterestedParty().get(shIndex)).getCustomerDetails().getCustomerIdNumber());
/*     */       } 
/* 155 */       pstmt.setString(4, legalName);
/* 156 */       if (custType.contains("IND")) {
/*     */         
/* 158 */         pstmt.setInt(5, 1);
/* 159 */       } else if (custType.contains("ORG") || custType.contains("FIN")) {
/*     */         
/* 161 */         pstmt.setInt(5, 2);
/*     */       } else {
/*     */         
/* 164 */         pstmt.setInt(5, 3);
/*     */       } 
/* 166 */       pstmt.setString(6, requestObj.getRaorRequest().getCustomer().getJurisdiction());
/* 167 */       pstmt.executeQuery();
/*     */       
/* 169 */       ResultSet wlskey = pstmt.getGeneratedKeys();
/* 170 */       if (wlskey.next()) {
/* 171 */         caseRefAndWlsKey[1] = String.valueOf(wlskey.getLong(1));
/*     */       }
/* 173 */       pstmt.close();
/* 174 */       conn.close();
/* 175 */     } catch (Exception ex) {
/*     */       
/* 177 */       throw ex;
/*     */     } 
/*     */     
/* 180 */     Log4j.getLog().info("This is insertWLSRequestToDB function ends");
/* 181 */     return caseRefAndWlsKey;
/*     */   }
/*     */   
/*     */   public void insertWLSResponseToDB(ScanWatchListResponse scanWatchListResponse, String[] caseRefAndWlsKey, String custType) throws Exception {
/* 185 */     Log4j.getLog().info("This is insertWLSResponseToDB function starts");
/* 186 */     PreparedStatement pstmt = null;
/* 187 */     String sql = "";
/*     */     
/*     */     try {
/* 190 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/* 191 */       conn.setAutoCommit(false);
/*     */       
/* 193 */       sql = "INSERT INTO FCT_WLS_RESULTS_TECHX_CUSTOM(n_wls_key,fic_mis_date,v_watch_list_type,v_watch_list_name,n_degree_risk,v_desc,v_match_name,v_wls_ref,n_wls_req_key,v_cust_type_name) values(SEQ_FCT_WLS_RES_THX_CSM.nextval,SYSDATE,?,?,?,?,?,?,?,?)";
/*     */       
/* 195 */       pstmt = conn.prepareStatement(sql);
/*     */       
/* 197 */       if (scanWatchListResponse.getCandidateMatch(0).getMatch() != null) {
/* 198 */         for (int i = 0; i < (scanWatchListResponse.getCandidateMatch(0).getMatch()).length; i++) {
/*     */           
/* 200 */           pstmt.setString(1, scanWatchListResponse.getCandidateMatch(0).getMatch(i).getWatchListType().getValue());
/* 201 */           pstmt.setString(2, scanWatchListResponse.getCandidateMatch(0).getMatch(i).getWatchListName());
/* 202 */           pstmt.setInt(3, Integer.parseInt(scanWatchListResponse.getCandidateMatch(0).getMatch(i).getScore().toString()));
/* 203 */           pstmt.setString(4, scanWatchListResponse.getCandidateMatch(0).getMatch(i).getDescription());
/* 204 */           pstmt.setString(5, scanWatchListResponse.getCandidateMatch(0).getMatch(i).getName());
/* 205 */           pstmt.setString(6, caseRefAndWlsKey[0]);
/* 206 */           pstmt.setString(7, caseRefAndWlsKey[1]);
/* 207 */           if (custType.contains("SH")) {
/*     */             
/* 209 */             pstmt.setString(8, "Shareholder");
/* 210 */           } else if (custType.contains("IND")) {
/*     */             
/* 212 */             pstmt.setString(8, "Individual");
/* 213 */           } else if (custType.contains("ORG") || custType.contains("FIN")) {
/*     */             
/* 215 */             pstmt.setString(8, "Entity");
/*     */           } 
/* 217 */           pstmt.addBatch();
/*     */         } 
/*     */       }
/* 220 */       pstmt.executeBatch();
/* 221 */       conn.commit();
/* 222 */       pstmt.close();
/* 223 */       conn.setAutoCommit(true);
/* 224 */       conn.close();
/* 225 */     } catch (Exception ex) {
/*     */       
/* 227 */       throw ex;
/*     */     } 
/*     */     
/* 230 */     Log4j.getLog().info("This is insertWLSResponseToDB function ends");
/*     */   }
/*     */   
/*     */   public void updateWLSRequestStatus(String requestRAORID) throws Exception {
/* 234 */     Log4j.getLog().info("This is updateWLSRequestStatus function starts");
/* 235 */     PreparedStatement pstmt = null;
/* 236 */     String sql = "";
/*     */     
/*     */     try {
/* 239 */       Connection conn = (new JNDIConnector()).getJNDIInstance(LoadProperties.getConf().getProperty("jndi.name"));
/* 240 */       sql = "UPDATE FCT_WLS_REQUESTS_TECHX_CUSTOM set v_request_status= 'C' WHERE n_raor_req_id = ?";
/*     */       
/* 242 */       pstmt = conn.prepareStatement(sql);
/* 243 */       pstmt.setInt(1, Integer.parseInt(requestRAORID));
/* 244 */       pstmt.executeQuery();
/* 245 */       pstmt.close();
/* 246 */       conn.close();
/* 247 */     } catch (Exception ex) {
/*     */       
/* 249 */       throw ex;
/*     */     } 
/*     */     
/* 252 */     Log4j.getLog().info("This is updateWLSRequestStatus function ends");
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\DAO\WatchListData\WatchListDataOperation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */