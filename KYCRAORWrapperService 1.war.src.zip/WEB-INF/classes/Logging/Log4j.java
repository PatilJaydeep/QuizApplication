/*    */ package WEB-INF.classes.Logging;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Properties;
/*    */ import org.apache.log4j.Category;
/*    */ import org.apache.log4j.PropertyConfigurator;
/*    */ 
/*    */ public class Log4j
/*    */ {
/* 11 */   private static final Category log = Category.getRoot();
/*    */   private static final String LOG_PROPERTIES_FILE = "/Properties/log4j.properties";
/*    */   
/*    */   static {
/* 15 */     Properties logProperties = new Properties();
/*    */     
/*    */     try {
/* 18 */       InputStream s = Logging.Log4j.class.getResourceAsStream("/Properties/log4j.properties");
/* 19 */       logProperties.load(s);
/* 20 */       PropertyConfigurator.configure(logProperties);
/* 21 */     } catch (IOException e) {
/*    */       
/* 23 */       throw new RuntimeException("Unable to load logging property /Properties/log4j.properties:" + e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static Category getLog() {
/* 28 */     return log;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\Logging\Log4j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */