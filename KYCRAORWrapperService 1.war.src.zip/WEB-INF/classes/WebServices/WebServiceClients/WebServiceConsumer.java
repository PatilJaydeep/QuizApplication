/*    */ package WEB-INF.classes.WebServices.WebServiceClients;
/*    */ 
/*    */ import BO.WatchList.ScanWatchListRequest;
/*    */ import BO.WatchList.ScanWatchListResponse;
/*    */ import Logging.Log4j;
/*    */ import WebServices.WebServiceClients.KYCWebServiceClient.KYCWebServiceClient.IKYCRAORService;
/*    */ import WebServices.WebServiceClients.KYCWebServiceClient.KYCWebServiceClient.IKYCRAORServiceServiceLocator;
/*    */ import WebServices.WebServiceClients.KYCWebServiceClient.WatchListClient.WatchListPortType;
/*    */ import WebServices.WebServiceClients.KYCWebServiceClient.WatchListClient.WatchListServiceLocator;
/*    */ import java.rmi.RemoteException;
/*    */ import javax.xml.rpc.ServiceException;
/*    */ 
/*    */ public class WebServiceConsumer
/*    */ {
/*    */   public String invokeKYCService(String xml, String username, String password) throws RemoteException, ServiceException {
/* 16 */     Log4j.getLog().info("This is cosumer invokeKYCService function starts");
/*    */     
/* 18 */     String kycServiceResponse = null;
/* 19 */     IKYCRAORServiceServiceLocator sl = new IKYCRAORServiceServiceLocator();
/* 20 */     IKYCRAORService stub1 = null;
/*    */     
/*    */     try {
/* 23 */       stub1 = sl.getKYCRAORService();
/* 24 */       kycServiceResponse = stub1.doRealTimeRiskRating(xml, username, password);
/* 25 */     } catch (ServiceException ex) {
/* 26 */       throw ex;
/*    */     }
/* 28 */     catch (RemoteException ex) {
/* 29 */       throw ex;
/*    */     } 
/*    */     
/* 32 */     Log4j.getLog().info("This is cosumer invokeKYCService function ends");
/* 33 */     return kycServiceResponse;
/*    */   }
/*    */   
/*    */   public ScanWatchListResponse invokeWatchListService(ScanWatchListRequest scanWatchListRequest) throws ServiceException, RemoteException {
/* 37 */     Log4j.getLog().info("This is cosumer invokeWatchListService function starts");
/* 38 */     WatchListServiceLocator locator = new WatchListServiceLocator();
/* 39 */     WatchListPortType stub = null;
/* 40 */     ScanWatchListResponse responseWL = null;
/*    */     
/*    */     try {
/* 43 */       stub = locator.getWatchListPort();
/* 44 */       responseWL = stub.scanWatchList(scanWatchListRequest);
/* 45 */     } catch (ServiceException ex) {
/* 46 */       throw ex;
/* 47 */     } catch (RemoteException ex) {
/* 48 */       throw ex;
/*    */     } 
/*    */     
/* 51 */     Log4j.getLog().info("This is cosumer invokeWatchListService function ends");
/* 52 */     return responseWL;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\WebServices\WebServiceClients\WebServiceConsumer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */