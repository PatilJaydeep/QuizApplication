/*     */ package WEB-INF.classes.WebServices.WebServiceClients.KYCWebServiceClient.WatchListClient;
/*     */ 
/*     */ import Utilities.LoadProperties;
/*     */ import WebServices.WebServiceClients.KYCWebServiceClient.WatchListClient.WatchListBindingStub;
/*     */ import WebServices.WebServiceClients.KYCWebServiceClient.WatchListClient.WatchListPortType;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.rmi.Remote;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.ServiceException;
/*     */ import org.apache.axis.AxisFault;
/*     */ import org.apache.axis.EngineConfiguration;
/*     */ import org.apache.axis.client.Service;
/*     */ import org.apache.axis.client.Stub;
/*     */ 
/*     */ public class WatchListServiceLocator extends Service implements WatchListService {
/*     */   private String WatchListPort_address;
/*     */   private String WatchListPortWSDDServiceName;
/*     */   private HashSet ports;
/*     */   
/*  23 */   public WatchListServiceLocator(EngineConfiguration config) { super(config);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  33 */     this.WatchListPort_address = LoadProperties.getConf().getProperty("watchlist.webservice");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  39 */     this.WatchListPortWSDDServiceName = "WatchListPort";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     this.ports = null; } public WatchListServiceLocator() { this.WatchListPort_address = LoadProperties.getConf().getProperty("watchlist.webservice"); this.WatchListPortWSDDServiceName = "WatchListPort"; this.ports = null; } public WatchListServiceLocator(String wsdlLoc, QName sName) throws ServiceException { super(wsdlLoc, sName); this.WatchListPort_address = LoadProperties.getConf().getProperty("watchlist.webservice"); this.WatchListPortWSDDServiceName = "WatchListPort"; this.ports = null; }
/*     */   public String getWatchListPortAddress() { return this.WatchListPort_address; }
/*     */   public String getWatchListPortWSDDServiceName() { return this.WatchListPortWSDDServiceName; }
/* 108 */   public void setWatchListPortWSDDServiceName(String name) { this.WatchListPortWSDDServiceName = name; } public WatchListPortType getWatchListPort() throws ServiceException { URL endpoint; try { endpoint = new URL(this.WatchListPort_address); } catch (MalformedURLException e) { throw new ServiceException(e); }  return getWatchListPort(endpoint); } public Iterator getPorts() { if (this.ports == null) {
/* 109 */       this.ports = new HashSet();
/* 110 */       this.ports.add(new QName("http://namespaces.mantas.com", "WatchListPort"));
/*     */     } 
/* 112 */     return this.ports.iterator(); }
/*     */   public WatchListPortType getWatchListPort(URL portAddress) throws ServiceException { try { WatchListBindingStub _stub = new WatchListBindingStub(portAddress, this); _stub.setPortName(getWatchListPortWSDDServiceName()); return (WatchListPortType)_stub; } catch (AxisFault e) { return null; }  }
/*     */   public void setWatchListPortEndpointAddress(String address) { this.WatchListPort_address = address; }
/*     */   public Remote getPort(Class<?> serviceEndpointInterface) throws ServiceException { try { if (WatchListPortType.class.isAssignableFrom(serviceEndpointInterface)) { WatchListBindingStub _stub = new WatchListBindingStub(new URL(this.WatchListPort_address), this); _stub.setPortName(getWatchListPortWSDDServiceName()); return (Remote)_stub; }  } catch (Throwable t) { throw new ServiceException(t); }  throw new ServiceException("There is no stub implementation for the interface:  " + ((serviceEndpointInterface == null) ? "null" : serviceEndpointInterface.getName())); }
/* 116 */   public Remote getPort(QName portName, Class serviceEndpointInterface) throws ServiceException { if (portName == null) return getPort(serviceEndpointInterface);  String inputPortName = portName.getLocalPart(); if ("WatchListPort".equals(inputPortName)) return (Remote)getWatchListPort();  Remote _stub = getPort(serviceEndpointInterface); ((Stub)_stub).setPortName(portName); return _stub; } public QName getServiceName() { return new QName("http://namespaces.mantas.com", "WatchListService"); } public void setEndpointAddress(String portName, String address) throws ServiceException { if ("WatchListPort".equals(portName)) {
/* 117 */       setWatchListPortEndpointAddress(address);
/*     */     } else {
/*     */       
/* 120 */       throw new ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
/*     */     }  }
/*     */ 
/*     */   
/*     */   public void setEndpointAddress(QName portName, String address) throws ServiceException {
/* 125 */     setEndpointAddress(portName.getLocalPart(), address);
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\WebServices\WebServiceClients\KYCWebServiceClient\WatchListClient\WatchListServiceLocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */