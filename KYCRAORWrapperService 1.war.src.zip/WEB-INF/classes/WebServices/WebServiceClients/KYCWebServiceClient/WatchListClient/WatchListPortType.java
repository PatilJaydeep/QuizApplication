package WEB-INF.classes.WebServices.WebServiceClients.KYCWebServiceClient.WatchListClient;

import BO.WatchList.Fault_type;
import BO.WatchList.ScanWatchListRequest;
import BO.WatchList.ScanWatchListResponse;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface WatchListPortType extends Remote {
  ScanWatchListResponse scanWatchList(ScanWatchListRequest paramScanWatchListRequest) throws RemoteException, Fault_type;
}


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\WebServices\WebServiceClients\KYCWebServiceClient\WatchListClient\WatchListPortType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */