/*     */ package WEB-INF.classes.WebServices.WebServiceClients.KYCWebServiceClient.WatchListClient;
/*     */ 
/*     */ import BO.WatchList.Address_type;
/*     */ import BO.WatchList.Candidate_match_type;
/*     */ import BO.WatchList.Candidate_name_type;
/*     */ import BO.WatchList.Candidate_type;
/*     */ import BO.WatchList.Fault_type;
/*     */ import BO.WatchList.MWSS.Password_type;
/*     */ import BO.WatchList.MWSS.Password_type_attr;
/*     */ import BO.WatchList.MWSS.Security_type;
/*     */ import BO.WatchList.MWSS.Username_token_type;
/*     */ import BO.WatchList.Match_type;
/*     */ import BO.WatchList.ScanWatchListRequest;
/*     */ import BO.WatchList.ScanWatchListResponse;
/*     */ import BO.WatchList.Watch_list_type;
/*     */ import WebServices.WebServiceClients.KYCWebServiceClient.WatchListClient.WatchListPortType;
/*     */ import java.math.BigInteger;
/*     */ import java.net.URL;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.Service;
/*     */ import org.apache.axis.AxisFault;
/*     */ import org.apache.axis.NoEndPointException;
/*     */ import org.apache.axis.client.Call;
/*     */ import org.apache.axis.client.Service;
/*     */ import org.apache.axis.client.Stub;
/*     */ import org.apache.axis.constants.Style;
/*     */ import org.apache.axis.constants.Use;
/*     */ import org.apache.axis.description.FaultDesc;
/*     */ import org.apache.axis.description.OperationDesc;
/*     */ import org.apache.axis.description.ParameterDesc;
/*     */ import org.apache.axis.encoding.DeserializerFactory;
/*     */ import org.apache.axis.encoding.SerializerFactory;
/*     */ import org.apache.axis.encoding.ser.ArrayDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.ArraySerializerFactory;
/*     */ import org.apache.axis.encoding.ser.BaseDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.BaseSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.BeanDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.BeanSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.EnumDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.EnumSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.SimpleDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.SimpleListDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.SimpleListSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.SimpleSerializerFactory;
/*     */ import org.apache.axis.soap.SOAPConstants;
/*     */ import org.apache.axis.types.NonNegativeInteger;
/*     */ import org.apache.axis.utils.JavaUtils;
/*     */ 
/*     */ public class WatchListBindingStub extends Stub implements WatchListPortType {
/*  53 */   private Vector cachedSerClasses = new Vector();
/*  54 */   private Vector cachedSerQNames = new Vector();
/*  55 */   private Vector cachedSerFactories = new Vector();
/*  56 */   private Vector cachedDeserFactories = new Vector();
/*     */   
/*  58 */   static OperationDesc[] _operations = new OperationDesc[1];
/*     */   
/*     */   static {
/*  61 */     _initOperationDesc1();
/*     */   }
/*     */   
/*     */   private static void _initOperationDesc1() {
/*  65 */     OperationDesc oper = new OperationDesc();
/*  66 */     oper.setName("ScanWatchList");
/*  67 */     ParameterDesc param = new ParameterDesc(new QName("http://namespaces.mantas.com", "ScanWatchListRequest"), (byte)1, new QName("http://namespaces.mantas.com", ">ScanWatchListRequest"), ScanWatchListRequest.class, false, false);
/*  68 */     oper.addParameter(param);
/*  69 */     oper.setReturnType(new QName("http://namespaces.mantas.com", ">ScanWatchListResponse"));
/*  70 */     oper.setReturnClass(ScanWatchListResponse.class);
/*  71 */     oper.setReturnQName(new QName("http://namespaces.mantas.com", "ScanWatchListResponse"));
/*  72 */     oper.setStyle(Style.DOCUMENT);
/*  73 */     oper.setUse(Use.LITERAL);
/*  74 */     oper.addFault(new FaultDesc(new QName("http://namespaces.mantas.com", "ScanWatchListFault"), "Fault_type", new QName("http://namespaces.mantas.com", "fault_type"), true));
/*     */     
/*  76 */     _operations[0] = oper;
/*     */   }
/*     */   
/*     */   public WatchListBindingStub() throws AxisFault {
/*  80 */     this(null);
/*     */   }
/*     */   
/*     */   public WatchListBindingStub(URL endpointURL, Service service) throws AxisFault {
/*  84 */     this(service);
/*  85 */     this.cachedEndpoint = endpointURL;
/*     */   }
/*     */   
/*     */   public WatchListBindingStub(Service service) throws AxisFault {
/*  89 */     if (service == null) {
/*  90 */       this.service = (Service)new Service();
/*     */     } else {
/*  92 */       this.service = (Service)service;
/*     */     } 
/*  94 */     ((Service)this.service).setTypeMappingVersion("1.2");
/*     */     
/*  96 */     Class<BeanSerializerFactory> beansf = BeanSerializerFactory.class;
/*  97 */     Class<BeanDeserializerFactory> beandf = BeanDeserializerFactory.class;
/*  98 */     Class<EnumSerializerFactory> enumsf = EnumSerializerFactory.class;
/*  99 */     Class<EnumDeserializerFactory> enumdf = EnumDeserializerFactory.class;
/* 100 */     Class<ArraySerializerFactory> arraysf = ArraySerializerFactory.class;
/* 101 */     Class<ArrayDeserializerFactory> arraydf = ArrayDeserializerFactory.class;
/* 102 */     Class<SimpleSerializerFactory> simplesf = SimpleSerializerFactory.class;
/* 103 */     Class<SimpleDeserializerFactory> simpledf = SimpleDeserializerFactory.class;
/* 104 */     Class<SimpleListSerializerFactory> simplelistsf = SimpleListSerializerFactory.class;
/* 105 */     Class<SimpleListDeserializerFactory> simplelistdf = SimpleListDeserializerFactory.class;
/* 106 */     QName qName = new QName("http://namespaces.mantas.com/MWSS", "password_type");
/* 107 */     this.cachedSerQNames.add(qName);
/* 108 */     Class<Password_type> cls = Password_type.class;
/* 109 */     this.cachedSerClasses.add(cls);
/* 110 */     this.cachedSerFactories.add(BaseSerializerFactory.createFactory(SimpleSerializerFactory.class, cls, qName));
/* 111 */     this.cachedDeserFactories.add(BaseDeserializerFactory.createFactory(SimpleDeserializerFactory.class, cls, qName));
/*     */     
/* 113 */     qName = new QName("http://namespaces.mantas.com/MWSS", "password_type_attr");
/* 114 */     this.cachedSerQNames.add(qName);
/* 115 */     Class<Password_type_attr> clazz13 = Password_type_attr.class;
/* 116 */     this.cachedSerClasses.add(clazz13);
/* 117 */     this.cachedSerFactories.add(enumsf);
/* 118 */     this.cachedDeserFactories.add(enumdf);
/*     */     
/* 120 */     qName = new QName("http://namespaces.mantas.com/MWSS", "security_type");
/* 121 */     this.cachedSerQNames.add(qName);
/* 122 */     Class<Security_type> clazz12 = Security_type.class;
/* 123 */     this.cachedSerClasses.add(clazz12);
/* 124 */     this.cachedSerFactories.add(beansf);
/* 125 */     this.cachedDeserFactories.add(beandf);
/*     */     
/* 127 */     qName = new QName("http://namespaces.mantas.com/MWSS", "username_token_type");
/* 128 */     this.cachedSerQNames.add(qName);
/* 129 */     Class<Username_token_type> clazz11 = Username_token_type.class;
/* 130 */     this.cachedSerClasses.add(clazz11);
/* 131 */     this.cachedSerFactories.add(beansf);
/* 132 */     this.cachedDeserFactories.add(beandf);
/*     */     
/* 134 */     qName = new QName("http://namespaces.mantas.com", ">ScanWatchListRequest");
/* 135 */     this.cachedSerQNames.add(qName);
/* 136 */     Class<ScanWatchListRequest> clazz10 = ScanWatchListRequest.class;
/* 137 */     this.cachedSerClasses.add(clazz10);
/* 138 */     this.cachedSerFactories.add(beansf);
/* 139 */     this.cachedDeserFactories.add(beandf);
/*     */     
/* 141 */     qName = new QName("http://namespaces.mantas.com", ">ScanWatchListResponse");
/* 142 */     this.cachedSerQNames.add(qName);
/* 143 */     Class<ScanWatchListResponse> clazz9 = ScanWatchListResponse.class;
/* 144 */     this.cachedSerClasses.add(clazz9);
/* 145 */     this.cachedSerFactories.add(beansf);
/* 146 */     this.cachedDeserFactories.add(beandf);
/*     */     
/* 148 */     qName = new QName("http://namespaces.mantas.com", "address_type");
/* 149 */     this.cachedSerQNames.add(qName);
/* 150 */     Class<Address_type> clazz8 = Address_type.class;
/* 151 */     this.cachedSerClasses.add(clazz8);
/* 152 */     this.cachedSerFactories.add(beansf);
/* 153 */     this.cachedDeserFactories.add(beandf);
/*     */     
/* 155 */     qName = new QName("http://namespaces.mantas.com", "candidate_match_type");
/* 156 */     this.cachedSerQNames.add(qName);
/* 157 */     Class<Candidate_match_type> clazz7 = Candidate_match_type.class;
/* 158 */     this.cachedSerClasses.add(clazz7);
/* 159 */     this.cachedSerFactories.add(beansf);
/* 160 */     this.cachedDeserFactories.add(beandf);
/*     */     
/* 162 */     qName = new QName("http://namespaces.mantas.com", "candidate_name_type");
/* 163 */     this.cachedSerQNames.add(qName);
/* 164 */     Class<Candidate_name_type> clazz6 = Candidate_name_type.class;
/* 165 */     this.cachedSerClasses.add(clazz6);
/* 166 */     this.cachedSerFactories.add(enumsf);
/* 167 */     this.cachedDeserFactories.add(enumdf);
/*     */     
/* 169 */     qName = new QName("http://namespaces.mantas.com", "candidate_type");
/* 170 */     this.cachedSerQNames.add(qName);
/* 171 */     Class<Candidate_type> clazz5 = Candidate_type.class;
/* 172 */     this.cachedSerClasses.add(clazz5);
/* 173 */     this.cachedSerFactories.add(beansf);
/* 174 */     this.cachedDeserFactories.add(beandf);
/*     */     
/* 176 */     qName = new QName("http://namespaces.mantas.com", "fault_type");
/* 177 */     this.cachedSerQNames.add(qName);
/* 178 */     Class<Fault_type> clazz4 = Fault_type.class;
/* 179 */     this.cachedSerClasses.add(clazz4);
/* 180 */     this.cachedSerFactories.add(beansf);
/* 181 */     this.cachedDeserFactories.add(beandf);
/*     */     
/* 183 */     qName = new QName("http://namespaces.mantas.com", "integer_from_0_to_100");
/* 184 */     this.cachedSerQNames.add(qName);
/* 185 */     Class<NonNegativeInteger> clazz3 = NonNegativeInteger.class;
/* 186 */     this.cachedSerClasses.add(clazz3);
/* 187 */     this.cachedSerFactories.add(BaseSerializerFactory.createFactory(SimpleSerializerFactory.class, clazz3, qName));
/* 188 */     this.cachedDeserFactories.add(BaseDeserializerFactory.createFactory(SimpleDeserializerFactory.class, clazz3, qName));
/*     */     
/* 190 */     qName = new QName("http://namespaces.mantas.com", "match_type");
/* 191 */     this.cachedSerQNames.add(qName);
/* 192 */     Class<Match_type> clazz2 = Match_type.class;
/* 193 */     this.cachedSerClasses.add(clazz2);
/* 194 */     this.cachedSerFactories.add(beansf);
/* 195 */     this.cachedDeserFactories.add(beandf);
/*     */     
/* 197 */     qName = new QName("http://namespaces.mantas.com", "watch_list_risk_type");
/* 198 */     this.cachedSerQNames.add(qName);
/* 199 */     Class<BigInteger> clazz1 = BigInteger.class;
/* 200 */     this.cachedSerClasses.add(clazz1);
/* 201 */     this.cachedSerFactories.add(BaseSerializerFactory.createFactory(SimpleSerializerFactory.class, clazz1, qName));
/* 202 */     this.cachedDeserFactories.add(BaseDeserializerFactory.createFactory(SimpleDeserializerFactory.class, clazz1, qName));
/*     */     
/* 204 */     qName = new QName("http://namespaces.mantas.com", "watch_list_type");
/* 205 */     this.cachedSerQNames.add(qName);
/* 206 */     Class<Watch_list_type> clazz = Watch_list_type.class;
/* 207 */     this.cachedSerClasses.add(clazz);
/* 208 */     this.cachedSerFactories.add(enumsf);
/* 209 */     this.cachedDeserFactories.add(enumdf);
/*     */   }
/*     */   
/*     */   protected Call createCall() throws RemoteException {
/*     */     try {
/* 214 */       Call _call = _createCall();
/* 215 */       if (this.maintainSessionSet) {
/* 216 */         _call.setMaintainSession(this.maintainSession);
/*     */       }
/* 218 */       if (this.cachedUsername != null) {
/* 219 */         _call.setUsername(this.cachedUsername);
/*     */       }
/* 221 */       if (this.cachedPassword != null) {
/* 222 */         _call.setPassword(this.cachedPassword);
/*     */       }
/* 224 */       if (this.cachedEndpoint != null) {
/* 225 */         _call.setTargetEndpointAddress(this.cachedEndpoint);
/*     */       }
/* 227 */       if (this.cachedTimeout != null) {
/* 228 */         _call.setTimeout(this.cachedTimeout);
/*     */       }
/* 230 */       if (this.cachedPortName != null) {
/* 231 */         _call.setPortName(this.cachedPortName);
/*     */       }
/* 233 */       Enumeration<Object> keys = this.cachedProperties.keys();
/*     */       
/* 235 */       while (keys.hasMoreElements()) {
/* 236 */         String key = (String)keys.nextElement();
/* 237 */         _call.setProperty(key, this.cachedProperties.get(key));
/*     */       } 
/*     */       
/* 240 */       synchronized (this) {
/* 241 */         if (firstCall()) {
/*     */           
/* 243 */           _call.setEncodingStyle(null);
/* 244 */           for (int i = 0; i < this.cachedSerFactories.size(); i++) {
/* 245 */             Class cls = this.cachedSerClasses.get(i);
/*     */             
/* 247 */             QName qName = this.cachedSerQNames.get(i);
/* 248 */             Object x = this.cachedSerFactories.get(i);
/* 249 */             if (x instanceof Class) {
/*     */               
/* 251 */               Class sf = this.cachedSerFactories.get(i);
/*     */               
/* 253 */               Class df = this.cachedDeserFactories.get(i);
/* 254 */               _call.registerTypeMapping(cls, qName, sf, df, false);
/* 255 */             } else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
/*     */               
/* 257 */               SerializerFactory sf = this.cachedSerFactories.get(i);
/*     */               
/* 259 */               DeserializerFactory df = this.cachedDeserFactories.get(i);
/* 260 */               _call.registerTypeMapping(cls, qName, sf, df, false);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 265 */       return _call;
/* 266 */     } catch (Throwable _t) {
/* 267 */       throw new AxisFault("Failure trying to get the Call object", _t);
/*     */     } 
/*     */   }
/*     */   
/*     */   public ScanWatchListResponse scanWatchList(ScanWatchListRequest body) throws RemoteException, Fault_type {
/* 272 */     if (this.cachedEndpoint == null) {
/* 273 */       throw new NoEndPointException();
/*     */     }
/* 275 */     Call _call = createCall();
/* 276 */     _call.setOperation(_operations[0]);
/* 277 */     _call.setUseSOAPAction(true);
/* 278 */     _call.setSOAPActionURI("urn:#ScanWatchList");
/* 279 */     _call.setEncodingStyle(null);
/* 280 */     _call.setProperty("sendXsiTypes", Boolean.FALSE);
/* 281 */     _call.setProperty("sendMultiRefs", Boolean.FALSE);
/* 282 */     _call.setSOAPVersion((SOAPConstants)SOAPConstants.SOAP11_CONSTANTS);
/* 283 */     _call.setOperationName(new QName("", "ScanWatchList"));
/*     */     
/* 285 */     setRequestHeaders(_call);
/* 286 */     setAttachments(_call);
/*     */     try {
/* 288 */       Object _resp = _call.invoke(new Object[] { body });
/*     */       
/* 290 */       if (_resp instanceof RemoteException) {
/* 291 */         throw (RemoteException)_resp;
/*     */       }
/*     */       
/* 294 */       extractAttachments(_call);
/*     */       try {
/* 296 */         return (ScanWatchListResponse)_resp;
/* 297 */       } catch (Exception _exception) {
/* 298 */         return (ScanWatchListResponse)JavaUtils.convert(_resp, ScanWatchListResponse.class);
/*     */       }
/*     */     
/* 301 */     } catch (AxisFault axisFaultException) {
/* 302 */       if (axisFaultException.detail != null) {
/* 303 */         if (axisFaultException.detail instanceof RemoteException) {
/* 304 */           throw (RemoteException)axisFaultException.detail;
/*     */         }
/* 306 */         if (axisFaultException.detail instanceof Fault_type) {
/* 307 */           throw (Fault_type)axisFaultException.detail;
/*     */         }
/*     */       } 
/* 310 */       throw axisFaultException;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\WebServices\WebServiceClients\KYCWebServiceClient\WatchListClient\WatchListBindingStub.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */