package WEB-INF.classes.WebServices.WebServiceClients.KYCWebServiceClient.WatchListClient;

import WebServices.WebServiceClients.KYCWebServiceClient.WatchListClient.WatchListPortType;
import java.net.URL;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;

public interface WatchListService extends Service {
  String getWatchListPortAddress();
  
  WatchListPortType getWatchListPort() throws ServiceException;
  
  WatchListPortType getWatchListPort(URL paramURL) throws ServiceException;
}


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\WebServices\WebServiceClients\KYCWebServiceClient\WatchListClient\WatchListService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */