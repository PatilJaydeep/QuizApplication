/*     */ package WEB-INF.classes.WebServices.WebServiceClients.KYCWebServiceClient.KYCWebServiceClient;
/*     */ 
/*     */ import WebServices.WebServiceClients.KYCWebServiceClient.KYCWebServiceClient.IKYCRAORService;
/*     */ import java.net.URL;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.Service;
/*     */ import org.apache.axis.AxisFault;
/*     */ import org.apache.axis.NoEndPointException;
/*     */ import org.apache.axis.client.Call;
/*     */ import org.apache.axis.client.Service;
/*     */ import org.apache.axis.client.Stub;
/*     */ import org.apache.axis.constants.Style;
/*     */ import org.apache.axis.constants.Use;
/*     */ import org.apache.axis.description.OperationDesc;
/*     */ import org.apache.axis.description.ParameterDesc;
/*     */ import org.apache.axis.soap.SOAPConstants;
/*     */ import org.apache.axis.utils.JavaUtils;
/*     */ 
/*     */ public class KYCRAORServiceSoapBindingStub
/*     */   extends Stub implements IKYCRAORService {
/*  24 */   private Vector cachedSerClasses = new Vector();
/*  25 */   private Vector cachedSerQNames = new Vector();
/*  26 */   private Vector cachedSerFactories = new Vector();
/*  27 */   private Vector cachedDeserFactories = new Vector();
/*     */   
/*  29 */   static OperationDesc[] _operations = new OperationDesc[1];
/*     */   
/*     */   static {
/*  32 */     _initOperationDesc1();
/*     */   }
/*     */   
/*     */   private static void _initOperationDesc1() {
/*  36 */     OperationDesc oper = new OperationDesc();
/*  37 */     oper.setName("doRealTimeRiskRating");
/*  38 */     ParameterDesc param = new ParameterDesc(new QName("", "in0"), (byte)1, new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), String.class, false, false);
/*  39 */     oper.addParameter(param);
/*  40 */     param = new ParameterDesc(new QName("", "in1"), (byte)1, new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), String.class, false, false);
/*  41 */     oper.addParameter(param);
/*  42 */     param = new ParameterDesc(new QName("", "in2"), (byte)1, new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), String.class, false, false);
/*  43 */     oper.addParameter(param);
/*  44 */     oper.setReturnType(new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
/*  45 */     oper.setReturnClass(String.class);
/*  46 */     oper.setReturnQName(new QName("", "doRealTimeRiskRatingReturn"));
/*  47 */     oper.setStyle(Style.RPC);
/*  48 */     oper.setUse(Use.ENCODED);
/*  49 */     _operations[0] = oper;
/*     */   }
/*     */   
/*     */   public KYCRAORServiceSoapBindingStub() throws AxisFault {
/*  53 */     this(null);
/*     */   }
/*     */   
/*     */   public KYCRAORServiceSoapBindingStub(URL endpointURL, Service service) throws AxisFault {
/*  57 */     this(service);
/*  58 */     this.cachedEndpoint = endpointURL;
/*     */   }
/*     */   
/*     */   public KYCRAORServiceSoapBindingStub(Service service) throws AxisFault {
/*  62 */     if (service == null) {
/*  63 */       this.service = (Service)new Service();
/*     */     } else {
/*  65 */       this.service = (Service)service;
/*     */     } 
/*  67 */     ((Service)this.service).setTypeMappingVersion("1.2");
/*     */   }
/*     */   
/*     */   protected Call createCall() throws RemoteException {
/*     */     try {
/*  72 */       Call _call = _createCall();
/*  73 */       if (this.maintainSessionSet) {
/*  74 */         _call.setMaintainSession(this.maintainSession);
/*     */       }
/*  76 */       if (this.cachedUsername != null) {
/*  77 */         _call.setUsername(this.cachedUsername);
/*     */       }
/*  79 */       if (this.cachedPassword != null) {
/*  80 */         _call.setPassword(this.cachedPassword);
/*     */       }
/*  82 */       if (this.cachedEndpoint != null) {
/*  83 */         _call.setTargetEndpointAddress(this.cachedEndpoint);
/*     */       }
/*  85 */       if (this.cachedTimeout != null) {
/*  86 */         _call.setTimeout(this.cachedTimeout);
/*     */       }
/*  88 */       if (this.cachedPortName != null) {
/*  89 */         _call.setPortName(this.cachedPortName);
/*     */       }
/*  91 */       Enumeration<Object> keys = this.cachedProperties.keys();
/*     */       
/*  93 */       while (keys.hasMoreElements()) {
/*  94 */         String key = (String)keys.nextElement();
/*  95 */         _call.setProperty(key, this.cachedProperties.get(key));
/*     */       } 
/*  97 */       return _call;
/*  98 */     } catch (Throwable _t) {
/*  99 */       throw new AxisFault("Failure trying to get the Call object", _t);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String doRealTimeRiskRating(String in0, String in1, String in2) throws RemoteException {
/* 104 */     if (this.cachedEndpoint == null) {
/* 105 */       throw new NoEndPointException();
/*     */     }
/* 107 */     Call _call = createCall();
/* 108 */     _call.setOperation(_operations[0]);
/* 109 */     _call.setUseSOAPAction(true);
/* 110 */     _call.setSOAPActionURI("");
/* 111 */     _call.setSOAPVersion((SOAPConstants)SOAPConstants.SOAP11_CONSTANTS);
/* 112 */     _call.setOperationName(new QName("urn:KYCRAORService", "doRealTimeRiskRating"));
/*     */     
/* 114 */     setRequestHeaders(_call);
/* 115 */     setAttachments(_call);
/*     */     try {
/* 117 */       Object _resp = _call.invoke(new Object[] { in0, in1, in2 });
/*     */       
/* 119 */       if (_resp instanceof RemoteException) {
/* 120 */         throw (RemoteException)_resp;
/*     */       }
/*     */       
/* 123 */       extractAttachments(_call);
/*     */       try {
/* 125 */         return (String)_resp;
/* 126 */       } catch (Exception _exception) {
/* 127 */         return (String)JavaUtils.convert(_resp, String.class);
/*     */       }
/*     */     
/* 130 */     } catch (AxisFault axisFaultException) {
/* 131 */       throw axisFaultException;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\WebServices\WebServiceClients\KYCWebServiceClient\KYCWebServiceClient\KYCRAORServiceSoapBindingStub.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */