/*     */ package WEB-INF.classes.WebServices.WebServiceClients.KYCWebServiceClient.KYCWebServiceClient;
/*     */ 
/*     */ import Utilities.LoadProperties;
/*     */ import WebServices.WebServiceClients.KYCWebServiceClient.KYCWebServiceClient.IKYCRAORService;
/*     */ import WebServices.WebServiceClients.KYCWebServiceClient.KYCWebServiceClient.KYCRAORServiceSoapBindingStub;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.rmi.Remote;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.ServiceException;
/*     */ import org.apache.axis.AxisFault;
/*     */ import org.apache.axis.EngineConfiguration;
/*     */ import org.apache.axis.client.Service;
/*     */ 
/*     */ public class IKYCRAORServiceServiceLocator extends Service implements IKYCRAORServiceService {
/*     */   private String KYCRAORService_address;
/*     */   private String KYCRAORServiceWSDDServiceName;
/*     */   private HashSet ports;
/*     */   
/*  22 */   public IKYCRAORServiceServiceLocator(EngineConfiguration config) { super(config);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  32 */     this.KYCRAORService_address = "http://" + LoadProperties.getConf().getProperty("kyc.webservice.ip") + ":" + LoadProperties.getConf().getProperty("kyc.webservice.port") + "/ofsaa/services/KYCRAORService";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  38 */     this.KYCRAORServiceWSDDServiceName = "KYCRAORService";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     this.ports = null; } public IKYCRAORServiceServiceLocator() { this.KYCRAORService_address = "http://" + LoadProperties.getConf().getProperty("kyc.webservice.ip") + ":" + LoadProperties.getConf().getProperty("kyc.webservice.port") + "/ofsaa/services/KYCRAORService"; this.KYCRAORServiceWSDDServiceName = "KYCRAORService"; this.ports = null; } public IKYCRAORServiceServiceLocator(String wsdlLoc, QName sName) throws ServiceException { super(wsdlLoc, sName); this.KYCRAORService_address = "http://" + LoadProperties.getConf().getProperty("kyc.webservice.ip") + ":" + LoadProperties.getConf().getProperty("kyc.webservice.port") + "/ofsaa/services/KYCRAORService"; this.KYCRAORServiceWSDDServiceName = "KYCRAORService"; this.ports = null; }
/*     */   public String getKYCRAORServiceAddress() { return this.KYCRAORService_address; }
/*     */   public String getKYCRAORServiceWSDDServiceName() { return this.KYCRAORServiceWSDDServiceName; }
/* 107 */   public void setKYCRAORServiceWSDDServiceName(String name) { this.KYCRAORServiceWSDDServiceName = name; } public IKYCRAORService getKYCRAORService() throws ServiceException { URL endpoint; try { endpoint = new URL(this.KYCRAORService_address); } catch (MalformedURLException e) { throw new ServiceException(e); }  return getKYCRAORService(endpoint); } public Iterator getPorts() { if (this.ports == null) {
/* 108 */       this.ports = new HashSet();
/* 109 */       this.ports.add(new QName("urn:KYCRAORService", "KYCRAORService"));
/*     */     } 
/* 111 */     return this.ports.iterator(); }
/*     */   public IKYCRAORService getKYCRAORService(URL portAddress) throws ServiceException { try { KYCRAORServiceSoapBindingStub _stub = new KYCRAORServiceSoapBindingStub(portAddress, this); _stub.setPortName(getKYCRAORServiceWSDDServiceName()); return (IKYCRAORService)_stub; } catch (AxisFault e) { return null; }  }
/*     */   public void setKYCRAORServiceEndpointAddress(String address) { this.KYCRAORService_address = address; }
/*     */   public Remote getPort(Class<?> serviceEndpointInterface) throws ServiceException { try { if (IKYCRAORService.class.isAssignableFrom(serviceEndpointInterface)) { KYCRAORServiceSoapBindingStub _stub = new KYCRAORServiceSoapBindingStub(new URL(this.KYCRAORService_address), this); _stub.setPortName(getKYCRAORServiceWSDDServiceName()); return (Remote)_stub; }  } catch (Throwable t) { throw new ServiceException(t); }  throw new ServiceException("There is no stub implementation for the interface:  " + ((serviceEndpointInterface == null) ? "null" : serviceEndpointInterface.getName())); }
/* 115 */   public Remote getPort(QName portName, Class serviceEndpointInterface) throws ServiceException { if (portName == null) return getPort(serviceEndpointInterface);  String inputPortName = portName.getLocalPart(); if ("KYCRAORService".equals(inputPortName)) return (Remote)getKYCRAORService();  Remote _stub = getPort(serviceEndpointInterface); ((Stub)_stub).setPortName(portName); return _stub; } public QName getServiceName() { return new QName("urn:KYCRAORService", "IKYCRAORServiceService"); } public void setEndpointAddress(String portName, String address) throws ServiceException { if ("KYCRAORService".equals(portName)) {
/* 116 */       setKYCRAORServiceEndpointAddress(address);
/*     */     } else {
/*     */       
/* 119 */       throw new ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
/*     */     }  }
/*     */ 
/*     */   
/*     */   public void setEndpointAddress(QName portName, String address) throws ServiceException {
/* 124 */     setEndpointAddress(portName.getLocalPart(), address);
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\WebServices\WebServiceClients\KYCWebServiceClient\KYCWebServiceClient\IKYCRAORServiceServiceLocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */