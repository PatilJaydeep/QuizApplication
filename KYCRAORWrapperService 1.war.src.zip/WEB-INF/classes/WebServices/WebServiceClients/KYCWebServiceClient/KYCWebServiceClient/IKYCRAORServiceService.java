package WEB-INF.classes.WebServices.WebServiceClients.KYCWebServiceClient.KYCWebServiceClient;

import WebServices.WebServiceClients.KYCWebServiceClient.KYCWebServiceClient.IKYCRAORService;
import java.net.URL;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;

public interface IKYCRAORServiceService extends Service {
  String getKYCRAORServiceAddress();
  
  IKYCRAORService getKYCRAORService() throws ServiceException;
  
  IKYCRAORService getKYCRAORService(URL paramURL) throws ServiceException;
}


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\WebServices\WebServiceClients\KYCWebServiceClient\KYCWebServiceClient\IKYCRAORServiceService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */