package WEB-INF.classes.WebServices.WebServiceClients.KYCWebServiceClient.KYCWebServiceClient;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IKYCRAORService extends Remote {
  String doRealTimeRiskRating(String paramString1, String paramString2, String paramString3) throws RemoteException;
}


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\WebServices\WebServiceClients\KYCWebServiceClient\KYCWebServiceClient\IKYCRAORService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */