/*    */ package WEB-INF.classes.WebServices.KYCWrapperService;
/*    */ 
/*    */ import DAL.WrapperService;
/*    */ import Logging.Log4j;
/*    */ import javax.jws.WebMethod;
/*    */ import javax.jws.WebParam;
/*    */ import javax.jws.WebService;
/*    */ 
/*    */ @WebService(serviceName = "KYCWrapperService")
/*    */ public class KYCWrapperService
/*    */ {
/*    */   @WebMethod(operationName = "invokeRealTimeRiskRating")
/*    */   public String invokeRealTimeRiskRating(@WebParam(name = "in0") String in0, @WebParam(name = "in1") String in1, @WebParam(name = "in2") String in2) {
/* 14 */     System.out.println("District");
/* 15 */     WrapperService wrapperService = new WrapperService();
/* 16 */     Log4j.getLog().info("Initiating invokeRealTimeRiskRating wrapper webservice");
/* 17 */     String wrapperServiceResponse = "";
/* 18 */     wrapperServiceResponse = wrapperService.createWrapperServiceResponse(in0, in1, in2);
/* 19 */     Log4j.getLog().info("Finishing invokeRealTimeRiskRating wrapper webservice");
/* 20 */     return wrapperServiceResponse;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\WebServices\KYCWrapperService\KYCWrapperService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */