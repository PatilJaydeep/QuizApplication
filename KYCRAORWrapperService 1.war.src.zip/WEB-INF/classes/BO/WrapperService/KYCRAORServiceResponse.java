/*     */ package WEB-INF.classes.BO.WrapperService;
/*     */ 
/*     */ import BO.WrapperService.IndiciaAttributes;
/*     */ import BO.WrapperService.Shareholders;
/*     */ import BO.WrapperService.WatchList;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ @XmlRootElement(name = "KYCRAORServiceResponse")
/*     */ @XmlType(propOrder = {"dataAvailable", "customerId", "customerTypeMissing", "accountMismatch", "RAORiskScore", "RAORiskCategory", "error", "customerType", "indiciaAttributes", "fatcaOrgType", "shareholders", "overallIndicia", "GIINAvailable", "message", "territoryRegion", "fatcaStatus", "fatcaFormType", "watchlist"})
/*     */ public class KYCRAORServiceResponse
/*     */ {
/*     */   private String DataAvailable;
/*     */   private String CustomerId;
/*     */   private String CustomerTypeMissing;
/*     */   private String AccountMismatch;
/*     */   private String RAORiskScore;
/*     */   private String RAORiskCategory;
/*     */   private String Error;
/*     */   private WatchList watchlist;
/*     */   private String CustomerType;
/*     */   private IndiciaAttributes indiciaAttributes;
/*     */   private String FatcaOrgType;
/*     */   private Shareholders shareholders;
/*     */   private String OverallIndicia;
/*     */   private String GIINAvailable;
/*     */   private String Message;
/*     */   private String TerritoryRegion;
/*     */   private String FatcaStatus;
/*     */   private String FatcaFormType;
/*     */   
/*     */   @XmlElement(name = "DataAvailable")
/*     */   public String getDataAvailable() {
/*  35 */     return this.DataAvailable;
/*     */   }
/*     */   
/*     */   public void setDataAvailable(String DataAvailable) {
/*  39 */     this.DataAvailable = DataAvailable;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CustomerId")
/*     */   public String getCustomerId() {
/*  44 */     return this.CustomerId;
/*     */   }
/*     */   
/*     */   public void setCustomerId(String CustomerId) {
/*  48 */     this.CustomerId = CustomerId;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CustomerTypeMissing")
/*     */   public String getCustomerTypeMissing() {
/*  53 */     return this.CustomerTypeMissing;
/*     */   }
/*     */   
/*     */   public void setCustomerTypeMissing(String CustomerTypeMissing) {
/*  57 */     this.CustomerTypeMissing = CustomerTypeMissing;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "AccountMismatch")
/*     */   public String getAccountMismatch() {
/*  62 */     return this.AccountMismatch;
/*     */   }
/*     */   
/*     */   public void setAccountMismatch(String AccountMismatch) {
/*  66 */     this.AccountMismatch = AccountMismatch;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "RAORiskScore")
/*     */   public String getRAORiskScore() {
/*  71 */     return this.RAORiskScore;
/*     */   }
/*     */   
/*     */   public void setRAORiskScore(String RAORiskScore) {
/*  75 */     this.RAORiskScore = RAORiskScore;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "RAORiskCategory")
/*     */   public String getRAORiskCategory() {
/*  80 */     return this.RAORiskCategory;
/*     */   }
/*     */   
/*     */   public void setRAORiskCategory(String RAORiskCategory) {
/*  84 */     this.RAORiskCategory = RAORiskCategory;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "Error")
/*     */   public String getError() {
/*  89 */     return this.Error;
/*     */   }
/*     */   
/*     */   public void setError(String Error) {
/*  93 */     this.Error = Error;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "WatchList")
/*     */   public WatchList getWatchlist() {
/*  98 */     return this.watchlist;
/*     */   }
/*     */   
/*     */   public void setWatchlist(WatchList watchlist) {
/* 102 */     this.watchlist = watchlist;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CustomerType")
/*     */   public String getCustomerType() {
/* 107 */     return this.CustomerType;
/*     */   }
/*     */   
/*     */   public void setCustomerType(String CustomerType) {
/* 111 */     this.CustomerType = CustomerType;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "IndiciaAttributes")
/*     */   public IndiciaAttributes getIndiciaAttributes() {
/* 116 */     return this.indiciaAttributes;
/*     */   }
/*     */   
/*     */   public void setIndiciaAttributes(IndiciaAttributes indiciaAttributes) {
/* 120 */     this.indiciaAttributes = indiciaAttributes;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "FatcaOrgType")
/*     */   public String getFatcaOrgType() {
/* 125 */     return this.FatcaOrgType;
/*     */   }
/*     */   
/*     */   public void setFatcaOrgType(String FatcaOrgType) {
/* 129 */     this.FatcaOrgType = FatcaOrgType;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "Shareholders")
/*     */   public Shareholders getShareholders() {
/* 134 */     return this.shareholders;
/*     */   }
/*     */   
/*     */   public void setShareholders(Shareholders shareholders) {
/* 138 */     this.shareholders = shareholders;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "OverallIndicia")
/*     */   public String getOverallIndicia() {
/* 143 */     return this.OverallIndicia;
/*     */   }
/*     */   
/*     */   public void setOverallIndicia(String OverallIndicia) {
/* 147 */     this.OverallIndicia = OverallIndicia;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "GIINAvailable")
/*     */   public String getGIINAvailable() {
/* 152 */     return this.GIINAvailable;
/*     */   }
/*     */   
/*     */   public void setGIINAvailable(String GIINAvailable) {
/* 156 */     this.GIINAvailable = GIINAvailable;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "Message")
/*     */   public String getMessage() {
/* 161 */     return this.Message;
/*     */   }
/*     */   
/*     */   public void setMessage(String Message) {
/* 165 */     this.Message = Message;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "TerritoryRegion")
/*     */   public String getTerritoryRegion() {
/* 170 */     return this.TerritoryRegion;
/*     */   }
/*     */   
/*     */   public void setTerritoryRegion(String TerritoryRegion) {
/* 174 */     this.TerritoryRegion = TerritoryRegion;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "FatcaStatus")
/*     */   public String getFatcaStatus() {
/* 179 */     return this.FatcaStatus;
/*     */   }
/*     */   
/*     */   public void setFatcaStatus(String FatcaStatus) {
/* 183 */     this.FatcaStatus = FatcaStatus;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "FatcaFormType")
/*     */   public String getFatcaFormType() {
/* 188 */     return this.FatcaFormType;
/*     */   }
/*     */   
/*     */   public void setFatcaFormType(String FatcaFormType) {
/* 192 */     this.FatcaFormType = FatcaFormType;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WrapperService\KYCRAORServiceResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */