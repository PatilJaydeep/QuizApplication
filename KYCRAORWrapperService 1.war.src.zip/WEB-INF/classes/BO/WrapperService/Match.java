/*    */ package WEB-INF.classes.BO.WrapperService;
/*    */ 
/*    */ import BO.WrapperService.Match;
/*    */ import java.util.Comparator;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ public class Match
/*    */   implements Comparator<Match>
/*    */ {
/*    */   private String WatchListLegalName;
/*    */   private String WatchListName;
/*    */   private String WatchListCustomerType;
/*    */   private int WatchListScore;
/*    */   
/*    */   public String getWatchListLegalName() {
/* 18 */     return this.WatchListLegalName;
/*    */   }
/*    */   
/*    */   public void setWatchListLegalName(String WatchListLegalName) {
/* 22 */     this.WatchListLegalName = WatchListLegalName;
/*    */   }
/*    */   
/*    */   public String getWatchListName() {
/* 26 */     return this.WatchListName;
/*    */   }
/*    */   
/*    */   public void setWatchListName(String WatchListName) {
/* 30 */     this.WatchListName = WatchListName;
/*    */   }
/*    */   
/*    */   public int getWatchListScore() {
/* 34 */     return this.WatchListScore;
/*    */   }
/*    */   
/*    */   public void setWatchListScore(int WatchListScore) {
/* 38 */     this.WatchListScore = WatchListScore;
/*    */   }
/*    */   
/*    */   public String getWatchListCustomerType() {
/* 42 */     return this.WatchListCustomerType;
/*    */   }
/*    */   
/*    */   public void setWatchListCustomerType(String WatchListCustomerType) {
/* 46 */     this.WatchListCustomerType = WatchListCustomerType;
/*    */   }
/*    */   
/*    */   public int compare(Match d, Match d1) {
/* 50 */     return d1.WatchListScore - d.WatchListScore;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WrapperService\Match.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */