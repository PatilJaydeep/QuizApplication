/*    */ package WEB-INF.classes.BO.WrapperService;
/*    */ 
/*    */ import BO.WrapperService.IndiciaAttributes;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ @XmlRootElement(name = "Shareholder")
/*    */ @XmlType(propOrder = {"shareholderId", "shareholderType", "indiciaAttributes", "fatcaOrgType"})
/*    */ public class Shareholder
/*    */ {
/*    */   private String ShareholderId;
/*    */   private String ShareholderType;
/*    */   private IndiciaAttributes indiciaAttributes;
/*    */   private String FatcaOrgType;
/*    */   
/*    */   @XmlElement(name = "ShareholderId")
/*    */   public String getShareholderId() {
/* 19 */     return this.ShareholderId;
/*    */   }
/*    */   
/*    */   public void setShareholderId(String ShareholderId) {
/* 23 */     this.ShareholderId = ShareholderId;
/*    */   }
/*    */   
/*    */   @XmlElement(name = "ShareholderType")
/*    */   public String getShareholderType() {
/* 28 */     return this.ShareholderType;
/*    */   }
/*    */   
/*    */   public void setShareholderType(String ShareholderType) {
/* 32 */     this.ShareholderType = ShareholderType;
/*    */   }
/*    */   
/*    */   @XmlElement(name = "IndiciaAttributes")
/*    */   public IndiciaAttributes getIndiciaAttributes() {
/* 37 */     return this.indiciaAttributes;
/*    */   }
/*    */   
/*    */   public void setIndiciaAttributes(IndiciaAttributes indiciaAttributes) {
/* 41 */     this.indiciaAttributes = indiciaAttributes;
/*    */   }
/*    */   
/*    */   @XmlElement(name = "FatcaOrgType")
/*    */   public String getFatcaOrgType() {
/* 46 */     return this.FatcaOrgType;
/*    */   }
/*    */   
/*    */   public void setFatcaOrgType(String FatcaOrgType) {
/* 50 */     this.FatcaOrgType = FatcaOrgType;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WrapperService\Shareholder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */