/*     */ package WEB-INF.classes.BO.WrapperService;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ @XmlRootElement(name = "IndiciaAttributes")
/*     */ @XmlType(propOrder = {"indicia", "countryOfIncorporation", "countryOfBusinessAddress", "countryOfFax", "countryOfNationality", "greenCard", "countryOfResidence", "countryOfBirth", "countryOfAddress", "powerOfAttorney", "standingInstructions", "mailHandlingInstructions", "countryOfPhoneNumber", "entityControlledByUsIndicia"})
/*     */ public class IndiciaAttributes
/*     */ {
/*     */   private String Indicia;
/*     */   private String CountryOfIncorporation;
/*     */   private String CountryOfBusinessAddress;
/*     */   private String CountryOfFax;
/*     */   private String CountryOfPhoneNumber;
/*     */   private String CountryOfNationality;
/*     */   private String GreenCard;
/*     */   private String CountryOfResidence;
/*     */   private String CountryOfBirth;
/*     */   private String CountryOfAddress;
/*     */   private String PowerOfAttorney;
/*     */   private String StandingInstructions;
/*     */   private String MailHandlingInstructions;
/*     */   private String EntityControlledByUsIndicia;
/*     */   
/*     */   @XmlElement(name = "Indicia")
/*     */   public String getIndicia() {
/*  28 */     return this.Indicia;
/*     */   }
/*     */   
/*     */   public void setIndicia(String Indicia) {
/*  32 */     this.Indicia = Indicia;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CountryOfIncorporation")
/*     */   public String getCountryOfIncorporation() {
/*  37 */     return this.CountryOfIncorporation;
/*     */   }
/*     */   
/*     */   public void setCountryOfIncorporation(String CountryOfIncorporation) {
/*  41 */     this.CountryOfIncorporation = CountryOfIncorporation;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CountryOfBusinessAddress")
/*     */   public String getCountryOfBusinessAddress() {
/*  46 */     return this.CountryOfBusinessAddress;
/*     */   }
/*     */   
/*     */   public void setCountryOfBusinessAddress(String CountryOfBusinessAddress) {
/*  50 */     this.CountryOfBusinessAddress = CountryOfBusinessAddress;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CountryOfFax")
/*     */   public String getCountryOfFax() {
/*  55 */     return this.CountryOfFax;
/*     */   }
/*     */   
/*     */   public void setCountryOfFax(String CountryOfFax) {
/*  59 */     this.CountryOfFax = CountryOfFax;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CountryOfPhoneNumber")
/*     */   public String getCountryOfPhoneNumber() {
/*  64 */     return this.CountryOfPhoneNumber;
/*     */   }
/*     */   
/*     */   public void setCountryOfPhoneNumber(String CountryOfPhoneNumber) {
/*  68 */     this.CountryOfPhoneNumber = CountryOfPhoneNumber;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CountryOfNationality")
/*     */   public String getCountryOfNationality() {
/*  73 */     return this.CountryOfNationality;
/*     */   }
/*     */   
/*     */   public void setCountryOfNationality(String CountryOfNationality) {
/*  77 */     this.CountryOfNationality = CountryOfNationality;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "GreenCard")
/*     */   public String getGreenCard() {
/*  82 */     return this.GreenCard;
/*     */   }
/*     */   
/*     */   public void setGreenCard(String GreenCard) {
/*  86 */     this.GreenCard = GreenCard;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CountryOfResidence")
/*     */   public String getCountryOfResidence() {
/*  91 */     return this.CountryOfResidence;
/*     */   }
/*     */   
/*     */   public void setCountryOfResidence(String CountryOfResidence) {
/*  95 */     this.CountryOfResidence = CountryOfResidence;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CountryOfBirth")
/*     */   public String getCountryOfBirth() {
/* 100 */     return this.CountryOfBirth;
/*     */   }
/*     */   
/*     */   public void setCountryOfBirth(String CountryOfBirth) {
/* 104 */     this.CountryOfBirth = CountryOfBirth;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CountryOfAddress")
/*     */   public String getCountryOfAddress() {
/* 109 */     return this.CountryOfAddress;
/*     */   }
/*     */   
/*     */   public void setCountryOfAddress(String CountryOfAddress) {
/* 113 */     this.CountryOfAddress = CountryOfAddress;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "PowerOfAttorney")
/*     */   public String getPowerOfAttorney() {
/* 118 */     return this.PowerOfAttorney;
/*     */   }
/*     */   
/*     */   public void setPowerOfAttorney(String PowerOfAttorney) {
/* 122 */     this.PowerOfAttorney = PowerOfAttorney;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "StandingInstructions")
/*     */   public String getStandingInstructions() {
/* 127 */     return this.StandingInstructions;
/*     */   }
/*     */   
/*     */   public void setStandingInstructions(String StandingInstructions) {
/* 131 */     this.StandingInstructions = StandingInstructions;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "MailHandlingInstructions")
/*     */   public String getMailHandlingInstructions() {
/* 136 */     return this.MailHandlingInstructions;
/*     */   }
/*     */   
/*     */   public void setMailHandlingInstructions(String MailHandlingInstructions) {
/* 140 */     this.MailHandlingInstructions = MailHandlingInstructions;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "EntityControlledByUsIndicia")
/*     */   public String getEntityControlledByUsIndicia() {
/* 145 */     return this.EntityControlledByUsIndicia;
/*     */   }
/*     */   
/*     */   public void setEntityControlledByUsIndicia(String EntityControlledByUsIndicia) {
/* 149 */     this.EntityControlledByUsIndicia = EntityControlledByUsIndicia;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WrapperService\IndiciaAttributes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */