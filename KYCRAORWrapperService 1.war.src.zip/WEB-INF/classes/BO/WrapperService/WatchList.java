/*    */ package WEB-INF.classes.BO.WrapperService;
/*    */ 
/*    */ import BO.WrapperService.Match;
/*    */ import java.util.ArrayList;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement(name = "WatchList")
/*    */ public class WatchList
/*    */ {
/*    */   private ArrayList<Match> match;
/*    */   
/*    */   @XmlElement(name = "Match")
/*    */   public ArrayList<Match> getMatch() {
/* 15 */     return this.match;
/*    */   }
/*    */   
/*    */   public void setMatch(ArrayList<Match> match) {
/* 19 */     this.match = match;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WrapperService\WatchList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */