/*    */ package WEB-INF.classes.BO.WrapperService;
/*    */ 
/*    */ import BO.WrapperService.Shareholder;
/*    */ import java.util.ArrayList;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ @XmlRootElement(name = "Shareholders")
/*    */ @XmlType(propOrder = {"shareholderIndicia", "shareholder"})
/*    */ public class Shareholders
/*    */ {
/*    */   private String ShareholderIndicia;
/*    */   private ArrayList<Shareholder> shareholder;
/*    */   
/*    */   @XmlElement(name = "ShareholderIndicia")
/*    */   public String getShareholderIndicia() {
/* 18 */     return this.ShareholderIndicia;
/*    */   }
/*    */   
/*    */   public void setShareholderIndicia(String ShareholderIndicia) {
/* 22 */     this.ShareholderIndicia = ShareholderIndicia;
/*    */   }
/*    */   
/*    */   @XmlElement(name = "Shareholder")
/*    */   public ArrayList<Shareholder> getShareholder() {
/* 27 */     return this.shareholder;
/*    */   }
/*    */   
/*    */   public void setShareholder(ArrayList<Shareholder> shareholder) {
/* 31 */     this.shareholder = shareholder;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WrapperService\Shareholders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */