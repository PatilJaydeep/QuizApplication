/*     */ package WEB-INF.classes.BO.WatchList;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.description.ElementDesc;
/*     */ import org.apache.axis.description.FieldDesc;
/*     */ import org.apache.axis.description.TypeDesc;
/*     */ import org.apache.axis.encoding.Deserializer;
/*     */ import org.apache.axis.encoding.Serializer;
/*     */ import org.apache.axis.encoding.ser.BeanDeserializer;
/*     */ import org.apache.axis.encoding.ser.BeanSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Address_type
/*     */   implements Serializable
/*     */ {
/*     */   private String country;
/*     */   private String city;
/*     */   private String postalCode;
/*     */   private Object __equalsCalc;
/*     */   private boolean __hashCodeCalc;
/*     */   
/*     */   public Address_type(String country, String city, String postalCode) {
/*  50 */     this.__equalsCalc = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     this.__hashCodeCalc = false; this.country = country; this.city = city; this.postalCode = postalCode;
/*     */   }
/*     */   public String getCountry() { return this.country; }
/*  75 */   public void setCountry(String country) { this.country = country; } public String getCity() { return this.city; } public synchronized int hashCode() { if (this.__hashCodeCalc) {
/*  76 */       return 0;
/*     */     }
/*  78 */     this.__hashCodeCalc = true;
/*  79 */     int _hashCode = 1;
/*  80 */     if (getCountry() != null) {
/*  81 */       _hashCode += getCountry().hashCode();
/*     */     }
/*  83 */     if (getCity() != null) {
/*  84 */       _hashCode += getCity().hashCode();
/*     */     }
/*  86 */     if (getPostalCode() != null) {
/*  87 */       _hashCode += getPostalCode().hashCode();
/*     */     }
/*  89 */     this.__hashCodeCalc = false;
/*  90 */     return _hashCode; }
/*     */   public void setCity(String city) { this.city = city; }
/*     */   public String getPostalCode() { return this.postalCode; }
/*  93 */   public void setPostalCode(String postalCode) { this.postalCode = postalCode; } public synchronized boolean equals(Object obj) { if (!(obj instanceof BO.WatchList.Address_type)) return false;  BO.WatchList.Address_type other = (BO.WatchList.Address_type)obj; if (obj == null) return false;  if (this == obj) return true;  if (this.__equalsCalc != null) return (this.__equalsCalc == obj);  this.__equalsCalc = obj; boolean _equals = (((this.country == null && other.getCountry() == null) || (this.country != null && this.country.equals(other.getCountry()))) && ((this.city == null && other.getCity() == null) || (this.city != null && this.city.equals(other.getCity()))) && ((this.postalCode == null && other.getPostalCode() == null) || (this.postalCode != null && this.postalCode.equals(other.getPostalCode())))); this.__equalsCalc = null; return _equals; } private static TypeDesc typeDesc = new TypeDesc(BO.WatchList.Address_type.class, true);
/*     */   
/*     */   static {
/*  96 */     typeDesc.setXmlType(new QName("http://namespaces.mantas.com", "address_type"));
/*  97 */     ElementDesc elemField = new ElementDesc();
/*  98 */     elemField.setFieldName("country");
/*  99 */     elemField.setXmlName(new QName("", "Country"));
/* 100 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
/* 101 */     elemField.setNillable(false);
/* 102 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 103 */     elemField = new ElementDesc();
/* 104 */     elemField.setFieldName("city");
/* 105 */     elemField.setXmlName(new QName("", "City"));
/* 106 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
/* 107 */     elemField.setMinOccurs(0);
/* 108 */     elemField.setNillable(false);
/* 109 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 110 */     elemField = new ElementDesc();
/* 111 */     elemField.setFieldName("postalCode");
/* 112 */     elemField.setXmlName(new QName("", "PostalCode"));
/* 113 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
/* 114 */     elemField.setMinOccurs(0);
/* 115 */     elemField.setNillable(false);
/* 116 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/*     */   }
/*     */   
/*     */   public static TypeDesc getTypeDesc() {
/* 120 */     return typeDesc;
/*     */   }
/*     */   
/*     */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType) {
/* 124 */     return (Serializer)new BeanSerializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType) {
/* 128 */     return (Deserializer)new BeanDeserializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public Address_type() {
/*     */     this.__equalsCalc = null;
/*     */     this.__hashCodeCalc = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WatchList\Address_type.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */