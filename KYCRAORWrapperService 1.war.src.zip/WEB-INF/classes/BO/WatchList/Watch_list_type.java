/*    */ package WEB-INF.classes.BO.WatchList;
/*    */ 
/*    */ import java.io.ObjectStreamException;
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.description.TypeDesc;
/*    */ import org.apache.axis.encoding.Deserializer;
/*    */ import org.apache.axis.encoding.Serializer;
/*    */ import org.apache.axis.encoding.ser.EnumDeserializer;
/*    */ import org.apache.axis.encoding.ser.EnumSerializer;
/*    */ 
/*    */ public class Watch_list_type
/*    */   implements Serializable {
/* 15 */   private static HashMap _table_ = new HashMap<Object, Object>();
/*    */   private String _value_;
/*    */   public static final String _Risk = "Risk";
/*    */   public static final String _Trusted = "Trusted";
/*    */   public static final String _Exemption = "Exemption";
/*    */   
/*    */   protected Watch_list_type(String value) {
/* 22 */     this._value_ = value;
/* 23 */     _table_.put(this._value_, this);
/*    */   }
/*    */   
/* 26 */   public static final BO.WatchList.Watch_list_type Risk = new BO.WatchList.Watch_list_type("Risk");
/* 27 */   public static final BO.WatchList.Watch_list_type Trusted = new BO.WatchList.Watch_list_type("Trusted");
/* 28 */   public static final BO.WatchList.Watch_list_type Exemption = new BO.WatchList.Watch_list_type("Exemption");
/*    */   
/*    */   public String getValue() {
/* 31 */     return this._value_;
/*    */   }
/*    */   
/*    */   public static BO.WatchList.Watch_list_type fromValue(String value) throws IllegalArgumentException {
/* 35 */     BO.WatchList.Watch_list_type enumeration = (BO.WatchList.Watch_list_type)_table_.get(value);
/* 36 */     if (enumeration == null) {
/* 37 */       throw new IllegalArgumentException();
/*    */     }
/* 39 */     return enumeration;
/*    */   }
/*    */   
/*    */   public static BO.WatchList.Watch_list_type fromString(String value) throws IllegalArgumentException {
/* 43 */     return fromValue(value);
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 47 */     return (obj == this);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 51 */     return toString().hashCode();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 55 */     return this._value_;
/*    */   }
/*    */   
/*    */   public Object readResolve() throws ObjectStreamException {
/* 59 */     return fromValue(this._value_);
/*    */   }
/*    */   
/*    */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType) {
/* 63 */     return (Serializer)new EnumSerializer(_javaType, _xmlType);
/*    */   }
/*    */   
/*    */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType) {
/* 67 */     return (Deserializer)new EnumDeserializer(_javaType, _xmlType);
/*    */   }
/*    */   
/* 70 */   private static TypeDesc typeDesc = new TypeDesc(BO.WatchList.Watch_list_type.class);
/*    */   
/*    */   static {
/* 73 */     typeDesc.setXmlType(new QName("http://namespaces.mantas.com", "watch_list_type"));
/*    */   }
/*    */   
/*    */   public static TypeDesc getTypeDesc() {
/* 77 */     return typeDesc;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WatchList\Watch_list_type.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */