/*     */ package WEB-INF.classes.BO.WatchList;
/*     */ 
/*     */ import BO.WatchList.Candidate_match_type;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.description.ElementDesc;
/*     */ import org.apache.axis.description.FieldDesc;
/*     */ import org.apache.axis.description.TypeDesc;
/*     */ import org.apache.axis.encoding.Deserializer;
/*     */ import org.apache.axis.encoding.Serializer;
/*     */ import org.apache.axis.encoding.ser.BeanDeserializer;
/*     */ import org.apache.axis.encoding.ser.BeanSerializer;
/*     */ import org.apache.axis.types.NonNegativeInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScanWatchListResponse
/*     */   implements Serializable
/*     */ {
/*     */   private Candidate_match_type[] candidateMatch;
/*     */   private NonNegativeInteger personalMatchThreshold;
/*     */   private NonNegativeInteger businessMatchThreshold;
/*     */   private Object __equalsCalc;
/*     */   private boolean __hashCodeCalc;
/*     */   
/*     */   public ScanWatchListResponse(Candidate_match_type[] candidateMatch, NonNegativeInteger personalMatchThreshold, NonNegativeInteger businessMatchThreshold) {
/*  64 */     this.__equalsCalc = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     this.__hashCodeCalc = false; this.candidateMatch = candidateMatch; this.personalMatchThreshold = personalMatchThreshold; this.businessMatchThreshold = businessMatchThreshold;
/*     */   }
/*     */   public Candidate_match_type[] getCandidateMatch() { return this.candidateMatch; }
/*  89 */   public void setCandidateMatch(Candidate_match_type[] candidateMatch) { this.candidateMatch = candidateMatch; } public Candidate_match_type getCandidateMatch(int i) { return this.candidateMatch[i]; } public void setCandidateMatch(int i, Candidate_match_type _value) { this.candidateMatch[i] = _value; } public synchronized int hashCode() { if (this.__hashCodeCalc) {
/*  90 */       return 0;
/*     */     }
/*  92 */     this.__hashCodeCalc = true;
/*  93 */     int _hashCode = 1;
/*  94 */     if (getCandidateMatch() != null) {
/*  95 */       int i = 0;
/*  96 */       for (; i < Array.getLength(getCandidateMatch()); 
/*  97 */         i++) {
/*  98 */         Object obj = Array.get(getCandidateMatch(), i);
/*  99 */         if (obj != null && 
/* 100 */           !obj.getClass().isArray()) {
/* 101 */           _hashCode += obj.hashCode();
/*     */         }
/*     */       } 
/*     */     } 
/* 105 */     if (getPersonalMatchThreshold() != null) {
/* 106 */       _hashCode += getPersonalMatchThreshold().hashCode();
/*     */     }
/* 108 */     if (getBusinessMatchThreshold() != null) {
/* 109 */       _hashCode += getBusinessMatchThreshold().hashCode();
/*     */     }
/* 111 */     this.__hashCodeCalc = false;
/* 112 */     return _hashCode; }
/*     */   public NonNegativeInteger getPersonalMatchThreshold() { return this.personalMatchThreshold; }
/*     */   public void setPersonalMatchThreshold(NonNegativeInteger personalMatchThreshold) { this.personalMatchThreshold = personalMatchThreshold; }
/* 115 */   public NonNegativeInteger getBusinessMatchThreshold() { return this.businessMatchThreshold; } public void setBusinessMatchThreshold(NonNegativeInteger businessMatchThreshold) { this.businessMatchThreshold = businessMatchThreshold; } public synchronized boolean equals(Object obj) { if (!(obj instanceof BO.WatchList.ScanWatchListResponse)) return false;  BO.WatchList.ScanWatchListResponse other = (BO.WatchList.ScanWatchListResponse)obj; if (obj == null) return false;  if (this == obj) return true;  if (this.__equalsCalc != null) return (this.__equalsCalc == obj);  this.__equalsCalc = obj; boolean _equals = (((this.candidateMatch == null && other.getCandidateMatch() == null) || (this.candidateMatch != null && Arrays.equals((Object[])this.candidateMatch, (Object[])other.getCandidateMatch()))) && ((this.personalMatchThreshold == null && other.getPersonalMatchThreshold() == null) || (this.personalMatchThreshold != null && this.personalMatchThreshold.equals(other.getPersonalMatchThreshold()))) && ((this.businessMatchThreshold == null && other.getBusinessMatchThreshold() == null) || (this.businessMatchThreshold != null && this.businessMatchThreshold.equals(other.getBusinessMatchThreshold())))); this.__equalsCalc = null; return _equals; } private static TypeDesc typeDesc = new TypeDesc(BO.WatchList.ScanWatchListResponse.class, true);
/*     */   
/*     */   static {
/* 118 */     typeDesc.setXmlType(new QName("http://namespaces.mantas.com", ">ScanWatchListResponse"));
/* 119 */     ElementDesc elemField = new ElementDesc();
/* 120 */     elemField.setFieldName("candidateMatch");
/* 121 */     elemField.setXmlName(new QName("", "CandidateMatch"));
/* 122 */     elemField.setXmlType(new QName("http://namespaces.mantas.com", "candidate_match_type"));
/* 123 */     elemField.setNillable(false);
/* 124 */     elemField.setMaxOccursUnbounded(true);
/* 125 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 126 */     elemField = new ElementDesc();
/* 127 */     elemField.setFieldName("personalMatchThreshold");
/* 128 */     elemField.setXmlName(new QName("", "PersonalMatchThreshold"));
/* 129 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "nonNegativeInteger"));
/* 130 */     elemField.setNillable(false);
/* 131 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 132 */     elemField = new ElementDesc();
/* 133 */     elemField.setFieldName("businessMatchThreshold");
/* 134 */     elemField.setXmlName(new QName("", "BusinessMatchThreshold"));
/* 135 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "nonNegativeInteger"));
/* 136 */     elemField.setNillable(false);
/* 137 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/*     */   }
/*     */   
/*     */   public static TypeDesc getTypeDesc() {
/* 141 */     return typeDesc;
/*     */   }
/*     */   
/*     */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType) {
/* 145 */     return (Serializer)new BeanSerializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType) {
/* 149 */     return (Deserializer)new BeanDeserializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public ScanWatchListResponse() {
/*     */     this.__equalsCalc = null;
/*     */     this.__hashCodeCalc = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WatchList\ScanWatchListResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */