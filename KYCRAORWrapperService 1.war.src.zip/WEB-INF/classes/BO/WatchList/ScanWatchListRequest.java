/*     */ package WEB-INF.classes.BO.WatchList;
/*     */ 
/*     */ import BO.WatchList.Candidate_type;
/*     */ import BO.WatchList.MWSS.Security_type;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.description.ElementDesc;
/*     */ import org.apache.axis.description.FieldDesc;
/*     */ import org.apache.axis.description.TypeDesc;
/*     */ import org.apache.axis.encoding.Deserializer;
/*     */ import org.apache.axis.encoding.Serializer;
/*     */ import org.apache.axis.encoding.ser.BeanDeserializer;
/*     */ import org.apache.axis.encoding.ser.BeanSerializer;
/*     */ import org.apache.axis.types.NonNegativeInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScanWatchListRequest
/*     */   implements Serializable
/*     */ {
/*     */   private Security_type security;
/*     */   private Candidate_type[] candidate;
/*     */   private String[] watchListName;
/*     */   private NonNegativeInteger personalMatchThreshold;
/*     */   private NonNegativeInteger businessMatchThreshold;
/*     */   private Object __equalsCalc;
/*     */   private boolean __hashCodeCalc;
/*     */   
/*     */   public ScanWatchListRequest(Security_type security, Candidate_type[] candidate, String[] watchListName, NonNegativeInteger personalMatchThreshold, NonNegativeInteger businessMatchThreshold) {
/*  91 */     this.__equalsCalc = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     this.__hashCodeCalc = false; this.security = security; this.candidate = candidate; this.watchListName = watchListName; this.personalMatchThreshold = personalMatchThreshold; this.businessMatchThreshold = businessMatchThreshold;
/*     */   }
/*     */   public Security_type getSecurity() { return this.security; }
/* 116 */   public void setSecurity(Security_type security) { this.security = security; } public Candidate_type[] getCandidate() { return this.candidate; } public void setCandidate(Candidate_type[] candidate) { this.candidate = candidate; } public Candidate_type getCandidate(int i) { return this.candidate[i]; } public void setCandidate(int i, Candidate_type _value) { this.candidate[i] = _value; } public String[] getWatchListName() { return this.watchListName; } public synchronized int hashCode() { if (this.__hashCodeCalc) {
/* 117 */       return 0;
/*     */     }
/* 119 */     this.__hashCodeCalc = true;
/* 120 */     int _hashCode = 1;
/* 121 */     if (getSecurity() != null) {
/* 122 */       _hashCode += getSecurity().hashCode();
/*     */     }
/* 124 */     if (getCandidate() != null) {
/* 125 */       int i = 0;
/* 126 */       for (; i < Array.getLength(getCandidate()); 
/* 127 */         i++) {
/* 128 */         Object obj = Array.get(getCandidate(), i);
/* 129 */         if (obj != null && 
/* 130 */           !obj.getClass().isArray()) {
/* 131 */           _hashCode += obj.hashCode();
/*     */         }
/*     */       } 
/*     */     } 
/* 135 */     if (getWatchListName() != null) {
/* 136 */       int i = 0;
/* 137 */       for (; i < Array.getLength(getWatchListName()); 
/* 138 */         i++) {
/* 139 */         Object obj = Array.get(getWatchListName(), i);
/* 140 */         if (obj != null && 
/* 141 */           !obj.getClass().isArray()) {
/* 142 */           _hashCode += obj.hashCode();
/*     */         }
/*     */       } 
/*     */     } 
/* 146 */     if (getPersonalMatchThreshold() != null) {
/* 147 */       _hashCode += getPersonalMatchThreshold().hashCode();
/*     */     }
/* 149 */     if (getBusinessMatchThreshold() != null) {
/* 150 */       _hashCode += getBusinessMatchThreshold().hashCode();
/*     */     }
/* 152 */     this.__hashCodeCalc = false;
/* 153 */     return _hashCode; }
/*     */   public void setWatchListName(String[] watchListName) { this.watchListName = watchListName; }
/*     */   public String getWatchListName(int i) { return this.watchListName[i]; }
/* 156 */   public void setWatchListName(int i, String _value) { this.watchListName[i] = _value; } public NonNegativeInteger getPersonalMatchThreshold() { return this.personalMatchThreshold; } public void setPersonalMatchThreshold(NonNegativeInteger personalMatchThreshold) { this.personalMatchThreshold = personalMatchThreshold; } public NonNegativeInteger getBusinessMatchThreshold() { return this.businessMatchThreshold; } public void setBusinessMatchThreshold(NonNegativeInteger businessMatchThreshold) { this.businessMatchThreshold = businessMatchThreshold; } public synchronized boolean equals(Object obj) { if (!(obj instanceof BO.WatchList.ScanWatchListRequest)) return false;  BO.WatchList.ScanWatchListRequest other = (BO.WatchList.ScanWatchListRequest)obj; if (obj == null) return false;  if (this == obj) return true;  if (this.__equalsCalc != null) return (this.__equalsCalc == obj);  this.__equalsCalc = obj; boolean _equals = (((this.security == null && other.getSecurity() == null) || (this.security != null && this.security.equals(other.getSecurity()))) && ((this.candidate == null && other.getCandidate() == null) || (this.candidate != null && Arrays.equals((Object[])this.candidate, (Object[])other.getCandidate()))) && ((this.watchListName == null && other.getWatchListName() == null) || (this.watchListName != null && Arrays.equals((Object[])this.watchListName, (Object[])other.getWatchListName()))) && ((this.personalMatchThreshold == null && other.getPersonalMatchThreshold() == null) || (this.personalMatchThreshold != null && this.personalMatchThreshold.equals(other.getPersonalMatchThreshold()))) && ((this.businessMatchThreshold == null && other.getBusinessMatchThreshold() == null) || (this.businessMatchThreshold != null && this.businessMatchThreshold.equals(other.getBusinessMatchThreshold())))); this.__equalsCalc = null; return _equals; } private static TypeDesc typeDesc = new TypeDesc(BO.WatchList.ScanWatchListRequest.class, true);
/*     */   
/*     */   static {
/* 159 */     typeDesc.setXmlType(new QName("http://namespaces.mantas.com", ">ScanWatchListRequest"));
/* 160 */     ElementDesc elemField = new ElementDesc();
/* 161 */     elemField.setFieldName("security");
/* 162 */     elemField.setXmlName(new QName("http://namespaces.mantas.com/MWSS", "Security"));
/* 163 */     elemField.setXmlType(new QName("http://namespaces.mantas.com/MWSS", "security_type"));
/* 164 */     elemField.setNillable(false);
/* 165 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 166 */     elemField = new ElementDesc();
/* 167 */     elemField.setFieldName("candidate");
/* 168 */     elemField.setXmlName(new QName("", "Candidate"));
/* 169 */     elemField.setXmlType(new QName("http://namespaces.mantas.com", "candidate_type"));
/* 170 */     elemField.setNillable(false);
/* 171 */     elemField.setMaxOccursUnbounded(true);
/* 172 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 173 */     elemField = new ElementDesc();
/* 174 */     elemField.setFieldName("watchListName");
/* 175 */     elemField.setXmlName(new QName("", "WatchListName"));
/* 176 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
/* 177 */     elemField.setMinOccurs(0);
/* 178 */     elemField.setNillable(false);
/* 179 */     elemField.setMaxOccursUnbounded(true);
/* 180 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 181 */     elemField = new ElementDesc();
/* 182 */     elemField.setFieldName("personalMatchThreshold");
/* 183 */     elemField.setXmlName(new QName("", "PersonalMatchThreshold"));
/* 184 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "nonNegativeInteger"));
/* 185 */     elemField.setMinOccurs(0);
/* 186 */     elemField.setNillable(false);
/* 187 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 188 */     elemField = new ElementDesc();
/* 189 */     elemField.setFieldName("businessMatchThreshold");
/* 190 */     elemField.setXmlName(new QName("", "BusinessMatchThreshold"));
/* 191 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "nonNegativeInteger"));
/* 192 */     elemField.setMinOccurs(0);
/* 193 */     elemField.setNillable(false);
/* 194 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/*     */   }
/*     */   
/*     */   public static TypeDesc getTypeDesc() {
/* 198 */     return typeDesc;
/*     */   }
/*     */   
/*     */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType) {
/* 202 */     return (Serializer)new BeanSerializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType) {
/* 206 */     return (Deserializer)new BeanDeserializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public ScanWatchListRequest() {
/*     */     this.__equalsCalc = null;
/*     */     this.__hashCodeCalc = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WatchList\ScanWatchListRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */