/*     */ package WEB-INF.classes.BO.WatchList;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.AxisFault;
/*     */ import org.apache.axis.description.ElementDesc;
/*     */ import org.apache.axis.description.FieldDesc;
/*     */ import org.apache.axis.description.TypeDesc;
/*     */ import org.apache.axis.encoding.Deserializer;
/*     */ import org.apache.axis.encoding.SerializationContext;
/*     */ import org.apache.axis.encoding.Serializer;
/*     */ import org.apache.axis.encoding.ser.BeanDeserializer;
/*     */ import org.apache.axis.encoding.ser.BeanSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Fault_type
/*     */   extends AxisFault
/*     */   implements Serializable
/*     */ {
/*     */   private String errorCode;
/*     */   private String errorMessage;
/*     */   private String errorDescription;
/*     */   private Object __equalsCalc;
/*     */   private boolean __hashCodeCalc;
/*     */   
/*     */   public Fault_type(String errorCode, String errorMessage, String errorDescription) {
/*  54 */     this.__equalsCalc = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     this.__hashCodeCalc = false; this.errorCode = errorCode; this.errorMessage = errorMessage; this.errorDescription = errorDescription;
/*     */   }
/*     */   public String getErrorCode() { return this.errorCode; }
/*  79 */   public void setErrorCode(String errorCode) { this.errorCode = errorCode; } public String getErrorMessage() { return this.errorMessage; } public synchronized int hashCode() { if (this.__hashCodeCalc) {
/*  80 */       return 0;
/*     */     }
/*  82 */     this.__hashCodeCalc = true;
/*  83 */     int _hashCode = 1;
/*  84 */     if (getErrorCode() != null) {
/*  85 */       _hashCode += getErrorCode().hashCode();
/*     */     }
/*  87 */     if (getErrorMessage() != null) {
/*  88 */       _hashCode += getErrorMessage().hashCode();
/*     */     }
/*  90 */     if (getErrorDescription() != null) {
/*  91 */       _hashCode += getErrorDescription().hashCode();
/*     */     }
/*  93 */     this.__hashCodeCalc = false;
/*  94 */     return _hashCode; }
/*     */   public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }
/*     */   public String getErrorDescription() { return this.errorDescription; }
/*  97 */   public void setErrorDescription(String errorDescription) { this.errorDescription = errorDescription; } public synchronized boolean equals(Object obj) { if (!(obj instanceof BO.WatchList.Fault_type)) return false;  BO.WatchList.Fault_type other = (BO.WatchList.Fault_type)obj; if (obj == null) return false;  if (this == obj) return true;  if (this.__equalsCalc != null) return (this.__equalsCalc == obj);  this.__equalsCalc = obj; boolean _equals = (((this.errorCode == null && other.getErrorCode() == null) || (this.errorCode != null && this.errorCode.equals(other.getErrorCode()))) && ((this.errorMessage == null && other.getErrorMessage() == null) || (this.errorMessage != null && this.errorMessage.equals(other.getErrorMessage()))) && ((this.errorDescription == null && other.getErrorDescription() == null) || (this.errorDescription != null && this.errorDescription.equals(other.getErrorDescription())))); this.__equalsCalc = null; return _equals; } private static TypeDesc typeDesc = new TypeDesc(BO.WatchList.Fault_type.class, true);
/*     */   
/*     */   static {
/* 100 */     typeDesc.setXmlType(new QName("http://namespaces.mantas.com", "fault_type"));
/* 101 */     ElementDesc elemField = new ElementDesc();
/* 102 */     elemField.setFieldName("errorCode");
/* 103 */     elemField.setXmlName(new QName("", "ErrorCode"));
/* 104 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
/* 105 */     elemField.setNillable(false);
/* 106 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 107 */     elemField = new ElementDesc();
/* 108 */     elemField.setFieldName("errorMessage");
/* 109 */     elemField.setXmlName(new QName("", "ErrorMessage"));
/* 110 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
/* 111 */     elemField.setMinOccurs(0);
/* 112 */     elemField.setNillable(false);
/* 113 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 114 */     elemField = new ElementDesc();
/* 115 */     elemField.setFieldName("errorDescription");
/* 116 */     elemField.setXmlName(new QName("", "ErrorDescription"));
/* 117 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
/* 118 */     elemField.setMinOccurs(0);
/* 119 */     elemField.setNillable(false);
/* 120 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/*     */   }
/*     */   
/*     */   public static TypeDesc getTypeDesc() {
/* 124 */     return typeDesc;
/*     */   }
/*     */   
/*     */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType) {
/* 128 */     return (Serializer)new BeanSerializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType) {
/* 132 */     return (Deserializer)new BeanDeserializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public void writeDetails(QName qname, SerializationContext context) throws IOException {
/* 136 */     context.serialize(qname, null, this);
/*     */   }
/*     */   
/*     */   public Fault_type() {
/*     */     this.__equalsCalc = null;
/*     */     this.__hashCodeCalc = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WatchList\Fault_type.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */