/*     */ package WEB-INF.classes.BO.WatchList;
/*     */ 
/*     */ import BO.WatchList.Address_type;
/*     */ import BO.WatchList.Watch_list_type;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigInteger;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.description.ElementDesc;
/*     */ import org.apache.axis.description.FieldDesc;
/*     */ import org.apache.axis.description.TypeDesc;
/*     */ import org.apache.axis.encoding.Deserializer;
/*     */ import org.apache.axis.encoding.Serializer;
/*     */ import org.apache.axis.encoding.ser.BeanDeserializer;
/*     */ import org.apache.axis.encoding.ser.BeanSerializer;
/*     */ import org.apache.axis.types.NonNegativeInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Match_type
/*     */   implements Serializable
/*     */ {
/*     */   private String name;
/*     */   private Address_type address;
/*     */   private NonNegativeInteger score;
/*     */   private String watchListName;
/*     */   private Watch_list_type watchListType;
/*     */   private BigInteger degreeOfRisk;
/*     */   private String description;
/*     */   private String matchedScore;
/*     */   private Object __equalsCalc;
/*     */   private boolean __hashCodeCalc;
/*     */   
/*     */   public Match_type(String name, Address_type address, NonNegativeInteger score, String watchListName, Watch_list_type watchListType, BigInteger degreeOfRisk, String description) {
/*  95 */     this.__equalsCalc = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     this.__hashCodeCalc = false; this.name = name; this.address = address; this.score = score; this.watchListName = watchListName; this.watchListType = watchListType; this.degreeOfRisk = degreeOfRisk; this.description = description;
/*     */   }
/*     */   public String getName() { return this.name; }
/* 120 */   public void setName(String name) { this.name = name; } public Address_type getAddress() { return this.address; } public void setAddress(Address_type address) { this.address = address; } public NonNegativeInteger getScore() { return this.score; } public void setScore(NonNegativeInteger score) { this.score = score; } public String getWatchListName() { return this.watchListName; } public synchronized int hashCode() { if (this.__hashCodeCalc) {
/* 121 */       return 0;
/*     */     }
/* 123 */     this.__hashCodeCalc = true;
/* 124 */     int _hashCode = 1;
/* 125 */     if (getName() != null) {
/* 126 */       _hashCode += getName().hashCode();
/*     */     }
/* 128 */     if (getAddress() != null) {
/* 129 */       _hashCode += getAddress().hashCode();
/*     */     }
/* 131 */     if (getScore() != null) {
/* 132 */       _hashCode += getScore().hashCode();
/*     */     }
/* 134 */     if (getWatchListName() != null) {
/* 135 */       _hashCode += getWatchListName().hashCode();
/*     */     }
/* 137 */     if (getWatchListType() != null) {
/* 138 */       _hashCode += getWatchListType().hashCode();
/*     */     }
/* 140 */     if (getDegreeOfRisk() != null) {
/* 141 */       _hashCode += getDegreeOfRisk().hashCode();
/*     */     }
/* 143 */     if (getDescription() != null) {
/* 144 */       _hashCode += getDescription().hashCode();
/*     */     }
/* 146 */     this.__hashCodeCalc = false;
/* 147 */     return _hashCode; }
/*     */   public void setWatchListName(String watchListName) { this.watchListName = watchListName; }
/*     */   public Watch_list_type getWatchListType() { return this.watchListType; }
/* 150 */   public void setWatchListType(Watch_list_type watchListType) { this.watchListType = watchListType; } public BigInteger getDegreeOfRisk() { return this.degreeOfRisk; } public void setDegreeOfRisk(BigInteger degreeOfRisk) { this.degreeOfRisk = degreeOfRisk; } public String getDescription() { return this.description; } public void setDescription(String description) { this.description = description; } public synchronized boolean equals(Object obj) { if (!(obj instanceof BO.WatchList.Match_type)) return false;  BO.WatchList.Match_type other = (BO.WatchList.Match_type)obj; if (obj == null) return false;  if (this == obj) return true;  if (this.__equalsCalc != null) return (this.__equalsCalc == obj);  this.__equalsCalc = obj; boolean _equals = (((this.name == null && other.getName() == null) || (this.name != null && this.name.equals(other.getName()))) && ((this.address == null && other.getAddress() == null) || (this.address != null && this.address.equals(other.getAddress()))) && ((this.score == null && other.getScore() == null) || (this.score != null && this.score.equals(other.getScore()))) && ((this.watchListName == null && other.getWatchListName() == null) || (this.watchListName != null && this.watchListName.equals(other.getWatchListName()))) && ((this.watchListType == null && other.getWatchListType() == null) || (this.watchListType != null && this.watchListType.equals(other.getWatchListType()))) && ((this.degreeOfRisk == null && other.getDegreeOfRisk() == null) || (this.degreeOfRisk != null && this.degreeOfRisk.equals(other.getDegreeOfRisk()))) && ((this.description == null && other.getDescription() == null) || (this.description != null && this.description.equals(other.getDescription())))); this.__equalsCalc = null; return _equals; } private static TypeDesc typeDesc = new TypeDesc(BO.WatchList.Match_type.class, true);
/*     */   
/*     */   static {
/* 153 */     typeDesc.setXmlType(new QName("http://namespaces.mantas.com", "match_type"));
/* 154 */     ElementDesc elemField = new ElementDesc();
/* 155 */     elemField.setFieldName("name");
/* 156 */     elemField.setXmlName(new QName("", "Name"));
/* 157 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
/* 158 */     elemField.setNillable(false);
/* 159 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 160 */     elemField = new ElementDesc();
/* 161 */     elemField.setFieldName("address");
/* 162 */     elemField.setXmlName(new QName("", "Address"));
/* 163 */     elemField.setXmlType(new QName("http://namespaces.mantas.com", "address_type"));
/* 164 */     elemField.setMinOccurs(0);
/* 165 */     elemField.setNillable(false);
/* 166 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 167 */     elemField = new ElementDesc();
/* 168 */     elemField.setFieldName("score");
/* 169 */     elemField.setXmlName(new QName("", "Score"));
/* 170 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "nonNegativeInteger"));
/* 171 */     elemField.setNillable(false);
/* 172 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 173 */     elemField = new ElementDesc();
/* 174 */     elemField.setFieldName("watchListName");
/* 175 */     elemField.setXmlName(new QName("", "WatchListName"));
/* 176 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
/* 177 */     elemField.setNillable(false);
/* 178 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 179 */     elemField = new ElementDesc();
/* 180 */     elemField.setFieldName("watchListType");
/* 181 */     elemField.setXmlName(new QName("", "WatchListType"));
/* 182 */     elemField.setXmlType(new QName("http://namespaces.mantas.com", "watch_list_type"));
/* 183 */     elemField.setNillable(false);
/* 184 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 185 */     elemField = new ElementDesc();
/* 186 */     elemField.setFieldName("degreeOfRisk");
/* 187 */     elemField.setXmlName(new QName("", "DegreeOfRisk"));
/* 188 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "integer"));
/* 189 */     elemField.setMinOccurs(0);
/* 190 */     elemField.setNillable(false);
/* 191 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 192 */     elemField = new ElementDesc();
/* 193 */     elemField.setFieldName("description");
/* 194 */     elemField.setXmlName(new QName("", "Description"));
/* 195 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
/* 196 */     elemField.setMinOccurs(0);
/* 197 */     elemField.setNillable(false);
/* 198 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/*     */   }
/*     */   
/*     */   public static TypeDesc getTypeDesc() {
/* 202 */     return typeDesc;
/*     */   }
/*     */   
/*     */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType) {
/* 206 */     return (Serializer)new BeanSerializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType) {
/* 210 */     return (Deserializer)new BeanDeserializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public String getMatchedScore() {
/* 214 */     return this.matchedScore;
/*     */   }
/*     */   
/*     */   public void setMatchedScore(String matchedScore) {
/* 218 */     this.matchedScore = matchedScore;
/*     */   }
/*     */   
/*     */   public Match_type() {
/*     */     this.__equalsCalc = null;
/*     */     this.__hashCodeCalc = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WatchList\Match_type.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */