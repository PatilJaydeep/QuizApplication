/*     */ package WEB-INF.classes.BO.WatchList.MWSS;
/*     */ 
/*     */ import BO.WatchList.MWSS.Password_type;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.description.ElementDesc;
/*     */ import org.apache.axis.description.FieldDesc;
/*     */ import org.apache.axis.description.TypeDesc;
/*     */ import org.apache.axis.encoding.Deserializer;
/*     */ import org.apache.axis.encoding.Serializer;
/*     */ import org.apache.axis.encoding.ser.BeanDeserializer;
/*     */ import org.apache.axis.encoding.ser.BeanSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Username_token_type
/*     */   implements Serializable
/*     */ {
/*     */   private String username;
/*     */   private Password_type password;
/*     */   private byte[] nonce;
/*     */   private Calendar created;
/*     */   private Object __equalsCalc;
/*     */   private boolean __hashCodeCalc;
/*     */   
/*     */   public Username_token_type(String username, Password_type password, byte[] nonce, Calendar created) {
/*  64 */     this.__equalsCalc = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     this.__hashCodeCalc = false; this.username = username; this.password = password; this.nonce = nonce; this.created = created;
/*     */   }
/*     */   public String getUsername() { return this.username; }
/*  89 */   public void setUsername(String username) { this.username = username; } public Password_type getPassword() { return this.password; } public void setPassword(Password_type password) { this.password = password; } public synchronized int hashCode() { if (this.__hashCodeCalc) {
/*  90 */       return 0;
/*     */     }
/*  92 */     this.__hashCodeCalc = true;
/*  93 */     int _hashCode = 1;
/*  94 */     if (getUsername() != null) {
/*  95 */       _hashCode += getUsername().hashCode();
/*     */     }
/*  97 */     if (getPassword() != null) {
/*  98 */       _hashCode += getPassword().hashCode();
/*     */     }
/* 100 */     if (getNonce() != null) {
/* 101 */       int i = 0;
/* 102 */       for (; i < Array.getLength(getNonce()); 
/* 103 */         i++) {
/* 104 */         Object obj = Array.get(getNonce(), i);
/* 105 */         if (obj != null && 
/* 106 */           !obj.getClass().isArray()) {
/* 107 */           _hashCode += obj.hashCode();
/*     */         }
/*     */       } 
/*     */     } 
/* 111 */     if (getCreated() != null) {
/* 112 */       _hashCode += getCreated().hashCode();
/*     */     }
/* 114 */     this.__hashCodeCalc = false;
/* 115 */     return _hashCode; }
/*     */   public byte[] getNonce() { return this.nonce; }
/*     */   public void setNonce(byte[] nonce) { this.nonce = nonce; }
/* 118 */   public Calendar getCreated() { return this.created; } public void setCreated(Calendar created) { this.created = created; } public synchronized boolean equals(Object obj) { if (!(obj instanceof BO.WatchList.MWSS.Username_token_type)) return false;  BO.WatchList.MWSS.Username_token_type other = (BO.WatchList.MWSS.Username_token_type)obj; if (obj == null) return false;  if (this == obj) return true;  if (this.__equalsCalc != null) return (this.__equalsCalc == obj);  this.__equalsCalc = obj; boolean _equals = (((this.username == null && other.getUsername() == null) || (this.username != null && this.username.equals(other.getUsername()))) && ((this.password == null && other.getPassword() == null) || (this.password != null && this.password.equals(other.getPassword()))) && ((this.nonce == null && other.getNonce() == null) || (this.nonce != null && Arrays.equals(this.nonce, other.getNonce()))) && ((this.created == null && other.getCreated() == null) || (this.created != null && this.created.equals(other.getCreated())))); this.__equalsCalc = null; return _equals; } private static TypeDesc typeDesc = new TypeDesc(BO.WatchList.MWSS.Username_token_type.class, true);
/*     */   
/*     */   static {
/* 121 */     typeDesc.setXmlType(new QName("http://namespaces.mantas.com/MWSS", "username_token_type"));
/* 122 */     ElementDesc elemField = new ElementDesc();
/* 123 */     elemField.setFieldName("username");
/* 124 */     elemField.setXmlName(new QName("", "Username"));
/* 125 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
/* 126 */     elemField.setNillable(false);
/* 127 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 128 */     elemField = new ElementDesc();
/* 129 */     elemField.setFieldName("password");
/* 130 */     elemField.setXmlName(new QName("", "Password"));
/* 131 */     elemField.setXmlType(new QName("http://namespaces.mantas.com/MWSS", "password_type"));
/* 132 */     elemField.setNillable(false);
/* 133 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 134 */     elemField = new ElementDesc();
/* 135 */     elemField.setFieldName("nonce");
/* 136 */     elemField.setXmlName(new QName("", "Nonce"));
/* 137 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "base64Binary"));
/* 138 */     elemField.setMinOccurs(0);
/* 139 */     elemField.setNillable(false);
/* 140 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 141 */     elemField = new ElementDesc();
/* 142 */     elemField.setFieldName("created");
/* 143 */     elemField.setXmlName(new QName("", "Created"));
/* 144 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
/* 145 */     elemField.setMinOccurs(0);
/* 146 */     elemField.setNillable(false);
/* 147 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/*     */   }
/*     */   
/*     */   public static TypeDesc getTypeDesc() {
/* 151 */     return typeDesc;
/*     */   }
/*     */   
/*     */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType) {
/* 155 */     return (Serializer)new BeanSerializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType) {
/* 159 */     return (Deserializer)new BeanDeserializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public Username_token_type() {
/*     */     this.__equalsCalc = null;
/*     */     this.__hashCodeCalc = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WatchList\MWSS\Username_token_type.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */