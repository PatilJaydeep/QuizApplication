/*     */ package WEB-INF.classes.BO.WatchList.MWSS;
/*     */ 
/*     */ import BO.WatchList.MWSS.Password_type_attr;
/*     */ import java.io.Serializable;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.description.AttributeDesc;
/*     */ import org.apache.axis.description.ElementDesc;
/*     */ import org.apache.axis.description.FieldDesc;
/*     */ import org.apache.axis.description.TypeDesc;
/*     */ import org.apache.axis.encoding.Deserializer;
/*     */ import org.apache.axis.encoding.Serializer;
/*     */ import org.apache.axis.encoding.SimpleType;
/*     */ import org.apache.axis.encoding.ser.SimpleDeserializer;
/*     */ import org.apache.axis.encoding.ser.SimpleSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Password_type
/*     */   implements Serializable, SimpleType
/*     */ {
/*     */   private String _value;
/*     */   private Password_type_attr type;
/*     */   private Object __equalsCalc;
/*     */   private boolean __hashCodeCalc;
/*     */   
/*     */   public Password_type(String _value) {
/*  45 */     this.__equalsCalc = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     this.__hashCodeCalc = false; this._value = _value;
/*     */   }
/*     */   public String toString() { return this._value; }
/*  70 */   public String get_value() { return this._value; } public void set_value(String _value) { this._value = _value; } public synchronized int hashCode() { if (this.__hashCodeCalc) {
/*  71 */       return 0;
/*     */     }
/*  73 */     this.__hashCodeCalc = true;
/*  74 */     int _hashCode = 1;
/*  75 */     if (get_value() != null) {
/*  76 */       _hashCode += get_value().hashCode();
/*     */     }
/*  78 */     if (getType() != null) {
/*  79 */       _hashCode += getType().hashCode();
/*     */     }
/*  81 */     this.__hashCodeCalc = false;
/*  82 */     return _hashCode; }
/*     */   public Password_type_attr getType() { return this.type; }
/*     */   public void setType(Password_type_attr type) { this.type = type; }
/*  85 */   public synchronized boolean equals(Object obj) { if (!(obj instanceof BO.WatchList.MWSS.Password_type)) return false;  BO.WatchList.MWSS.Password_type other = (BO.WatchList.MWSS.Password_type)obj; if (obj == null) return false;  if (this == obj) return true;  if (this.__equalsCalc != null) return (this.__equalsCalc == obj);  this.__equalsCalc = obj; boolean _equals = (((this._value == null && other.get_value() == null) || (this._value != null && this._value.equals(other.get_value()))) && ((this.type == null && other.getType() == null) || (this.type != null && this.type.equals(other.getType())))); this.__equalsCalc = null; return _equals; } private static TypeDesc typeDesc = new TypeDesc(BO.WatchList.MWSS.Password_type.class, true);
/*     */   
/*     */   static {
/*  88 */     typeDesc.setXmlType(new QName("http://namespaces.mantas.com/MWSS", "password_type"));
/*  89 */     AttributeDesc attrField = new AttributeDesc();
/*  90 */     attrField.setFieldName("type");
/*  91 */     attrField.setXmlName(new QName("", "Type"));
/*  92 */     attrField.setXmlType(new QName("http://namespaces.mantas.com/MWSS", "password_type_attr"));
/*  93 */     typeDesc.addFieldDesc((FieldDesc)attrField);
/*  94 */     ElementDesc elemField = new ElementDesc();
/*  95 */     elemField.setFieldName("_value");
/*  96 */     elemField.setXmlName(new QName("", "_value"));
/*  97 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
/*  98 */     elemField.setNillable(false);
/*  99 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/*     */   }
/*     */   
/*     */   public static TypeDesc getTypeDesc() {
/* 103 */     return typeDesc;
/*     */   }
/*     */   
/*     */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType) {
/* 107 */     return (Serializer)new SimpleSerializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType) {
/* 111 */     return (Deserializer)new SimpleDeserializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public Password_type() {
/*     */     this.__equalsCalc = null;
/*     */     this.__hashCodeCalc = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WatchList\MWSS\Password_type.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */