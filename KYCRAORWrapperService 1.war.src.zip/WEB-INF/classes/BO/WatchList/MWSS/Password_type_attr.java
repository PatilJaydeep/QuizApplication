/*    */ package WEB-INF.classes.BO.WatchList.MWSS;
/*    */ 
/*    */ import java.io.ObjectStreamException;
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.description.TypeDesc;
/*    */ import org.apache.axis.encoding.Deserializer;
/*    */ import org.apache.axis.encoding.Serializer;
/*    */ import org.apache.axis.encoding.ser.EnumDeserializer;
/*    */ import org.apache.axis.encoding.ser.EnumSerializer;
/*    */ 
/*    */ public class Password_type_attr
/*    */   implements Serializable {
/* 15 */   private static HashMap _table_ = new HashMap<Object, Object>();
/*    */   private String _value_;
/*    */   public static final String _PasswordText = "PasswordText";
/*    */   public static final String _PasswordDigest = "PasswordDigest";
/*    */   
/*    */   protected Password_type_attr(String value) {
/* 21 */     this._value_ = value;
/* 22 */     _table_.put(this._value_, this);
/*    */   }
/*    */   
/* 25 */   public static final BO.WatchList.MWSS.Password_type_attr PasswordText = new BO.WatchList.MWSS.Password_type_attr("PasswordText");
/* 26 */   public static final BO.WatchList.MWSS.Password_type_attr PasswordDigest = new BO.WatchList.MWSS.Password_type_attr("PasswordDigest");
/*    */   
/*    */   public String getValue() {
/* 29 */     return this._value_;
/*    */   }
/*    */   
/*    */   public static BO.WatchList.MWSS.Password_type_attr fromValue(String value) throws IllegalArgumentException {
/* 33 */     BO.WatchList.MWSS.Password_type_attr enumeration = (BO.WatchList.MWSS.Password_type_attr)_table_.get(value);
/* 34 */     if (enumeration == null) {
/* 35 */       throw new IllegalArgumentException();
/*    */     }
/* 37 */     return enumeration;
/*    */   }
/*    */   
/*    */   public static BO.WatchList.MWSS.Password_type_attr fromString(String value) throws IllegalArgumentException {
/* 41 */     return fromValue(value);
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 45 */     return (obj == this);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 49 */     return toString().hashCode();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 53 */     return this._value_;
/*    */   }
/*    */   
/*    */   public Object readResolve() throws ObjectStreamException {
/* 57 */     return fromValue(this._value_);
/*    */   }
/*    */   
/*    */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType) {
/* 61 */     return (Serializer)new EnumSerializer(_javaType, _xmlType);
/*    */   }
/*    */   
/*    */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType) {
/* 65 */     return (Deserializer)new EnumDeserializer(_javaType, _xmlType);
/*    */   }
/*    */   
/* 68 */   private static TypeDesc typeDesc = new TypeDesc(BO.WatchList.MWSS.Password_type_attr.class);
/*    */   
/*    */   static {
/* 71 */     typeDesc.setXmlType(new QName("http://namespaces.mantas.com/MWSS", "password_type_attr"));
/*    */   }
/*    */   
/*    */   public static TypeDesc getTypeDesc() {
/* 75 */     return typeDesc;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WatchList\MWSS\Password_type_attr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */