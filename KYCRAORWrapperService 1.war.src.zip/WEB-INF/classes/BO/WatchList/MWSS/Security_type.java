/*    */ package WEB-INF.classes.BO.WatchList.MWSS;
/*    */ 
/*    */ import BO.WatchList.MWSS.Username_token_type;
/*    */ import java.io.Serializable;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.description.ElementDesc;
/*    */ import org.apache.axis.description.FieldDesc;
/*    */ import org.apache.axis.description.TypeDesc;
/*    */ import org.apache.axis.encoding.Deserializer;
/*    */ import org.apache.axis.encoding.Serializer;
/*    */ import org.apache.axis.encoding.ser.BeanDeserializer;
/*    */ import org.apache.axis.encoding.ser.BeanSerializer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Security_type
/*    */   implements Serializable
/*    */ {
/*    */   private Username_token_type usernameToken;
/*    */   private Object __equalsCalc;
/*    */   private boolean __hashCodeCalc;
/*    */   
/*    */   public Security_type(Username_token_type usernameToken) {
/* 30 */     this.__equalsCalc = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 52 */     this.__hashCodeCalc = false;
/*    */     this.usernameToken = usernameToken;
/*    */   }
/* 55 */   public Username_token_type getUsernameToken() { return this.usernameToken; } public synchronized int hashCode() { if (this.__hashCodeCalc) {
/* 56 */       return 0;
/*    */     }
/* 58 */     this.__hashCodeCalc = true;
/* 59 */     int _hashCode = 1;
/* 60 */     if (getUsernameToken() != null) {
/* 61 */       _hashCode += getUsernameToken().hashCode();
/*    */     }
/* 63 */     this.__hashCodeCalc = false;
/* 64 */     return _hashCode; }
/*    */   public void setUsernameToken(Username_token_type usernameToken) { this.usernameToken = usernameToken; }
/*    */   public synchronized boolean equals(Object obj) { if (!(obj instanceof BO.WatchList.MWSS.Security_type)) return false;  BO.WatchList.MWSS.Security_type other = (BO.WatchList.MWSS.Security_type)obj; if (obj == null) return false;  if (this == obj) return true;  if (this.__equalsCalc != null)
/* 67 */       return (this.__equalsCalc == obj);  this.__equalsCalc = obj; boolean _equals = ((this.usernameToken == null && other.getUsernameToken() == null) || (this.usernameToken != null && this.usernameToken.equals(other.getUsernameToken()))); this.__equalsCalc = null; return _equals; } private static TypeDesc typeDesc = new TypeDesc(BO.WatchList.MWSS.Security_type.class, true);
/*    */   
/*    */   static {
/* 70 */     typeDesc.setXmlType(new QName("http://namespaces.mantas.com/MWSS", "security_type"));
/* 71 */     ElementDesc elemField = new ElementDesc();
/* 72 */     elemField.setFieldName("usernameToken");
/* 73 */     elemField.setXmlName(new QName("", "UsernameToken"));
/* 74 */     elemField.setXmlType(new QName("http://namespaces.mantas.com/MWSS", "username_token_type"));
/* 75 */     elemField.setNillable(false);
/* 76 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/*    */   }
/*    */   
/*    */   public static TypeDesc getTypeDesc() {
/* 80 */     return typeDesc;
/*    */   }
/*    */   
/*    */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType) {
/* 84 */     return (Serializer)new BeanSerializer(_javaType, _xmlType, typeDesc);
/*    */   }
/*    */   
/*    */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType) {
/* 88 */     return (Deserializer)new BeanDeserializer(_javaType, _xmlType, typeDesc);
/*    */   }
/*    */   
/*    */   public Security_type() {
/*    */     this.__equalsCalc = null;
/*    */     this.__hashCodeCalc = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WatchList\MWSS\Security_type.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */