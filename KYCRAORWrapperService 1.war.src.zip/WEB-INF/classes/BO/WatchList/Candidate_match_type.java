/*     */ package WEB-INF.classes.BO.WatchList;
/*     */ 
/*     */ import BO.WatchList.Candidate_type;
/*     */ import BO.WatchList.Match_type;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.description.ElementDesc;
/*     */ import org.apache.axis.description.FieldDesc;
/*     */ import org.apache.axis.description.TypeDesc;
/*     */ import org.apache.axis.encoding.Deserializer;
/*     */ import org.apache.axis.encoding.Serializer;
/*     */ import org.apache.axis.encoding.ser.BeanDeserializer;
/*     */ import org.apache.axis.encoding.ser.BeanSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Candidate_match_type
/*     */   implements Serializable
/*     */ {
/*     */   private Candidate_type candidate;
/*     */   private Match_type[] match;
/*     */   private Object __equalsCalc;
/*     */   private boolean __hashCodeCalc;
/*     */   
/*     */   public Candidate_match_type(Candidate_type candidate, Match_type[] match) {
/*  52 */     this.__equalsCalc = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     this.__hashCodeCalc = false; this.candidate = candidate; this.match = match;
/*     */   }
/*     */   public Candidate_type getCandidate() { return this.candidate; }
/*  77 */   public void setCandidate(Candidate_type candidate) { this.candidate = candidate; } public Match_type[] getMatch() { return this.match; } public synchronized int hashCode() { if (this.__hashCodeCalc) {
/*  78 */       return 0;
/*     */     }
/*  80 */     this.__hashCodeCalc = true;
/*  81 */     int _hashCode = 1;
/*  82 */     if (getCandidate() != null) {
/*  83 */       _hashCode += getCandidate().hashCode();
/*     */     }
/*  85 */     if (getMatch() != null) {
/*  86 */       int i = 0;
/*  87 */       for (; i < Array.getLength(getMatch()); 
/*  88 */         i++) {
/*  89 */         Object obj = Array.get(getMatch(), i);
/*  90 */         if (obj != null && 
/*  91 */           !obj.getClass().isArray()) {
/*  92 */           _hashCode += obj.hashCode();
/*     */         }
/*     */       } 
/*     */     } 
/*  96 */     this.__hashCodeCalc = false;
/*  97 */     return _hashCode; }
/*     */   public void setMatch(Match_type[] match) { this.match = match; }
/*     */   public Match_type getMatch(int i) { return this.match[i]; }
/* 100 */   public void setMatch(int i, Match_type _value) { this.match[i] = _value; } public synchronized boolean equals(Object obj) { if (!(obj instanceof BO.WatchList.Candidate_match_type)) return false;  BO.WatchList.Candidate_match_type other = (BO.WatchList.Candidate_match_type)obj; if (obj == null) return false;  if (this == obj) return true;  if (this.__equalsCalc != null) return (this.__equalsCalc == obj);  this.__equalsCalc = obj; boolean _equals = (((this.candidate == null && other.getCandidate() == null) || (this.candidate != null && this.candidate.equals(other.getCandidate()))) && ((this.match == null && other.getMatch() == null) || (this.match != null && Arrays.equals((Object[])this.match, (Object[])other.getMatch())))); this.__equalsCalc = null; return _equals; } private static TypeDesc typeDesc = new TypeDesc(BO.WatchList.Candidate_match_type.class, true);
/*     */   
/*     */   static {
/* 103 */     typeDesc.setXmlType(new QName("http://namespaces.mantas.com", "candidate_match_type"));
/* 104 */     ElementDesc elemField = new ElementDesc();
/* 105 */     elemField.setFieldName("candidate");
/* 106 */     elemField.setXmlName(new QName("", "Candidate"));
/* 107 */     elemField.setXmlType(new QName("http://namespaces.mantas.com", "candidate_type"));
/* 108 */     elemField.setNillable(false);
/* 109 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 110 */     elemField = new ElementDesc();
/* 111 */     elemField.setFieldName("match");
/* 112 */     elemField.setXmlName(new QName("", "Match"));
/* 113 */     elemField.setXmlType(new QName("http://namespaces.mantas.com", "match_type"));
/* 114 */     elemField.setMinOccurs(0);
/* 115 */     elemField.setNillable(false);
/* 116 */     elemField.setMaxOccursUnbounded(true);
/* 117 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/*     */   }
/*     */   
/*     */   public static TypeDesc getTypeDesc() {
/* 121 */     return typeDesc;
/*     */   }
/*     */   
/*     */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType) {
/* 125 */     return (Serializer)new BeanSerializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType) {
/* 129 */     return (Deserializer)new BeanDeserializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public Candidate_match_type() {
/*     */     this.__equalsCalc = null;
/*     */     this.__hashCodeCalc = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WatchList\Candidate_match_type.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */