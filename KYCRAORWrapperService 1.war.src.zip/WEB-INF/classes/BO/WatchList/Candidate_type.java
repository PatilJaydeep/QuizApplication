/*     */ package WEB-INF.classes.BO.WatchList;
/*     */ 
/*     */ import BO.WatchList.Address_type;
/*     */ import BO.WatchList.Candidate_name_type;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.description.ElementDesc;
/*     */ import org.apache.axis.description.FieldDesc;
/*     */ import org.apache.axis.description.TypeDesc;
/*     */ import org.apache.axis.encoding.Deserializer;
/*     */ import org.apache.axis.encoding.Serializer;
/*     */ import org.apache.axis.encoding.ser.BeanDeserializer;
/*     */ import org.apache.axis.encoding.ser.BeanSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Candidate_type
/*     */   implements Serializable
/*     */ {
/*     */   private String name;
/*     */   private Candidate_name_type type;
/*     */   private Address_type[] address;
/*     */   private Object __equalsCalc;
/*     */   private boolean __hashCodeCalc;
/*     */   
/*     */   public Candidate_type(String name, Candidate_name_type type, Address_type[] address) {
/*  62 */     this.__equalsCalc = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     this.__hashCodeCalc = false; this.name = name; this.type = type; this.address = address;
/*     */   }
/*     */   public String getName() { return this.name; }
/*  87 */   public void setName(String name) { this.name = name; } public Candidate_name_type getType() { return this.type; } public void setType(Candidate_name_type type) { this.type = type; } public synchronized int hashCode() { if (this.__hashCodeCalc) {
/*  88 */       return 0;
/*     */     }
/*  90 */     this.__hashCodeCalc = true;
/*  91 */     int _hashCode = 1;
/*  92 */     if (getName() != null) {
/*  93 */       _hashCode += getName().hashCode();
/*     */     }
/*  95 */     if (getType() != null) {
/*  96 */       _hashCode += getType().hashCode();
/*     */     }
/*  98 */     if (getAddress() != null) {
/*  99 */       int i = 0;
/* 100 */       for (; i < Array.getLength(getAddress()); 
/* 101 */         i++) {
/* 102 */         Object obj = Array.get(getAddress(), i);
/* 103 */         if (obj != null && 
/* 104 */           !obj.getClass().isArray()) {
/* 105 */           _hashCode += obj.hashCode();
/*     */         }
/*     */       } 
/*     */     } 
/* 109 */     this.__hashCodeCalc = false;
/* 110 */     return _hashCode; }
/*     */   public Address_type[] getAddress() { return this.address; }
/*     */   public void setAddress(Address_type[] address) { this.address = address; }
/* 113 */   public Address_type getAddress(int i) { return this.address[i]; } public void setAddress(int i, Address_type _value) { this.address[i] = _value; } public synchronized boolean equals(Object obj) { if (!(obj instanceof BO.WatchList.Candidate_type)) return false;  BO.WatchList.Candidate_type other = (BO.WatchList.Candidate_type)obj; if (obj == null) return false;  if (this == obj) return true;  if (this.__equalsCalc != null) return (this.__equalsCalc == obj);  this.__equalsCalc = obj; boolean _equals = (((this.name == null && other.getName() == null) || (this.name != null && this.name.equals(other.getName()))) && ((this.type == null && other.getType() == null) || (this.type != null && this.type.equals(other.getType()))) && ((this.address == null && other.getAddress() == null) || (this.address != null && Arrays.equals((Object[])this.address, (Object[])other.getAddress())))); this.__equalsCalc = null; return _equals; } private static TypeDesc typeDesc = new TypeDesc(BO.WatchList.Candidate_type.class, true);
/*     */   
/*     */   static {
/* 116 */     typeDesc.setXmlType(new QName("http://namespaces.mantas.com", "candidate_type"));
/* 117 */     ElementDesc elemField = new ElementDesc();
/* 118 */     elemField.setFieldName("name");
/* 119 */     elemField.setXmlName(new QName("", "Name"));
/* 120 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "string"));
/* 121 */     elemField.setNillable(false);
/* 122 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 123 */     elemField = new ElementDesc();
/* 124 */     elemField.setFieldName("type");
/* 125 */     elemField.setXmlName(new QName("", "Type"));
/* 126 */     elemField.setXmlType(new QName("http://namespaces.mantas.com", "candidate_name_type"));
/* 127 */     elemField.setNillable(false);
/* 128 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/* 129 */     elemField = new ElementDesc();
/* 130 */     elemField.setFieldName("address");
/* 131 */     elemField.setXmlName(new QName("", "Address"));
/* 132 */     elemField.setXmlType(new QName("http://namespaces.mantas.com", "address_type"));
/* 133 */     elemField.setMinOccurs(0);
/* 134 */     elemField.setNillable(false);
/* 135 */     elemField.setMaxOccursUnbounded(true);
/* 136 */     typeDesc.addFieldDesc((FieldDesc)elemField);
/*     */   }
/*     */   
/*     */   public static TypeDesc getTypeDesc() {
/* 140 */     return typeDesc;
/*     */   }
/*     */   
/*     */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType) {
/* 144 */     return (Serializer)new BeanSerializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType) {
/* 148 */     return (Deserializer)new BeanDeserializer(_javaType, _xmlType, typeDesc);
/*     */   }
/*     */   
/*     */   public Candidate_type() {
/*     */     this.__equalsCalc = null;
/*     */     this.__hashCodeCalc = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\WatchList\Candidate_type.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */