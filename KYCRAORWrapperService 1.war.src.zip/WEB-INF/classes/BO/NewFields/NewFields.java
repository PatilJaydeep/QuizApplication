/*     */ package WEB-INF.classes.BO.NewFields;
/*     */ 
/*     */ import BO.RAOR.InterestedParty;
/*     */ import BO.RAOR.Parameter;
/*     */ import BO.RAOR.RAORRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class NewFields
/*     */ {
/*     */   private String CustomerNameType;
/*     */   private String WatchListName;
/*     */   private String PEP;
/*     */   private String CustomerSegment;
/*     */   private String AnticipatedAnnualDeposit;
/*     */   private String xml;
/*     */   private int interestedPartiesCount;
/*     */   private ArrayList<InterestedParty> interestedParty;
/*     */   private String Jurisdiction;
/*     */   private HashMap<String, String> legalNames;
/*     */   private ArrayList<Parameter> paramValues;
/*     */   private RAORRequest raorRequest;
/*     */   
/*     */   public String getCustomerNameType() {
/*  25 */     return this.CustomerNameType;
/*     */   }
/*     */   
/*     */   public void setCustomerNameType(String CustomerNameType) {
/*  29 */     this.CustomerNameType = CustomerNameType;
/*     */   }
/*     */   
/*     */   public String getWatchListName() {
/*  33 */     return this.WatchListName;
/*     */   }
/*     */   
/*     */   public void setWatchListName(String WatchListName) {
/*  37 */     this.WatchListName = WatchListName;
/*     */   }
/*     */   
/*     */   public String getPEP() {
/*  41 */     return this.PEP;
/*     */   }
/*     */   
/*     */   public void setPEP(String PEP) {
/*  45 */     this.PEP = PEP;
/*     */   }
/*     */   
/*     */   public String getCustomerSegment() {
/*  49 */     return this.CustomerSegment;
/*     */   }
/*     */   
/*     */   public void setCustomerSegment(String CustomerSegment) {
/*  53 */     this.CustomerSegment = CustomerSegment;
/*     */   }
/*     */   
/*     */   public String getAnticipatedAnnualDeposit() {
/*  57 */     return this.AnticipatedAnnualDeposit;
/*     */   }
/*     */   
/*     */   public void setAnticipatedAnnualDeposit(String AnticipatedAnnualDeposit) {
/*  61 */     this.AnticipatedAnnualDeposit = AnticipatedAnnualDeposit;
/*     */   }
/*     */   
/*     */   public String getXml() {
/*  65 */     return this.xml;
/*     */   }
/*     */   
/*     */   public void setXml(String xml) {
/*  69 */     this.xml = xml;
/*     */   }
/*     */   
/*     */   public int getInterestedPartiesCount() {
/*  73 */     return this.interestedPartiesCount;
/*     */   }
/*     */   
/*     */   public void setInterestedPartiesCount(int interestedPartiesCount) {
/*  77 */     this.interestedPartiesCount = interestedPartiesCount;
/*     */   }
/*     */   
/*     */   public ArrayList<InterestedParty> getInterestedParty() {
/*  81 */     return this.interestedParty;
/*     */   }
/*     */   
/*     */   public void setInterestedParty(ArrayList<InterestedParty> interestedParty) {
/*  85 */     this.interestedParty = interestedParty;
/*     */   }
/*     */   
/*     */   public String getJurisdiction() {
/*  89 */     return this.Jurisdiction;
/*     */   }
/*     */   
/*     */   public void setJurisdiction(String Jurisdiction) {
/*  93 */     this.Jurisdiction = Jurisdiction;
/*     */   }
/*     */   
/*     */   public HashMap<String, String> getLegalNames() {
/*  97 */     return this.legalNames;
/*     */   }
/*     */   
/*     */   public void setLegalNames(HashMap<String, String> legalNames) {
/* 101 */     this.legalNames = legalNames;
/*     */   }
/*     */   
/*     */   public ArrayList<Parameter> getParamValues() {
/* 105 */     return this.paramValues;
/*     */   }
/*     */   
/*     */   public void setParamValues(ArrayList<Parameter> paramValues) {
/* 109 */     this.paramValues = paramValues;
/*     */   }
/*     */   
/*     */   public RAORRequest getRaorRequest() {
/* 113 */     return this.raorRequest;
/*     */   }
/*     */   
/*     */   public void setRaorRequest(RAORRequest raorRequest) {
/* 117 */     this.raorRequest = raorRequest;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\NewFields\NewFields.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */