/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import BO.RAOR.CustomerCountry;
/*    */ import java.util.ArrayList;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement(name = "CustomerCountries")
/*    */ public class CustomerCountries
/*    */ {
/*    */   private ArrayList<CustomerCountry> customerCountry;
/*    */   
/*    */   @XmlElement(name = "CustomerCountry")
/*    */   public ArrayList<CustomerCountry> getCustomerCountry() {
/* 15 */     return this.customerCountry;
/*    */   }
/*    */   
/*    */   public void setCustomerCountry(ArrayList<CustomerCountry> customerCountry) {
/* 19 */     this.customerCountry = customerCountry;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\CustomerCountries.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */