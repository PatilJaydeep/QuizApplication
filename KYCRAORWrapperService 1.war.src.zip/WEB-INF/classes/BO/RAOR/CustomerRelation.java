/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ public class CustomerRelation
/*    */ {
/*    */   private String RelationDefn;
/*    */   private String ParentCustomerNumber;
/*    */   private String RelationEffectiveDate;
/*    */   private String RelationExpiryDate;
/*    */   private String OwnershipPercentage;
/*    */   
/*    */   public String getParentCustomerNumber() {
/* 16 */     return this.ParentCustomerNumber;
/*    */   }
/*    */   
/*    */   public void setParentCustomerNumber(String ParentCustomerNumber) {
/* 20 */     this.ParentCustomerNumber = ParentCustomerNumber;
/*    */   }
/*    */   
/*    */   public String getRelationDefn() {
/* 24 */     return this.RelationDefn;
/*    */   }
/*    */   
/*    */   public void setRelationDefn(String RelationDefn) {
/* 28 */     this.RelationDefn = RelationDefn;
/*    */   }
/*    */   
/*    */   public String getRelationEffectiveDate() {
/* 32 */     return this.RelationEffectiveDate;
/*    */   }
/*    */   
/*    */   public void setRelationEffectiveDate(String RelationEffectiveDate) {
/* 36 */     this.RelationEffectiveDate = RelationEffectiveDate;
/*    */   }
/*    */   
/*    */   public String getRelationExpiryDate() {
/* 40 */     return this.RelationExpiryDate;
/*    */   }
/*    */   
/*    */   public void setRelationExpiryDate(String RelationExpiryDate) {
/* 44 */     this.RelationExpiryDate = RelationExpiryDate;
/*    */   }
/*    */   
/*    */   public String getOwnershipPercentage() {
/* 48 */     return this.OwnershipPercentage;
/*    */   }
/*    */   
/*    */   public void setOwnershipPercentage(String OwnershipPercentage) {
/* 52 */     this.OwnershipPercentage = OwnershipPercentage;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\CustomerRelation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */