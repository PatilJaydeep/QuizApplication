/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ @XmlRootElement(name = "RAORAcknowledgement")
/*    */ @XmlType(propOrder = {"DataAvailable", "CustomerId", "CustomerTypeMissing", "AccountMismatch", "RAORiskScore", "RAORiskCategory", "Error"})
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ public class RAORAcknowledgement
/*    */ {
/* 13 */   private String DataAvailable = null;
/* 14 */   private String CustomerId = null;
/* 15 */   private String CustomerTypeMissing = null;
/* 16 */   private String AccountMismatch = null;
/* 17 */   private String RAORiskScore = null;
/* 18 */   private String RAORiskCategory = null;
/* 19 */   private String Error = null;
/*    */   
/*    */   public String getDataAvailable() {
/* 22 */     return this.DataAvailable;
/*    */   }
/*    */   
/*    */   public void setDataAvailable(String DataAvailable) {
/* 26 */     this.DataAvailable = DataAvailable;
/*    */   }
/*    */   
/*    */   public String getCustomerId() {
/* 30 */     return this.CustomerId;
/*    */   }
/*    */   
/*    */   public void setCustomerId(String CustomerId) {
/* 34 */     this.CustomerId = CustomerId;
/*    */   }
/*    */   
/*    */   public String getCustomerTypeMissing() {
/* 38 */     return this.CustomerTypeMissing;
/*    */   }
/*    */   
/*    */   public void setCustomerTypeMissing(String CustomerTypeMissing) {
/* 42 */     this.CustomerTypeMissing = CustomerTypeMissing;
/*    */   }
/*    */   
/*    */   public String getAccountMismatch() {
/* 46 */     return this.AccountMismatch;
/*    */   }
/*    */   
/*    */   public void setAccountMismatch(String AccountMismatch) {
/* 50 */     this.AccountMismatch = AccountMismatch;
/*    */   }
/*    */   
/*    */   public String getRAORiskScore() {
/* 54 */     return this.RAORiskScore;
/*    */   }
/*    */   
/*    */   public void setRAORiskScore(String RAORiskScore) {
/* 58 */     this.RAORiskScore = RAORiskScore;
/*    */   }
/*    */   
/*    */   public String getRAORiskCategory() {
/* 62 */     return this.RAORiskCategory;
/*    */   }
/*    */   
/*    */   public void setRAORiskCategory(String RAORiskCategory) {
/* 66 */     this.RAORiskCategory = RAORiskCategory;
/*    */   }
/*    */   
/*    */   public String getError() {
/* 70 */     return this.Error;
/*    */   }
/*    */   
/*    */   public void setError(String Error) {
/* 74 */     this.Error = Error;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\RAORAcknowledgement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */