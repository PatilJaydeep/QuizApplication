/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import BO.RAOR.CustomerRole;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement(name = "CustomerCountries")
/*    */ public class CustomerRoles
/*    */ {
/*    */   private CustomerRole customerRole;
/*    */   
/*    */   @XmlElement(name = "CustomerRole")
/*    */   public CustomerRole getCustomerRole() {
/* 14 */     return this.customerRole;
/*    */   }
/*    */   
/*    */   public void setCustomerRole(CustomerRole customerRole) {
/* 18 */     this.customerRole = customerRole;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\CustomerRoles.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */