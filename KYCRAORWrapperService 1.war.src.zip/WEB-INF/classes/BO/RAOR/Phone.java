/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ public class Phone
/*    */ {
/*    */   private String PhoneType;
/*    */   private String PhoneNumber;
/*    */   private String PhoneExtension;
/*    */   private String PhoneCountry;
/*    */   
/*    */   public String getPhoneExtension() {
/* 15 */     return this.PhoneExtension;
/*    */   }
/*    */   
/*    */   public void setPhoneExtension(String PhoneExtension) {
/* 19 */     this.PhoneExtension = PhoneExtension;
/*    */   }
/*    */   
/*    */   public String getPhoneType() {
/* 23 */     return this.PhoneType;
/*    */   }
/*    */   
/*    */   public void setPhoneType(String PhoneType) {
/* 27 */     this.PhoneType = PhoneType;
/*    */   }
/*    */   
/*    */   public String getPhoneNumber() {
/* 31 */     return this.PhoneNumber;
/*    */   }
/*    */   
/*    */   public void setPhoneNumber(String PhoneNumber) {
/* 35 */     this.PhoneNumber = PhoneNumber;
/*    */   }
/*    */   
/*    */   public String getPhoneCountry() {
/* 39 */     return this.PhoneCountry;
/*    */   }
/*    */   
/*    */   public void setPhoneCountry(String PhoneCountry) {
/* 43 */     this.PhoneCountry = PhoneCountry;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\Phone.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */