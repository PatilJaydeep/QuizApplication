/*     */ package WEB-INF.classes.BO.RAOR;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ public class CustmerDetails
/*     */ {
/*     */   private String CustomerIdNumber;
/*     */   private String CustomerType;
/*     */   private String CustomerTitle;
/*     */   private String CustomerFirstName;
/*     */   private String CustomerMiddleName;
/*     */   private String CustomerLastName;
/*     */   private String LegalName;
/*     */   private String InstituteName;
/*     */   private String InstituteStartDate;
/*     */   private String Gender;
/*     */   private String DateOfBirth;
/*     */   private String Industry;
/*     */   private String TaxIdentifierFormat;
/*     */   private String TaxIdentificationNumber;
/*     */   private String Occupation;
/*     */   private String CustomerCreationDate;
/*     */   private String ResidenceCountry;
/*     */   private String PrimaryCitznCountry;
/*     */   private String SecondryCitznCountry;
/*     */   private String DocumetsVerifiedFlag;
/*     */   private String CustomerNameType;
/*     */   private String WatchListName;
/*     */   private String PEP;
/*     */   private String CustomerSegment;
/*     */   private String AnticipatedAnnualDeposit;
/*     */   
/*     */   public String getCustomerIdNumber() {
/*  36 */     return this.CustomerIdNumber;
/*     */   }
/*     */   
/*     */   public void setCustomerIdNumber(String CustomerIdNumber) {
/*  40 */     this.CustomerIdNumber = CustomerIdNumber;
/*     */   }
/*     */   
/*     */   public String getCustomerType() {
/*  44 */     return this.CustomerType;
/*     */   }
/*     */   
/*     */   public void setCustomerType(String CustomerType) {
/*  48 */     this.CustomerType = CustomerType;
/*     */   }
/*     */   
/*     */   public String getCustomerTitle() {
/*  52 */     return this.CustomerTitle;
/*     */   }
/*     */   
/*     */   public void setCustomerTitle(String CustomerTitle) {
/*  56 */     this.CustomerTitle = CustomerTitle;
/*     */   }
/*     */   
/*     */   public String getCustomerFirstName() {
/*  60 */     return this.CustomerFirstName;
/*     */   }
/*     */   
/*     */   public void setCustomerFirstName(String CustomerFirstName) {
/*  64 */     this.CustomerFirstName = CustomerFirstName;
/*     */   }
/*     */   
/*     */   public String getCustomerMiddleName() {
/*  68 */     return this.CustomerMiddleName;
/*     */   }
/*     */   
/*     */   public void setCustomerMiddleName(String CustomerMiddleName) {
/*  72 */     this.CustomerMiddleName = CustomerMiddleName;
/*     */   }
/*     */   
/*     */   public String getCustomerLastName() {
/*  76 */     return this.CustomerLastName;
/*     */   }
/*     */   
/*     */   public void setCustomerLastName(String CustomerLastName) {
/*  80 */     this.CustomerLastName = CustomerLastName;
/*     */   }
/*     */   
/*     */   public String getLegalName() {
/*  84 */     return this.LegalName;
/*     */   }
/*     */   
/*     */   public void setLegalName(String LegalName) {
/*  88 */     this.LegalName = LegalName;
/*     */   }
/*     */   
/*     */   public String getInstituteName() {
/*  92 */     return this.InstituteName;
/*     */   }
/*     */   
/*     */   public void setInstituteName(String InstituteName) {
/*  96 */     this.InstituteName = InstituteName;
/*     */   }
/*     */   
/*     */   public String getInstituteStartDate() {
/* 100 */     return this.InstituteStartDate;
/*     */   }
/*     */   
/*     */   public void setInstituteStartDate(String InstituteStartDate) {
/* 104 */     this.InstituteStartDate = InstituteStartDate;
/*     */   }
/*     */   
/*     */   public String getDateOfBirth() {
/* 108 */     return this.DateOfBirth;
/*     */   }
/*     */   
/*     */   public void setDateOfBirth(String DateOfBirth) {
/* 112 */     this.DateOfBirth = DateOfBirth;
/*     */   }
/*     */   
/*     */   public String getIndustry() {
/* 116 */     return this.Industry;
/*     */   }
/*     */   
/*     */   public void setIndustry(String Industry) {
/* 120 */     this.Industry = Industry;
/*     */   }
/*     */   
/*     */   public String getTaxIdentifierFormat() {
/* 124 */     return this.TaxIdentifierFormat;
/*     */   }
/*     */   
/*     */   public void setTaxIdentifierFormat(String TaxIdentifierFormat) {
/* 128 */     this.TaxIdentifierFormat = TaxIdentifierFormat;
/*     */   }
/*     */   
/*     */   public String getTaxIdentificationNumber() {
/* 132 */     return this.TaxIdentificationNumber;
/*     */   }
/*     */   
/*     */   public void setTaxIdentificationNumber(String TaxIdentificationNumber) {
/* 136 */     this.TaxIdentificationNumber = TaxIdentificationNumber;
/*     */   }
/*     */   
/*     */   public String getOccupation() {
/* 140 */     return this.Occupation;
/*     */   }
/*     */   
/*     */   public void setOccupation(String Occupation) {
/* 144 */     this.Occupation = Occupation;
/*     */   }
/*     */   
/*     */   public String getCustomerCreationDate() {
/* 148 */     return this.CustomerCreationDate;
/*     */   }
/*     */   
/*     */   public void setCustomerCreationDate(String CustomerCreationDate) {
/* 152 */     this.CustomerCreationDate = CustomerCreationDate;
/*     */   }
/*     */   
/*     */   public String getResidenceCountry() {
/* 156 */     return this.ResidenceCountry;
/*     */   }
/*     */   
/*     */   public void setResidenceCountry(String ResidenceCountry) {
/* 160 */     this.ResidenceCountry = ResidenceCountry;
/*     */   }
/*     */   
/*     */   public String getPrimaryCitznCountry() {
/* 164 */     return this.PrimaryCitznCountry;
/*     */   }
/*     */   
/*     */   public void setPrimaryCitznCountry(String PrimaryCitznCountry) {
/* 168 */     this.PrimaryCitznCountry = PrimaryCitznCountry;
/*     */   }
/*     */   
/*     */   public String getSecondryCitznCountry() {
/* 172 */     return this.SecondryCitznCountry;
/*     */   }
/*     */   
/*     */   public void setSecondryCitznCountry(String SecondryCitznCountry) {
/* 176 */     this.SecondryCitznCountry = SecondryCitznCountry;
/*     */   }
/*     */   
/*     */   public String getDocumetsVerifiedFlag() {
/* 180 */     return this.DocumetsVerifiedFlag;
/*     */   }
/*     */   
/*     */   public void setDocumetsVerifiedFlag(String DocumetsVerifiedFlag) {
/* 184 */     this.DocumetsVerifiedFlag = DocumetsVerifiedFlag;
/*     */   }
/*     */   
/*     */   public String getCustomerNameType() {
/* 188 */     return this.CustomerNameType;
/*     */   }
/*     */   
/*     */   public void setCustomerNameType(String CustomerNameType) {
/* 192 */     this.CustomerNameType = CustomerNameType;
/*     */   }
/*     */   
/*     */   public String getWatchListName() {
/* 196 */     return this.WatchListName;
/*     */   }
/*     */   
/*     */   public void setWatchListName(String WatchListName) {
/* 200 */     this.WatchListName = WatchListName;
/*     */   }
/*     */   
/*     */   public String getCustomerSegment() {
/* 204 */     return this.CustomerSegment;
/*     */   }
/*     */   
/*     */   public void setCustomerSegment(String CustomerSegment) {
/* 208 */     this.CustomerSegment = CustomerSegment;
/*     */   }
/*     */   
/*     */   public String getAnticipatedAnnualDeposit() {
/* 212 */     return this.AnticipatedAnnualDeposit;
/*     */   }
/*     */   
/*     */   public void setAnticipatedAnnualDeposit(String AnticipatedAnnualDeposit) {
/* 216 */     this.AnticipatedAnnualDeposit = AnticipatedAnnualDeposit;
/*     */   }
/*     */   
/*     */   public String getPEP() {
/* 220 */     return this.PEP;
/*     */   }
/*     */   
/*     */   public void setPEP(String PEP) {
/* 224 */     this.PEP = PEP;
/*     */   }
/*     */   
/*     */   public String getGender() {
/* 228 */     return this.Gender;
/*     */   }
/*     */   
/*     */   public void setGender(String Gender) {
/* 232 */     this.Gender = Gender;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\CustmerDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */