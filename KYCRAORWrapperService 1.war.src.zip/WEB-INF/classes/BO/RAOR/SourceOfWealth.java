/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ public class SourceOfWealth
/*    */ {
/*    */   private String SourceType;
/*    */   private String Currency;
/*    */   private String ReceivedDate;
/*    */   private String ReceivedAmount;
/*    */   private String AsOfDate;
/*    */   private String LastUpdateDate;
/*    */   
/*    */   public String getSourceType() {
/* 17 */     return this.SourceType;
/*    */   }
/*    */   
/*    */   public void setSourceType(String SourceType) {
/* 21 */     this.SourceType = SourceType;
/*    */   }
/*    */   
/*    */   public String getCurrency() {
/* 25 */     return this.Currency;
/*    */   }
/*    */   
/*    */   public void setCurrency(String Currency) {
/* 29 */     this.Currency = Currency;
/*    */   }
/*    */   
/*    */   public String getReceivedDate() {
/* 33 */     return this.ReceivedDate;
/*    */   }
/*    */   
/*    */   public void setReceivedDate(String ReceivedDate) {
/* 37 */     this.ReceivedDate = ReceivedDate;
/*    */   }
/*    */   
/*    */   public String getReceivedAmount() {
/* 41 */     return this.ReceivedAmount;
/*    */   }
/*    */   
/*    */   public void setReceivedAmount(String ReceivedAmount) {
/* 45 */     this.ReceivedAmount = ReceivedAmount;
/*    */   }
/*    */   
/*    */   public String getAsOfDate() {
/* 49 */     return this.AsOfDate;
/*    */   }
/*    */   
/*    */   public void setAsOfDate(String AsOfDate) {
/* 53 */     this.AsOfDate = AsOfDate;
/*    */   }
/*    */   
/*    */   public String getLastUpdateDate() {
/* 57 */     return this.LastUpdateDate;
/*    */   }
/*    */   
/*    */   public void setLastUpdateDate(String LastUpdateDate) {
/* 61 */     this.LastUpdateDate = LastUpdateDate;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\SourceOfWealth.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */