/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import BO.RAOR.InterestedParty;
/*    */ import java.util.ArrayList;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement(name = "InterestedParties")
/*    */ public class InterestedParties
/*    */ {
/*    */   private ArrayList<InterestedParty> interestedParty;
/*    */   
/*    */   @XmlElement(name = "InterestedParty")
/*    */   public ArrayList<InterestedParty> getInterestedParty() {
/* 15 */     return this.interestedParty;
/*    */   }
/*    */   
/*    */   public void setInterestedParty(ArrayList<InterestedParty> interestedParty) {
/* 19 */     this.interestedParty = interestedParty;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\InterestedParties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */