/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ public class XmlMapping_FT
/*    */ {
/*    */   private String ruleGrpNm;
/*    */   private String riskParamDesc;
/*    */   private String riskParamCode;
/*    */   private String riskParamTag;
/*    */   private String customerType;
/*    */   private String customerTypeKey;
/*    */   private String ruleOpt;
/*    */   private String ruleTxVal;
/*    */   private String ruleEnblFl;
/*    */   
/*    */   public String getRuleGrpNm() {
/* 16 */     return this.ruleGrpNm;
/*    */   }
/*    */   
/*    */   public void setRuleGrpNm(String ruleGrpNm) {
/* 20 */     this.ruleGrpNm = ruleGrpNm;
/*    */   }
/*    */   
/*    */   public String getRiskParamDesc() {
/* 24 */     return this.riskParamDesc;
/*    */   }
/*    */   
/*    */   public void setRiskParamDesc(String riskParamDesc) {
/* 28 */     this.riskParamDesc = riskParamDesc;
/*    */   }
/*    */   
/*    */   public String getRiskParamCode() {
/* 32 */     return this.riskParamCode;
/*    */   }
/*    */   
/*    */   public void setRiskParamCode(String riskParamCode) {
/* 36 */     this.riskParamCode = riskParamCode;
/*    */   }
/*    */   
/*    */   public String getRiskParamTag() {
/* 40 */     return this.riskParamTag;
/*    */   }
/*    */   
/*    */   public void setRiskParamTag(String riskParamTag) {
/* 44 */     this.riskParamTag = riskParamTag;
/*    */   }
/*    */   
/*    */   public String getCustomerType() {
/* 48 */     return this.customerType;
/*    */   }
/*    */   
/*    */   public void setCustomerType(String customerType) {
/* 52 */     this.customerType = customerType;
/*    */   }
/*    */   
/*    */   public String getCustomerTypeKey() {
/* 56 */     return this.customerTypeKey;
/*    */   }
/*    */   
/*    */   public void setCustomerTypeKey(String customerTypeKey) {
/* 60 */     this.customerTypeKey = customerTypeKey;
/*    */   }
/*    */   
/*    */   public String getRuleOpt() {
/* 64 */     return this.ruleOpt;
/*    */   }
/*    */   
/*    */   public void setRuleOpt(String ruleOpt) {
/* 68 */     this.ruleOpt = ruleOpt;
/*    */   }
/*    */   
/*    */   public String getRuleTxVal() {
/* 72 */     return this.ruleTxVal;
/*    */   }
/*    */   
/*    */   public void setRuleTxVal(String ruleTxVal) {
/* 76 */     this.ruleTxVal = ruleTxVal;
/*    */   }
/*    */   
/*    */   public String getRuleEnblFl() {
/* 80 */     return this.ruleEnblFl;
/*    */   }
/*    */   
/*    */   public void setRuleEnblFl(String ruleEnblFl) {
/* 84 */     this.ruleEnblFl = ruleEnblFl;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\XmlMapping_FT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */