/*     */ package WEB-INF.classes.BO.RAOR;
/*     */ 
/*     */ import BO.RAOR.AdditionalParameters;
/*     */ import BO.RAOR.Addresses;
/*     */ import BO.RAOR.CustomerCountries;
/*     */ import BO.RAOR.CustomerDetails;
/*     */ import BO.RAOR.CustomerRelationships;
/*     */ import BO.RAOR.CustomerRoles;
/*     */ import BO.RAOR.MarketsServed;
/*     */ import BO.RAOR.Phones;
/*     */ import BO.RAOR.SourcesOfWealth;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ @XmlRootElement(name = "InterestedParty")
/*     */ @XmlType(propOrder = {"customerDetails", "addresses", "phones", "sourcesOfWealth", "marketsServed", "customerRoles", "customerRelationships", "customerCountries", "additionalParameters"})
/*     */ public class InterestedParty
/*     */ {
/*     */   private CustomerDetails customerDetails;
/*     */   private Addresses addresses;
/*     */   private Phones phones;
/*     */   private SourcesOfWealth sourcesOfWealth;
/*     */   private MarketsServed marketsServed;
/*     */   private CustomerRoles customerRoles;
/*     */   private CustomerRelationships customerRelationships;
/*     */   private CustomerCountries customerCountries;
/*     */   private AdditionalParameters additionalParameters;
/*     */   
/*     */   @XmlElement(name = "Addresses")
/*     */   public Addresses getAddresses() {
/*  32 */     return this.addresses;
/*     */   }
/*     */   
/*     */   public void setAddresses(Addresses addresses) {
/*  36 */     this.addresses = addresses;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "Phones")
/*     */   public Phones getPhones() {
/*  41 */     return this.phones;
/*     */   }
/*     */   
/*     */   public void setPhones(Phones phones) {
/*  45 */     this.phones = phones;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "SourcesOfWealth")
/*     */   public SourcesOfWealth getSourcesOfWealth() {
/*  50 */     return this.sourcesOfWealth;
/*     */   }
/*     */   
/*     */   public void setSourcesOfWealth(SourcesOfWealth sourcesOfWealth) {
/*  54 */     this.sourcesOfWealth = sourcesOfWealth;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "MarketsServed")
/*     */   public MarketsServed getMarketsServed() {
/*  59 */     return this.marketsServed;
/*     */   }
/*     */   
/*     */   public void setMarketsServed(MarketsServed marketsServed) {
/*  63 */     this.marketsServed = marketsServed;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CustomerRoles")
/*     */   public CustomerRoles getCustomerRoles() {
/*  68 */     return this.customerRoles;
/*     */   }
/*     */   
/*     */   public void setCustomerRoles(CustomerRoles customerRoles) {
/*  72 */     this.customerRoles = customerRoles;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CustomerRelationships")
/*     */   public CustomerRelationships getCustomerRelationships() {
/*  77 */     return this.customerRelationships;
/*     */   }
/*     */   
/*     */   public void setCustomerRelationships(CustomerRelationships customerRelationships) {
/*  81 */     this.customerRelationships = customerRelationships;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CustomerCountries")
/*     */   public CustomerCountries getCustomerCountries() {
/*  86 */     return this.customerCountries;
/*     */   }
/*     */   
/*     */   public void setCustomerCountries(CustomerCountries customerCountries) {
/*  90 */     this.customerCountries = customerCountries;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CustomerDetails")
/*     */   public CustomerDetails getCustomerDetails() {
/*  95 */     return this.customerDetails;
/*     */   }
/*     */   
/*     */   public void setCustomerDetails(CustomerDetails customerDetails) {
/*  99 */     this.customerDetails = customerDetails;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "AdditionalParameters")
/*     */   public AdditionalParameters getAdditionalParameters() {
/* 104 */     return this.additionalParameters;
/*     */   }
/*     */   
/*     */   public void setAdditionalParameters(AdditionalParameters additionalParameters) {
/* 108 */     this.additionalParameters = additionalParameters;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\InterestedParty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */