/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import BO.RAOR.CustomerRelation;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement(name = "CustomerRelationships")
/*    */ public class CustomerRelationships
/*    */ {
/*    */   private CustomerRelation customerRelation;
/*    */   
/*    */   @XmlElement(name = "CustomerRelation")
/*    */   public CustomerRelation getCustomerRelation() {
/* 14 */     return this.customerRelation;
/*    */   }
/*    */   
/*    */   public void setCustomerRelation(CustomerRelation customerRelation) {
/* 18 */     this.customerRelation = customerRelation;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\CustomerRelationships.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */