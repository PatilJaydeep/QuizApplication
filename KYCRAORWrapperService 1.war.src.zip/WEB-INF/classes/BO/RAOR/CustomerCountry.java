/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ public class CustomerCountry
/*    */ {
/*    */   private String CountryOfRelationship;
/*    */   private String RelationType;
/*    */   
/*    */   public String getCountryOfRelationship() {
/* 13 */     return this.CountryOfRelationship;
/*    */   }
/*    */   
/*    */   public void setCountryOfRelationship(String CountryOfRelationship) {
/* 17 */     this.CountryOfRelationship = CountryOfRelationship;
/*    */   }
/*    */   
/*    */   public String getRelationType() {
/* 21 */     return this.RelationType;
/*    */   }
/*    */   
/*    */   public void setRelationType(String RelationType) {
/* 25 */     this.RelationType = RelationType;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\CustomerCountry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */