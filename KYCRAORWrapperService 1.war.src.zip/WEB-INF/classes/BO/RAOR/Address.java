/*     */ package WEB-INF.classes.BO.RAOR;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ public class Address
/*     */ {
/*     */   private String AddressType;
/*     */   private String AddressLine1;
/*     */   private String AddressLine2;
/*     */   private String AddressLine3;
/*     */   private String AddressLine4;
/*     */   private String AddressLine5;
/*     */   private String AddressLine6;
/*     */   private String City;
/*     */   private String State;
/*     */   private String Region;
/*     */   private String PostalCode;
/*     */   private String AddressCountry;
/*     */   private String MailHandingInstruction;
/*     */   
/*     */   public String getAddressType() {
/*  24 */     return this.AddressType;
/*     */   }
/*     */   
/*     */   public void setAddressType(String AddressType) {
/*  28 */     this.AddressType = AddressType;
/*     */   }
/*     */   
/*     */   public String getAddressLine1() {
/*  32 */     return this.AddressLine1;
/*     */   }
/*     */   
/*     */   public void setAddressLine1(String AddressLine1) {
/*  36 */     this.AddressLine1 = AddressLine1;
/*     */   }
/*     */   
/*     */   public String getAddressLine2() {
/*  40 */     return this.AddressLine2;
/*     */   }
/*     */   
/*     */   public void setAddressLine2(String AddressLine2) {
/*  44 */     this.AddressLine2 = AddressLine2;
/*     */   }
/*     */   
/*     */   public String getAddressLine3() {
/*  48 */     return this.AddressLine3;
/*     */   }
/*     */   
/*     */   public void setAddressLine3(String AddressLine3) {
/*  52 */     this.AddressLine3 = AddressLine3;
/*     */   }
/*     */   
/*     */   public String getAddressLine4() {
/*  56 */     return this.AddressLine4;
/*     */   }
/*     */   
/*     */   public void setAddressLine4(String AddressLine4) {
/*  60 */     this.AddressLine4 = AddressLine4;
/*     */   }
/*     */   
/*     */   public String getAddressLine5() {
/*  64 */     return this.AddressLine5;
/*     */   }
/*     */   
/*     */   public void setAddressLine5(String AddressLine5) {
/*  68 */     this.AddressLine5 = AddressLine5;
/*     */   }
/*     */   
/*     */   public String getAddressLine6() {
/*  72 */     return this.AddressLine6;
/*     */   }
/*     */   
/*     */   public void setAddressLine6(String AddressLine6) {
/*  76 */     this.AddressLine6 = AddressLine6;
/*     */   }
/*     */   
/*     */   public String getCity() {
/*  80 */     return this.City;
/*     */   }
/*     */   
/*     */   public void setCity(String City) {
/*  84 */     this.City = City;
/*     */   }
/*     */   
/*     */   public String getState() {
/*  88 */     return this.State;
/*     */   }
/*     */   
/*     */   public void setState(String State) {
/*  92 */     this.State = State;
/*     */   }
/*     */   
/*     */   public String getPostalCode() {
/*  96 */     return this.PostalCode;
/*     */   }
/*     */   
/*     */   public void setPostalCode(String PostalCode) {
/* 100 */     this.PostalCode = PostalCode;
/*     */   }
/*     */   
/*     */   public String getAddressCountry() {
/* 104 */     return this.AddressCountry;
/*     */   }
/*     */   
/*     */   public void setAddressCountry(String AddressCountry) {
/* 108 */     this.AddressCountry = AddressCountry;
/*     */   }
/*     */   
/*     */   public String getRegion() {
/* 112 */     return this.Region;
/*     */   }
/*     */   
/*     */   public void setRegion(String Region) {
/* 116 */     this.Region = Region;
/*     */   }
/*     */   
/*     */   public String getMailHandingInstruction() {
/* 120 */     return this.MailHandingInstruction;
/*     */   }
/*     */   
/*     */   public void setMailHandingInstruction(String MailHandingInstruction) {
/* 124 */     this.MailHandingInstruction = MailHandingInstruction;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\Address.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */