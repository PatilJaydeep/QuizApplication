/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import BO.RAOR.Customer;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement(name = "RAORRequest")
/*    */ public class RAORRequest
/*    */ {
/*    */   private Customer customer;
/*    */   
/*    */   @XmlElement(name = "Customer")
/*    */   public Customer getCustomer() {
/* 14 */     return this.customer;
/*    */   }
/*    */   
/*    */   public void setCustomer(Customer customer) {
/* 18 */     this.customer = customer;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\RAORRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */