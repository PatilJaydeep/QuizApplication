/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ public class XmlMapping
/*    */ {
/*    */   private String riskParamDesc;
/*    */   private String riskParamTag;
/*    */   private String riskParamName;
/*    */   private String riskParamWeight;
/*    */   private String customerType;
/*    */   private String customerTypeKey;
/*    */   
/*    */   public String getRiskParamDesc() {
/* 13 */     return this.riskParamDesc;
/*    */   }
/*    */   
/*    */   public void setRiskParamDesc(String riskParamDesc) {
/* 17 */     this.riskParamDesc = riskParamDesc;
/*    */   }
/*    */   
/*    */   public String getRiskParamTag() {
/* 21 */     return this.riskParamTag;
/*    */   }
/*    */   
/*    */   public void setRiskParamTag(String riskParamTag) {
/* 25 */     this.riskParamTag = riskParamTag;
/*    */   }
/*    */   
/*    */   public String getRiskParamName() {
/* 29 */     return this.riskParamName;
/*    */   }
/*    */   
/*    */   public void setRiskParamName(String riskParamName) {
/* 33 */     this.riskParamName = riskParamName;
/*    */   }
/*    */   
/*    */   public String getRiskParamWeight() {
/* 37 */     return this.riskParamWeight;
/*    */   }
/*    */   
/*    */   public void setRiskParamWeight(String riskParamWeight) {
/* 41 */     this.riskParamWeight = riskParamWeight;
/*    */   }
/*    */   
/*    */   public String getCustomerType() {
/* 45 */     return this.customerType;
/*    */   }
/*    */   
/*    */   public void setCustomerType(String customerType) {
/* 49 */     this.customerType = customerType;
/*    */   }
/*    */   
/*    */   public String getCustomerTypeKey() {
/* 53 */     return this.customerTypeKey;
/*    */   }
/*    */   
/*    */   public void setCustomerTypeKey(String customerTypeKey) {
/* 57 */     this.customerTypeKey = customerTypeKey;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\XmlMapping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */