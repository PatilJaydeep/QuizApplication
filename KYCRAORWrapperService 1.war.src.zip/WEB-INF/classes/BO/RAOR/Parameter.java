/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ public class Parameter
/*    */ {
/*    */   private ArrayList<String> Value;
/*    */   
/*    */   public ArrayList<String> getValue() {
/* 14 */     return this.Value;
/*    */   }
/*    */   
/*    */   public void setValue(ArrayList<String> Value) {
/* 18 */     this.Value = Value;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\Parameter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */