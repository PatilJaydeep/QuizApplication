/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import BO.RAOR.Phone;
/*    */ import java.util.ArrayList;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement(name = "Phones")
/*    */ public class Phones
/*    */ {
/*    */   private ArrayList<Phone> phone;
/*    */   
/*    */   @XmlElement(name = "Phone")
/*    */   public ArrayList<Phone> getPhone() {
/* 15 */     return this.phone;
/*    */   }
/*    */   
/*    */   public void setPhone(ArrayList<Phone> phone) {
/* 19 */     this.phone = phone;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\Phones.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */