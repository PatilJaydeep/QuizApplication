/*     */ package WEB-INF.classes.BO.RAOR;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ public class CustomerDetails
/*     */ {
/*     */   private String CustomerIdNumber;
/*     */   private String CustomerType;
/*     */   private String CustomerTitle;
/*     */   private String CustomerFirstName;
/*     */   private String CustomerMiddleName;
/*     */   private String CustomerLastName;
/*     */   private String LegalName;
/*     */   private String InstituteName;
/*     */   private String InstituteStartDate;
/*     */   private String Gender;
/*     */   private String DateOfBirth;
/*     */   private String Industry;
/*     */   private String TaxIdentifierFormat;
/*     */   private String TaxIdentificationNumber;
/*     */   private String Occupation;
/*     */   private String CustomerCreationDate;
/*     */   private String ResidenceCountry;
/*     */   private String PrimaryCitznCountry;
/*     */   private String SecondryCitznCountry;
/*     */   private String DocumetsVerifiedFlag;
/*     */   
/*     */   public String getCustomerIdNumber() {
/*  31 */     return this.CustomerIdNumber;
/*     */   }
/*     */   
/*     */   public void setCustomerIdNumber(String CustomerIdNumber) {
/*  35 */     this.CustomerIdNumber = CustomerIdNumber;
/*     */   }
/*     */   
/*     */   public String getCustomerType() {
/*  39 */     return this.CustomerType;
/*     */   }
/*     */   
/*     */   public void setCustomerType(String CustomerType) {
/*  43 */     this.CustomerType = CustomerType;
/*     */   }
/*     */   
/*     */   public String getCustomerTitle() {
/*  47 */     return this.CustomerTitle;
/*     */   }
/*     */   
/*     */   public void setCustomerTitle(String CustomerTitle) {
/*  51 */     this.CustomerTitle = CustomerTitle;
/*     */   }
/*     */   
/*     */   public String getCustomerFirstName() {
/*  55 */     return this.CustomerFirstName;
/*     */   }
/*     */   
/*     */   public void setCustomerFirstName(String CustomerFirstName) {
/*  59 */     this.CustomerFirstName = CustomerFirstName;
/*     */   }
/*     */   
/*     */   public String getCustomerMiddleName() {
/*  63 */     return this.CustomerMiddleName;
/*     */   }
/*     */   
/*     */   public void setCustomerMiddleName(String CustomerMiddleName) {
/*  67 */     this.CustomerMiddleName = CustomerMiddleName;
/*     */   }
/*     */   
/*     */   public String getCustomerLastName() {
/*  71 */     return this.CustomerLastName;
/*     */   }
/*     */   
/*     */   public void setCustomerLastName(String CustomerLastName) {
/*  75 */     this.CustomerLastName = CustomerLastName;
/*     */   }
/*     */   
/*     */   public String getLegalName() {
/*  79 */     return this.LegalName;
/*     */   }
/*     */   
/*     */   public void setLegalName(String LegalName) {
/*  83 */     this.LegalName = LegalName;
/*     */   }
/*     */   
/*     */   public String getInstituteName() {
/*  87 */     return this.InstituteName;
/*     */   }
/*     */   
/*     */   public void setInstituteName(String InstituteName) {
/*  91 */     this.InstituteName = InstituteName;
/*     */   }
/*     */   
/*     */   public String getInstituteStartDate() {
/*  95 */     return this.InstituteStartDate;
/*     */   }
/*     */   
/*     */   public void setInstituteStartDate(String InstituteStartDate) {
/*  99 */     this.InstituteStartDate = InstituteStartDate;
/*     */   }
/*     */   
/*     */   public String getDateOfBirth() {
/* 103 */     return this.DateOfBirth;
/*     */   }
/*     */   
/*     */   public void setDateOfBirth(String DateOfBirth) {
/* 107 */     this.DateOfBirth = DateOfBirth;
/*     */   }
/*     */   
/*     */   public String getIndustry() {
/* 111 */     return this.Industry;
/*     */   }
/*     */   
/*     */   public void setIndustry(String Industry) {
/* 115 */     this.Industry = Industry;
/*     */   }
/*     */   
/*     */   public String getTaxIdentifierFormat() {
/* 119 */     return this.TaxIdentifierFormat;
/*     */   }
/*     */   
/*     */   public void setTaxIdentifierFormat(String TaxIdentifierFormat) {
/* 123 */     this.TaxIdentifierFormat = TaxIdentifierFormat;
/*     */   }
/*     */   
/*     */   public String getTaxIdentificationNumber() {
/* 127 */     return this.TaxIdentificationNumber;
/*     */   }
/*     */   
/*     */   public void setTaxIdentificationNumber(String TaxIdentificationNumber) {
/* 131 */     this.TaxIdentificationNumber = TaxIdentificationNumber;
/*     */   }
/*     */   
/*     */   public String getOccupation() {
/* 135 */     return this.Occupation;
/*     */   }
/*     */   
/*     */   public void setOccupation(String Occupation) {
/* 139 */     this.Occupation = Occupation;
/*     */   }
/*     */   
/*     */   public String getCustomerCreationDate() {
/* 143 */     return this.CustomerCreationDate;
/*     */   }
/*     */   
/*     */   public void setCustomerCreationDate(String CustomerCreationDate) {
/* 147 */     this.CustomerCreationDate = CustomerCreationDate;
/*     */   }
/*     */   
/*     */   public String getResidenceCountry() {
/* 151 */     return this.ResidenceCountry;
/*     */   }
/*     */   
/*     */   public void setResidenceCountry(String ResidenceCountry) {
/* 155 */     this.ResidenceCountry = ResidenceCountry;
/*     */   }
/*     */   
/*     */   public String getPrimaryCitznCountry() {
/* 159 */     return this.PrimaryCitznCountry;
/*     */   }
/*     */   
/*     */   public void setPrimaryCitznCountry(String PrimaryCitznCountry) {
/* 163 */     this.PrimaryCitznCountry = PrimaryCitznCountry;
/*     */   }
/*     */   
/*     */   public String getSecondryCitznCountry() {
/* 167 */     return this.SecondryCitznCountry;
/*     */   }
/*     */   
/*     */   public void setSecondryCitznCountry(String SecondryCitznCountry) {
/* 171 */     this.SecondryCitznCountry = SecondryCitznCountry;
/*     */   }
/*     */   
/*     */   public String getDocumetsVerifiedFlag() {
/* 175 */     return this.DocumetsVerifiedFlag;
/*     */   }
/*     */   
/*     */   public void setDocumetsVerifiedFlag(String DocumetsVerifiedFlag) {
/* 179 */     this.DocumetsVerifiedFlag = DocumetsVerifiedFlag;
/*     */   }
/*     */   
/*     */   public String getGender() {
/* 183 */     return this.Gender;
/*     */   }
/*     */   
/*     */   public void setGender(String Gender) {
/* 187 */     this.Gender = Gender;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\CustomerDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */