/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import BO.RAOR.Parameter;
/*    */ import java.util.ArrayList;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement(name = "AdditionalParameters")
/*    */ public class AdditionalParameters
/*    */ {
/*    */   private ArrayList<Parameter> parameter;
/*    */   
/*    */   @XmlElement(name = "Parameter")
/*    */   public ArrayList<Parameter> getParameter() {
/* 15 */     return this.parameter;
/*    */   }
/*    */   
/*    */   public void setParameter(ArrayList<Parameter> parameter) {
/* 19 */     this.parameter = parameter;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\AdditionalParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */