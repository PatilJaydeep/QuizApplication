/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ public class CustomerRole
/*    */ {
/*    */   private String Role;
/*    */   
/*    */   public String getRole() {
/* 12 */     return this.Role;
/*    */   }
/*    */   
/*    */   public void setRole(String Role) {
/* 16 */     this.Role = Role;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\CustomerRole.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */