/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import BO.RAOR.SourceOfWealth;
/*    */ import java.util.ArrayList;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement(name = "SourcesOfWealth")
/*    */ public class SourcesOfWealth
/*    */ {
/*    */   private ArrayList<SourceOfWealth> sourceOfWealth;
/*    */   
/*    */   @XmlElement(name = "SourceOfWealth")
/*    */   public ArrayList<SourceOfWealth> getSourceOfWealth() {
/* 15 */     return this.sourceOfWealth;
/*    */   }
/*    */   
/*    */   public void setSourceOfWealth(ArrayList<SourceOfWealth> sourceOfWealth) {
/* 19 */     this.sourceOfWealth = sourceOfWealth;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\SourcesOfWealth.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */