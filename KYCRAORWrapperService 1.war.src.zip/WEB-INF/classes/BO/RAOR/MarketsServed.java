/*    */ package WEB-INF.classes.BO.RAOR;
/*    */ 
/*    */ import BO.RAOR.Market;
/*    */ import java.util.ArrayList;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement(name = "MarketsServed")
/*    */ public class MarketsServed
/*    */ {
/*    */   private ArrayList<Market> market;
/*    */   
/*    */   @XmlElement(name = "Market")
/*    */   public ArrayList<Market> getMarket() {
/* 15 */     return this.market;
/*    */   }
/*    */   
/*    */   public void setMarket(ArrayList<Market> market) {
/* 19 */     this.market = market;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\MarketsServed.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */