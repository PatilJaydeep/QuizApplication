/*     */ package WEB-INF.classes.BO.RAOR;
/*     */ 
/*     */ import BO.RAOR.AdditionalParameters;
/*     */ import BO.RAOR.Addresses;
/*     */ import BO.RAOR.CustmerDetails;
/*     */ import BO.RAOR.CustomerCountries;
/*     */ import BO.RAOR.CustomerRoles;
/*     */ import BO.RAOR.InterestedParties;
/*     */ import BO.RAOR.MarketsServed;
/*     */ import BO.RAOR.Phones;
/*     */ import BO.RAOR.SourcesOfWealth;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ @XmlRootElement(name = "Customer")
/*     */ @XmlType(propOrder = {"custmerDetails", "jurisdiction", "customerCountries", "addresses", "phones", "sourcesOfWealth", "marketsServed", "interestedParties", "customerRoles", "accountID", "additionalParameters"})
/*     */ public class Customer
/*     */ {
/*     */   private CustmerDetails custmerDetails;
/*     */   private CustomerCountries customerCountries;
/*     */   private String Jurisdiction;
/*     */   private Addresses addresses;
/*     */   private Phones phones;
/*     */   private SourcesOfWealth sourcesOfWealth;
/*     */   private MarketsServed marketsServed;
/*     */   private InterestedParties interestedParties;
/*     */   private CustomerRoles customerRoles;
/*     */   private String AccountID;
/*     */   private AdditionalParameters additionalParameters;
/*     */   
/*     */   @XmlElement(name = "CustmerDetails")
/*     */   public CustmerDetails getCustmerDetails() {
/*  34 */     return this.custmerDetails;
/*     */   }
/*     */   
/*     */   public void setCustmerDetails(CustmerDetails custmerDetails) {
/*  38 */     this.custmerDetails = custmerDetails;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "Jurisdiction")
/*     */   public String getJurisdiction() {
/*  43 */     return this.Jurisdiction;
/*     */   }
/*     */   
/*     */   public void setJurisdiction(String Jurisdiction) {
/*  47 */     this.Jurisdiction = Jurisdiction;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CustomerCountries")
/*     */   public CustomerCountries getCustomerCountries() {
/*  52 */     return this.customerCountries;
/*     */   }
/*     */   
/*     */   public void setCustomerCountries(CustomerCountries customerCountries) {
/*  56 */     this.customerCountries = customerCountries;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "Addresses")
/*     */   public Addresses getAddresses() {
/*  61 */     return this.addresses;
/*     */   }
/*     */   
/*     */   public void setAddresses(Addresses addresses) {
/*  65 */     this.addresses = addresses;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "Phones")
/*     */   public Phones getPhones() {
/*  70 */     return this.phones;
/*     */   }
/*     */   
/*     */   public void setPhones(Phones phones) {
/*  74 */     this.phones = phones;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "SourcesOfWealth")
/*     */   public SourcesOfWealth getSourcesOfWealth() {
/*  79 */     return this.sourcesOfWealth;
/*     */   }
/*     */   
/*     */   public void setSourcesOfWealth(SourcesOfWealth sourcesOfWealth) {
/*  83 */     this.sourcesOfWealth = sourcesOfWealth;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "MarketsServed")
/*     */   public MarketsServed getMarketsServed() {
/*  88 */     return this.marketsServed;
/*     */   }
/*     */   
/*     */   public void setMarketsServed(MarketsServed marketsServed) {
/*  92 */     this.marketsServed = marketsServed;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "InterestedParties")
/*     */   public InterestedParties getInterestedParties() {
/*  97 */     return this.interestedParties;
/*     */   }
/*     */   
/*     */   public void setInterestedParties(InterestedParties interestedParties) {
/* 101 */     this.interestedParties = interestedParties;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "CustomerRoles")
/*     */   public CustomerRoles getCustomerRoles() {
/* 106 */     return this.customerRoles;
/*     */   }
/*     */   
/*     */   public void setCustomerRoles(CustomerRoles customerRoles) {
/* 110 */     this.customerRoles = customerRoles;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "AccountID")
/*     */   public String getAccountID() {
/* 115 */     return this.AccountID;
/*     */   }
/*     */   
/*     */   public void setAccountID(String AccountID) {
/* 119 */     this.AccountID = AccountID;
/*     */   }
/*     */   
/*     */   @XmlElement(name = "AdditionalParameters")
/*     */   public AdditionalParameters getAdditionalParameters() {
/* 124 */     return this.additionalParameters;
/*     */   }
/*     */   
/*     */   public void setAdditionalParameters(AdditionalParameters additionalParameters) {
/* 128 */     this.additionalParameters = additionalParameters;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\BO\RAOR\Customer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */