/*    */ package WEB-INF.classes.Database;
/*    */ 
/*    */ import Logging.Log4j;
/*    */ import Utilities.LoadProperties;
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Hashtable;
/*    */ import javax.naming.Context;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.log4j.Priority;
/*    */ 
/*    */ 
/*    */ public class JNDIConnector
/*    */ {
/* 17 */   private static Context ctx = null;
/* 18 */   private static Hashtable ht = new Hashtable<Object, Object>();
/*    */   
/*    */   static {
/*    */     try {
/* 22 */       ht.put("java.naming.factory.initial", LoadProperties.getConf().getProperty("context.factory"));
/* 23 */       ht.put("java.naming.provider.url", "t3://" + LoadProperties.getConf().getProperty("db.ip.port"));
/* 24 */       ctx = new InitialContext(ht);
/* 25 */     } catch (NamingException ex) {
/* 26 */       Log4j.getLog().log(Priority.ERROR, null, ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   public Connection getJNDIInstance(String jndiName) throws NamingException, SQLException, ClassNotFoundException {
/* 31 */     Connection conn = null;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 37 */       DataSource ds = (DataSource)ctx.lookup(jndiName);
/* 38 */       conn = ds.getConnection();
/* 39 */     } catch (SQLException ex) {
/* 40 */       throw ex;
/*    */     } 
/*    */     
/* 43 */     return conn;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\Database\JNDIConnector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */