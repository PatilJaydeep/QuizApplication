/*    */ package WEB-INF.classes.Utilities;
/*    */ 
/*    */ import java.text.DateFormat;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class GetDate
/*    */ {
/*    */   public String GetDate(String dateFormat) {
/* 11 */     DateFormat df = new SimpleDateFormat(dateFormat);
/* 12 */     Date today = Calendar.getInstance().getTime();
/* 13 */     String currentDate = df.format(today);
/* 14 */     return currentDate;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\Utilities\GetDate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */