/*    */ package WEB-INF.classes.Utilities;
/*    */ 
/*    */ public class StringOps
/*    */ {
/*    */   public String removeCDATATag(String xml) {
/*  6 */     String requestXml = xml;
/*  7 */     requestXml = requestXml.substring(9);
/*  8 */     requestXml = requestXml.substring(0, requestXml.length() - 3);
/*    */     
/* 10 */     return requestXml;
/*    */   }
/*    */   
/*    */   public String removeNamespace(String xml, String toBeReplace) {
/* 14 */     String requestXml = xml;
/* 15 */     requestXml = requestXml.replace(toBeReplace, "");
/*    */     
/* 17 */     return requestXml;
/*    */   }
/*    */   
/*    */   public String removeNs2(String xml) {
/* 21 */     String requestXml = xml;
/* 22 */     requestXml = requestXml.replace(":ns2", "");
/* 23 */     requestXml = requestXml.replace("ns2:", "");
/*    */     
/* 25 */     return requestXml;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\Utilities\StringOps.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */