/*    */ package WEB-INF.classes.Utilities;
/*    */ 
/*    */ import Logging.Log4j;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Properties;
/*    */ import org.apache.log4j.Priority;
/*    */ 
/*    */ public class LoadProperties
/*    */ {
/* 11 */   private static Properties dbProp = null;
/* 12 */   private static Properties wsNameSpace = null;
/* 13 */   private static Properties conf = null;
/*    */   
/*    */   static {
/* 16 */     Utilities.LoadProperties loadProp = new Utilities.LoadProperties();
/*    */     
/*    */     try {
/* 19 */       conf = loadProp.loadProperties("/Properties/conf.properties");
/* 20 */     } catch (IOException ex) {
/*    */       
/* 22 */       Log4j.getLog().log(Priority.ERROR, null, ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static Properties getDbProp() {
/* 27 */     return dbProp;
/*    */   }
/*    */   
/*    */   public static Properties getWsNameSpace() {
/* 31 */     return wsNameSpace;
/*    */   }
/*    */   
/*    */   public static Properties getConf() {
/* 35 */     return conf;
/*    */   }
/*    */   
/*    */   private Properties loadProperties(String propFileName) throws IOException {
/* 39 */     Properties prop = new Properties();
/* 40 */     InputStream input = null;
/*    */     
/*    */     try {
/* 43 */       input = Utilities.LoadProperties.class.getResourceAsStream(propFileName);
/*    */       
/* 45 */       prop.load(input);
/* 46 */     } catch (IOException ex) {
/* 47 */       throw ex;
/*    */     } finally {
/*    */       
/* 50 */       if (input != null) {
/*    */         
/*    */         try {
/* 53 */           input.close();
/* 54 */         } catch (IOException e) {
/* 55 */           throw e;
/*    */         } 
/*    */       }
/*    */     } 
/*    */     
/* 60 */     return prop;
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\Utilities\LoadProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */