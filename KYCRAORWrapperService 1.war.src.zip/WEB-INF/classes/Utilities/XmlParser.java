/*    */ package WEB-INF.classes.Utilities;
/*    */ 
/*    */ import BO.RAOR.RAORAcknowledgement;
/*    */ import BO.RAOR.RAORRequest;
/*    */ import BO.WrapperService.KYCRAORServiceResponse;
/*    */ import java.io.StringReader;
/*    */ import java.io.StringWriter;
/*    */ import javax.xml.bind.JAXBContext;
/*    */ import javax.xml.bind.JAXBElement;
/*    */ import javax.xml.bind.JAXBException;
/*    */ import javax.xml.bind.Marshaller;
/*    */ import javax.xml.bind.Unmarshaller;
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ public class XmlParser
/*    */ {
/*    */   public String convertoXML(Object input, String type) throws JAXBException {
/* 18 */     StringWriter writer = new StringWriter();
/*    */     
/*    */     try {
/* 21 */       JAXBContext context = null;
/* 22 */       JAXBElement<RAORRequest> je2 = null;
/*    */       
/* 24 */       if (type.equalsIgnoreCase("RAORRequest")) {
/*    */         
/* 26 */         context = JAXBContext.newInstance(new Class[] { RAORRequest.class });
/* 27 */         je2 = new JAXBElement<RAORRequest>(new QName("http://www.iflex.com/reveleus/kyc/model/customer", "RAORRequest"), RAORRequest.class, (RAORRequest)input);
/* 28 */       } else if (type.equalsIgnoreCase("RAORAcknowledgement")) {
/*    */         
/* 30 */         context = JAXBContext.newInstance(new Class[] { RAORAcknowledgement.class });
/* 31 */         je2 = new JAXBElement(new QName("http://www.oracle.com/reveleus/kyc/model/Acknowledgement", "RAORAcknowledgement"), RAORAcknowledgement.class, input);
/* 32 */       } else if (type.equalsIgnoreCase("KYCRAORServiceResponse")) {
/*    */         
/* 34 */         context = JAXBContext.newInstance(new Class[] { KYCRAORServiceResponse.class });
/* 35 */         je2 = new JAXBElement(new QName("", "KYCRAORServiceResponse"), KYCRAORServiceResponse.class, input);
/*    */       } 
/*    */       
/* 38 */       Marshaller m = context.createMarshaller();
/* 39 */       m.setProperty("jaxb.formatted.output", Boolean.valueOf(true));
/* 40 */       m.marshal(je2, writer);
/*    */     }
/* 42 */     catch (JAXBException e) {
/*    */       
/* 44 */       throw e;
/*    */     } 
/*    */     
/* 47 */     return writer.toString();
/*    */   }
/*    */   
/*    */   public Object unmarshalXMl(String xml, String type) throws JAXBException {
/*    */     try {
/* 52 */       JAXBContext jc = null;
/* 53 */       Unmarshaller u = null;
/* 54 */       Object object = null;
/*    */       
/* 56 */       if (type.equalsIgnoreCase("RAORRequest")) {
/*    */         
/* 58 */         jc = JAXBContext.newInstance(new Class[] { RAORRequest.class });
/* 59 */         u = jc.createUnmarshaller();
/* 60 */         StringReader reader = new StringReader(xml);
/* 61 */         object = u.unmarshal(reader);
/* 62 */       } else if (type.equalsIgnoreCase("RAORAcknowledgement")) {
/*    */         
/* 64 */         jc = JAXBContext.newInstance(new Class[] { RAORAcknowledgement.class });
/* 65 */         u = jc.createUnmarshaller();
/* 66 */         StringReader reader = new StringReader(xml);
/* 67 */         object = u.unmarshal(reader);
/*    */       } 
/*    */       
/* 70 */       return object;
/* 71 */     } catch (JAXBException e) {
/*    */       
/* 73 */       throw e;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\Utilities\XmlParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */