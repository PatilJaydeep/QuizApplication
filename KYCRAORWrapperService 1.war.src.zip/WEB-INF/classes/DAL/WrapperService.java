/*     */ package WEB-INF.classes.DAL;
/*     */ 
/*     */ import BO.NewFields.NewFields;
/*     */ import BO.RAOR.InterestedParty;
/*     */ import BO.RAOR.XmlMapping;
/*     */ import BO.RAOR.XmlMapping_FT;
/*     */ import BO.WatchList.ScanWatchListRequest;
/*     */ import BO.WatchList.ScanWatchListResponse;
/*     */ import BO.WrapperService.Match;
/*     */ import BO.WrapperService.WatchList;
/*     */ import DAO.FATCAData.FATCADataOperations;
/*     */ import DAO.KYCData.KYCDataOperations;
/*     */ import DAO.WatchListData.WatchListDataOperation;
/*     */ import DAO.WrapperServiceDataOperation;
/*     */ import Logging.Log4j;
/*     */ import Utilities.LoadProperties;
/*     */ import WebServices.WebServiceClients.WebServiceConsumer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Priority;
/*     */ 
/*     */ public class WrapperService
/*     */ {
/*  25 */   KYCDataOperations kycDataOps = new KYCDataOperations();
/*  26 */   FATCADataOperations fatcaDataOps = new FATCADataOperations();
/*  27 */   WatchListDataOperation wlDataOps = new WatchListDataOperation();
/*  28 */   WebServiceConsumer wsConsumer = new WebServiceConsumer();
/*  29 */   WrapperServiceDataOperation wsDataOps = new WrapperServiceDataOperation();
/*  30 */   NewFields newFields = null;
/*  31 */   NewFields newFields_FT = null;
/*  32 */   private String requestRAORID = "";
/*     */   
/*     */   public String createWrapperServiceResponse(String in0, String in1, String in2) {
/*  35 */     String wrapperServiceResponse = "";
/*  36 */     WatchList respWLBO = null;
/*  37 */     String[] respRAORBO = null;
/*  38 */     String[] respFATCABO = null;
/*     */     
/*     */     try {
/*  41 */       respRAORBO = getKYCResponseObj(in0, in1, in2);
/*     */       
/*  43 */       respFATCABO = getFATCAResponseObj(in0, in1, in2);
/*     */       
/*  45 */       String isWatchlistActive = LoadProperties.getConf().getProperty("watchlist.isActive");
/*     */       
/*  47 */       if (isWatchlistActive.equalsIgnoreCase("Y")) {
/*  48 */         respWLBO = getWatchListResponseObj();
/*     */       }
/*     */       
/*  51 */       wrapperServiceResponse = this.wsDataOps.createWrapperServiceResponse(respRAORBO, respWLBO, respFATCABO);
/*  52 */     } catch (Exception ex) {
/*     */       
/*  54 */       Log4j.getLog().log(Priority.ERROR, null, ex);
/*  55 */       wrapperServiceResponse = "Service execution failed! Check log file for details";
/*     */     } 
/*  57 */     return wrapperServiceResponse;
/*     */   }
/*     */   
/*     */   public String[] getKYCResponseObj(String xml, String username, String password) throws Exception {
/*  61 */     HashMap<String, String> custIDs = new HashMap<String, String>();
/*  62 */     ArrayList<XmlMapping> mappings = null;
/*  63 */     String[] maxRiskScore = null;
/*     */     
/*     */     try {
/*  66 */       Log4j.getLog().info("Request XML: " + xml);
/*     */       
/*  68 */       this.newFields = this.kycDataOps.loadNewField(xml);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  77 */       custIDs = this.kycDataOps.insertRAORInfoToDB(this.newFields);
/*     */       
/*  79 */       this.requestRAORID = custIDs.get("raorRequestID");
/*  80 */       custIDs.remove("raorRequestID");
/*     */       
/*  82 */       maxRiskScore = this.kycDataOps.getRiskScore(custIDs, this.requestRAORID);
/*     */       
/*  84 */       this.kycDataOps.updateRAORResponseToDB(maxRiskScore, this.requestRAORID);
/*     */       
/*  86 */       if (this.newFields.getInterestedParty() != null && this.newFields.getInterestedParty().size() > 0) {
/*  87 */         for (int i = 0; i < this.newFields.getInterestedParty().size(); i++) {
/*  88 */           this.newFields.getLegalNames().put((i + 1) + "-" + ((InterestedParty)this.newFields.getInterestedParty().get(i)).getCustomerDetails().getCustomerType() + "SH", ((InterestedParty)this.newFields.getInterestedParty().get(i)).getCustomerDetails().getLegalName());
/*     */         }
/*     */       }
/*     */       
/*  92 */       Log4j.getLog().info("LegalName count " + this.newFields.getLegalNames().size());
/*  93 */     } catch (Exception ex) {
/*     */       
/*  95 */       throw ex;
/*     */     } 
/*     */     
/*  98 */     return maxRiskScore;
/*     */   }
/*     */   
/*     */   public WatchList getWatchListResponseObj() throws Exception {
/* 102 */     ScanWatchListResponse response = null;
/* 103 */     ScanWatchListRequest scanRequest = null;
/* 104 */     ArrayList<Match> matchList = null;
/* 105 */     ArrayList<Match> filteredMatch = new ArrayList<Match>();
/* 106 */     WatchList watchList = new WatchList();
/* 107 */     int i = 0;
/*     */     
/* 109 */     String[] caseRefAndWlsKey = null;
/*     */     
/*     */     try {
/* 112 */       for (Map.Entry m : this.newFields.getLegalNames().entrySet()) {
/*     */         
/* 114 */         scanRequest = this.wlDataOps.setWatchListBO(m.getKey().toString(), m.getValue().toString());
/*     */         
/* 116 */         caseRefAndWlsKey = this.wlDataOps.insertWLSRequestToDB(this.newFields, this.requestRAORID, m.getKey().toString(), m.getValue().toString(), i);
/*     */         
/* 118 */         if (m.getKey().toString().contains("SH")) {
/* 119 */           i++;
/*     */         }
/*     */         
/* 122 */         response = this.wsConsumer.invokeWatchListService(scanRequest);
/*     */         
/* 124 */         this.wlDataOps.insertWLSResponseToDB(response, caseRefAndWlsKey, m.getKey().toString());
/*     */         
/* 126 */         this.wlDataOps.updateWLSRequestStatus(this.requestRAORID);
/*     */         
/* 128 */         matchList = this.wlDataOps.mapWLResponseToObj(response, m.getKey().toString());
/*     */         
/* 130 */         if (filteredMatch.isEmpty()) {
/*     */           
/* 132 */           filteredMatch = matchList;
/*     */         } else {
/*     */           
/* 135 */           for (Match matchedName : matchList) {
/*     */             
/* 137 */             Match match = new Match();
/* 138 */             match.setWatchListLegalName(matchedName.getWatchListLegalName());
/* 139 */             match.setWatchListScore(matchedName.getWatchListScore());
/* 140 */             match.setWatchListName(matchedName.getWatchListName());
/* 141 */             match.setWatchListCustomerType(matchedName.getWatchListCustomerType());
/* 142 */             filteredMatch.add(match);
/*     */           } 
/*     */         } 
/* 145 */         filteredMatch = this.wlDataOps.getTopRecords(filteredMatch);
/*     */       } 
/*     */       
/* 148 */       watchList.setMatch(filteredMatch);
/* 149 */     } catch (Exception ex) {
/*     */       
/* 151 */       throw ex;
/*     */     } 
/*     */     
/* 154 */     return watchList;
/*     */   }
/*     */   
/*     */   public String[] getFATCAResponseObj(String xml, String username, String password) throws Exception {
/* 158 */     HashMap<String, String> custIDs_FT = new HashMap<String, String>();
/* 159 */     ArrayList<XmlMapping_FT> mappings_FT = null;
/* 160 */     String[] fatcaResponseParams = null;
/*     */     
/*     */     try {
/* 163 */       Log4j.getLog().info("Request XML: " + xml);
/*     */       
/* 165 */       this.newFields_FT = this.fatcaDataOps.loadNewField(xml);
/*     */       
/* 167 */       mappings_FT = this.fatcaDataOps.loadXMLTagMapping();
/*     */       
/* 169 */       custIDs_FT = this.fatcaDataOps.insertRAORInfoToDB(mappings_FT, this.newFields_FT);
/*     */       
/* 171 */       this.requestRAORID = custIDs_FT.get("raorRequestID");
/* 172 */       custIDs_FT.remove("raorRequestID");
/*     */       
/* 174 */       this.fatcaDataOps.calculateIndicia(custIDs_FT, this.requestRAORID);
/*     */       
/* 176 */       fatcaResponseParams = this.fatcaDataOps.getfatcaResponseParams(this.requestRAORID, this.newFields_FT, custIDs_FT);
/*     */     }
/* 178 */     catch (Exception ex) {
/*     */       
/* 180 */       throw ex;
/*     */     } 
/*     */     
/* 183 */     return fatcaResponseParams;
/*     */   }
/*     */ }


/* Location:              C:\Users\919957\Downloads\KYCRAORWrapperService 1.war!\WEB-INF\classes\DAL\WrapperService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */